# TEST - Frontend Automation

## Initial setup

When starting this project the first time, run this line in your console:

```
sudo apt-get install libgstreamer-plugins-bad1.0-0 libflite1 gstreamer1.0-libav 
```
Then add the [certificate](tools/BMWGroupRootCAV3.crt) into your Java SDK.

```
keytool -keystore  <path-to-your-jdk>>/lib/security/cacerts -storepass changeit -importcert -alias bmwgroup_root_ca_v3 -file tools/BMWGroupRootCAV3.
crt -noprompt
```

Finally, add the env variables mentioned in this file:
[CardataCredentials](src/main/java/de/bmw/otp/tests/config/CardataCredentials.java)

Not all are currently needed. For now these are mandatory:

- CARDATA_CLIENT_ID_E2E
- CARDATA_CLIENT_SECRET_E2E
- CUSTOMER_PORTAL_BASIC_PASSWORD_E2E
- CUSTOMER_PORTAL_BASIC_USER_NAME_E2E
- CUSTOMER_PORTAL_PASSWORD_E2E
- CUSTOMER_PORTAL_USER_NAME_E2E
- THIRD_PARTY_PORTAL_PW_E2E
- THIRD_PARTY_PORTAL_USER_E2E
- CLEARANCE_BACKEND_USER_E2E
- CLEARANCE_BACKEND_PW_E2E
- THIRD_PARTY_ID_E2E

## Technical user

The pipeline uses a technical jira user (QDBBBA2) to authenticate to jira and push the results of the test run. 
This is done via a personal access token (PAT) that frequently expires (usually after a year, depending on what has been set when creating it).
You can find the credentials for the technical user in the Dev Keepass and can re-create the PAT once it ran out by logging in with these credentials.
