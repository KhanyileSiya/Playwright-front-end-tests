import de.bmw.otp.tests.TestResultExporterForXRay

plugins {
    id("java")
	id("org.openapi.generator") version "7.11.0"
}

repositories {
    mavenCentral()
}

dependencies {
// https://mvnrepository.com/artifact/com.microsoft.playwright/playwright
    implementation("com.microsoft.playwright:playwright:1.49.0")
// https://mvnrepository.com/artifact/com.jayway.jsonpath/json-path
    implementation("com.jayway.jsonpath:json-path:2.9.0")
// https://mvnrepository.com/artifact/org.apache.pdfbox/pdfbox
    implementation("org.apache.pdfbox:pdfbox:2.0.27")
// https://mvnrepository.com/artifact/com.fasterxml.jackson.core/jackson-core
    implementation("com.fasterxml.jackson.core:jackson-core:2.18.2")
// https://mvnrepository.com/artifact/com.fasterxml.jackson.core/jackson-databind
    implementation("com.fasterxml.jackson.core:jackson-databind:2.18.2")
// https://mvnrepository.com/artifact/org.junit.platform/junit-platform-reporting
    implementation("org.junit.platform:junit-platform-reporting:1.13.0")

    // https://mvnrepository.com/artifact/com.fasterxml.jackson.datatype/jackson-datatype-jsr310
    implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310:2.18.2")
	// https://mvnrepository.com/artifact/com.github.spotbugs/spotbugs-annotations
	implementation("com.github.spotbugs:spotbugs-annotations:4.9.1")
	// https://mvnrepository.com/artifact/org.openapitools/jackson-databind-nullable
	implementation("org.openapitools:jackson-databind-nullable:0.2.6")

// https://mvnrepository.com/artifact/com.squareup.okhttp3/okhttp
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
// https://mvnrepository.com/artifact/com.squareup.okhttp3/logging-interceptor
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
// https://mvnrepository.com/artifact/io.gsonfire/gson-fire
    implementation("io.gsonfire:gson-fire:1.9.0")

    // https://mvnrepository.com/artifact/com.fasterxml.jackson.dataformat/jackson-dataformat-xml
    implementation("com.fasterxml.jackson.dataformat:jackson-dataformat-xml:2.19.0")

    implementation(platform("org.junit:junit-bom:1.13.0"))
    implementation("org.junit.jupiter:junit-jupiter:1.13.0")
    // https://mvnrepository.com/artifact/org.hamcrest/hamcrest
    implementation("org.hamcrest:hamcrest:3.0")

    // https://mvnrepository.com/artifact/com.tngtech.archunit/archunit-junit5
    testImplementation("com.tngtech.archunit:archunit-junit5:1.4.1")
}

tasks.test {
    useJUnitPlatform()
    testLogging.setShowStandardStreams(true)
    reports.junitXml.isOutputPerTestCase = true
    val exporter = TestResultExporterForXRay()
    addTestListener(exporter)
    addTestOutputListener(exporter)
}

tasks.register<JavaExec>("install_playwright") {
    mainClass = "com.microsoft.playwright.CLI"
    classpath = sourceSets.main.get().runtimeClasspath
    args("install-deps")
}

tasks.register<JavaExec>("jira_upload") {
    classpath = sourceSets.main.get().runtimeClasspath
    mainClass = "de.bmw.otp.jira.JiraUploader"
}

openApiGenerate {
	generatorName.set("java")
	inputSpec.set("$rootDir/src/main/resources/api-cardata-e2e.json")
    skipValidateSpec.set(true)
	outputDir.set("$rootDir")
	apiPackage.set("de.bmw.otp.exve.api")
	invokerPackage.set("de.bmw.otp.exve.invoker")
	modelPackage.set("de.bmw.otp.exve.model")
	configOptions.put("dateLibrary", "java8")
	generateApiTests.set(false)
	generateModelTests.set(false)
	additionalProperties.put("library", "okhttp-gson")
	additionalProperties.put("hideGenerationTimestamp", "true")
	additionalProperties.put("withXml", "false")
    additionalProperties.put("useRuntimeException", "true")
	enablePostProcessFile.set(true)
}
