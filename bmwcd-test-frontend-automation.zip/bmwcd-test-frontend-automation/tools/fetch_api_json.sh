#!/usr/bin/env bash

ROOT_PATH=$(git rev-parse --show-toplevel)

curl -k 'https://exve.e2e.apps.4wm-de-odp-nonprod.eu-central-1.aws.cloud.bmw/v3/api-docs/Extended%20Vehicle%20API%20(internal)' -H 'Accept: application/json' | jq > ${ROOT_PATH}/src/main/resources/api-cardata-e2e.json
