#!/usr/bin/env bash

ROOT_PATH=$(git rev-parse --show-toplevel)

TEST_SUITE_BMW_STR=""
TEST_SUITE_MINI_STR=""
TEST_SUITE_RR_STR=""
TEST_SUITE_TOYOTA_STR=""
TEST_SUITE_3PP_STR=""
TEST_SUITE_SELF_STR=""

if [[ "$TEST_SUITE_BMW" == "true" ]]; then
	TEST_SUITE_BMW_STR="--tests de.bmw.otp.MyBmw.* "
fi

if [[ "$TEST_SUITE_MINI" == "true" ]]; then
	TEST_SUITE_MINI_STR="--tests de.bmw.otp.MyMini.* "
fi

if [[ "$TEST_SUITE_RR" == "true" ]]; then
	TEST_SUITE_RR_STR="--tests de.bmw.otp.MyRollsRoyce.* "
fi

if [[ "$TEST_SUITE_TOYOTA" == "true" ]]; then
	TEST_SUITE_TOYOTA_STR="--tests de.bmw.otp.MyToyota.* "
fi

if [[ "$TEST_SUITE_3PP" == "true" ]]; then
	TEST_SUITE_3PP_STR="--tests de.bmw.otp.ThirdPartyPortal.* "
fi

if [[ "$TEST_SUITE_SELF" == "true" ]]; then
	TEST_SUITE_SELF_STR="--tests de.bmw.otp.architecture.* --tests de.bmw.otp.tests.* "
fi

cd $ROOT_PATH && ./gradlew cleanTest :test $TEST_SUITE_BMW_STR $TEST_SUITE_MINI_STR $TEST_SUITE_RR_STR $TEST_SUITE_TOYOTA_STR $TEST_SUITE_3PP_STR $TEST_SUITE_SELF_STR
