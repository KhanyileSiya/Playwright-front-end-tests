#!/usr/bin/env bash

ROOT_PATH=$(git rev-parse --show-toplevel)

function check_domain() {
	local domain=$1

	echo "########## nslookup $domain"
	nslookup $domain

	echo "########## dig $domain"
	dig $domain

	echo "########## ping -c 4 $domain"
	ping -c 4 $domain

	echo "########## curl -vk https://$domain"
	curl -vk "https://$domain"

#	echo "########## nmap -p 443 $domain"
#	nmap -p 443 $domain

#	echo "########## tracepath $domain"
#	tracepath $domain
}

ip a

#int
check_domain api-cardata-int.bmwgroup.com
check_domain bmwcardata-int.bmwgroup.com
check_domain bmw-de-awsint-b1.int.bmwweb.eu-central-1.aws.bmw.cloud
check_domain mini-de-awsint-m2.int.miniweb.eu-central-1.aws.bmw.cloud
check_domain int.mybmw.com

#e2e
check_domain api-cardata-e2e.bmwgroup.com
check_domain bmwcardata-e2e.bmwgroup.com
check_domain bmw-de-awsint-b2.int.bmwweb.eu-central-1.aws.bmw.cloud
check_domain mini-de-awsint-m4.int.miniweb.eu-central-1.aws.bmw.cloud
check_domain e2e.mybmw.com

#prod
check_domain api-cardata.bmwgroup.com
check_domain bmw-cardata.bmwgroup.com
check_domain www.bmw.de
check_domain www.mini.de
check_domain cardata.rolls-roycemotorcars.com
check_domain www.toyota-supraconnect.de
