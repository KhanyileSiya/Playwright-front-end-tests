#!/usr/bin/env bash

JAVA_FILE=$1
sed -i -e 's/@javax.annotation.Generated(/@javax.annotation.processing.Generated(/g' "$JAVA_FILE" || exit 1
sed -i -e 's/import javax.xml.bind.annotation./import jakarta.xml.bind.annotation./g' "$JAVA_FILE" || exit 1
grep "^@javax.annotation.processing.Generated" "$JAVA_FILE" >/dev/null || (sed -i -e 's/^public class /@javax.annotation.processing.Generated(value = "org.openapitools.codegen.languages.JavaClientCodegen")\npublic class /g' "$JAVA_FILE") || exit 1
grep "^@javax.annotation.processing.Generated" "$JAVA_FILE" >/dev/null || (sed -i -e 's/^public interface /@javax.annotation.processing.Generated(value = "org.openapitools.codegen.languages.JavaClientCodegen")\npublic interface /g' "$JAVA_FILE") || exit 1
sed -i -e 's/import de.bmw.otp.exve.invoker.auth.RetryingOAuth;/import de.bmw.otp.tests.api.RetryingOAuth;/g' "$JAVA_FILE" || exit 1
sed -i -e 's/import org.apache.oltu.oauth2.common.message.types.GrantType;/\/\//g' "$JAVA_FILE" || exit 1
sed -i -e 's/import org.apache.oltu.oauth2.client.request.OAuthClientRequest.TokenRequestBuilder;/import de.bmw.otp.tests.api.TokenRequestBuilder;/g' "$JAVA_FILE" || exit 1
sed -i -e 's/public String selectHeaderAccept(String\[\] accepts) {/public String selectHeaderAccept(String\[\] accepts) { if(true) { if(accepts.length == 0){return null;}else{return StringUtil.join(accepts, ",");} }/g' "$JAVA_FILE" || exit 1
#sed -i -e 's/import org.apache.oltu.oauth2/\/\//g' "$JAVA_FILE" || exit 1
#sed -i -e 's/public TokenRequestBuilder getTokenEndPoint/\/\*/g' "$JAVA_FILE" || exit 1
