#!/usr/bin/env bash

ROOT_PATH=$(git rev-parse --show-toplevel)

keytool -cacerts -storepass changeit -importcert -alias bmwgroup_root_ca_v3 -file $ROOT_PATH/tools/BMWGroupRootCAV3.crt -noprompt
