#!/usr/bin/env bash

ROOT_PATH=$(git rev-parse --show-toplevel)

rm -rf "${ROOT_PATH}/src/main/java/de/bmw/otp/exve"
cd $ROOT_PATH && JAVA_POST_PROCESS_FILE="/usr/bin/bash ${ROOT_PATH}/tools/postprocess.sh" $ROOT_PATH/gradlew :openApiGenerate
rm "${ROOT_PATH}/src/main/java/de/bmw/otp/exve/invoker/auth/OAuthOkHttpClient.java"
rm "${ROOT_PATH}/src/main/java/de/bmw/otp/exve/invoker/auth/RetryingOAuth.java"
