package de.bmw.otp.tests;

import java.util.Arrays;

public interface LoggingHelper {

	default void logMethodCall(String... args) {
		logMethodCall(1, args);
	}

	default void logMethodCall(int methodOffset, String[] args) {
		var completeStack = stack();
		var parentMethod = completeStack[3+methodOffset];
		final String data;
		if (args == null || args.length == 0) {
			data = "";
		} else {
			data = " data: " + Arrays.toString(args);
		}
		System.out.println(loggingPrefix() + " " + parentMethod.getMethodName() + data);
	}

	default void log(String line) {
		System.out.println(loggingPrefix() + " " + line);
	}

	default String loggingPrefix() {
		return "======";
	}

	static StackTraceElement[] stack() {
		Thread thread = Thread.currentThread();
		return thread.getStackTrace();
	}
}
