package de.bmw.otp.playwright;

import de.bmw.otp.tests.CardataStage;
import de.bmw.otp.tests.EnvVar;
import de.bmw.otp.tests.WithCleanup;
import org.junit.jupiter.api.TestInfo;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class PlaywrightBase implements PlaywrightHelper {

	private static PlaywrightContext playwright;
	private BrowserContext browser;
	private PageHandle page;
	private TestInfo testInfo;
	private static boolean shouldContinue = true;

	@Override
	public PageHandle getPage() {
		return page;
	}

	protected static void baseSetUpAll() {
		shouldContinue = true;
		playwright = new PlaywrightContext();
	}

	protected void baseSetUp(CardataStage stage, TestInfo testInfo) {
		System.out.println("====== START TEST " + testInfo.getDisplayName());
		assertTrue(shouldContinue, "aborted by predecessor");
		this.browser = playwright.browserContext(stage, getNavigationTimeout(), getLocatorTimeout());
		setAndConfigurePage(browser.getPage(this));
		this.testInfo = testInfo;
	}

	protected void baseTearDown() {
		System.out.println("====== END TEST " + testInfo.getDisplayName());
		if (this.page != null) {
			this.page.close();
			this.page = null;
		}
		this.browser.close();
		this.browser = null;
	}

	protected static void baseTearDownAll() {
		playwright.close();
	}

	protected void abortTests() {
		shouldContinue = false;
	}

	protected void continueTests() {
		shouldContinue = true;
	}

	protected Optional<String> getCookie(String name) {
		return this.browser.getCookie(name);
	}

	public String testMethod() {
		return this.testInfo.getDisplayName();
	}

	public Optional<String> testClass() {
		return this.testInfo.getTestClass().map(Class::getName);
	}

	private void setAndConfigurePage(PageHandle page) {
		if (page != null && EnvVar.BROWSER_LOGGING.isTrue()) {
			page.getPage().onConsoleMessage(msg -> {
				String withPrefix = "====== browser: " + msg.text();
				var output = "error".equals(msg.type())
					? System.err
					: System.out;
				output.println(withPrefix);
			});
		}
		this.page = page;
	}

	public WithCleanup<PageHandle> withTemporaryPage(PageHandle popup) {
		var oldPage = this.page;
		setAndConfigurePage(popup);
		return new WithCleanup<>(popup, ignore -> this.page = oldPage);
	}
}
