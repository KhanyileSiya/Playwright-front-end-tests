package de.bmw.otp.business;

import de.bmw.otp.playwright.LocatorHandle;
import de.bmw.otp.tests.VinPair;

import java.nio.file.Path;

public interface MyToyotaHelper extends CustomerPortalHelper {
	@Override
	default String getTransactionReportAssertText() {return "Im definierten Zeitraum wurden für Ihr Fahrzeug keine Datenabrufe Dritter durchgeführt oder Daten zu Ereignissen bereitgestellt.";}

	default VinPair getVinPairOfStage() {
		return getStage().vins().myToyota();
	}

	@Override
	default void openPageAndLogin() {
		openPageAndLogin("Weiter", "Jetzt anmelden");
		LocatorHandle buttonRejectCookies = locateClassWithText("button-text", "Cookies verbieten");
		if (buttonRejectCookies.isPresent(getNavigationTimeout())) {
			buttonRejectCookies.click();
		}
	}

	default Path getRegressionCustomerPortalFolder() {
		return getRegressionFolder().resolve("mytoyota");
	}

	@Override
	default void selectVin(String vin) {
		CustomerPortalHelper.super.selectVin(vin);
		clickCheckError(getByTestId("navigationItemLink").getByText("Toyota Supra Connect CarData"));
	}

	@Override
	default LocatorHandle locateVehicleSelection(String vin) {
		return getByTestId("fullyMapped")
			.filterHasText("VIN: " + vin)
			.select("[data-tracking-linkid='myb > vehicle details']");
	}

	default String getBaseUrl() {
		return getStage().urls().myToyotaBase();
	}

	default void assertTransactionReportRequested() {
		assertTransactionReportRequested("Toyota CarData");
	}

	default LocatorHandle locateAccessPermission() {
		return locateClassWithText("chakra-heading", "Toyota Supra Vehicle Data Datenfreigaben");
	}

	default LocatorHandle locateServicefreigaben() {
		return locateClassWithText("chakra-heading", "Toyota Supra Vehicle Data Servicefreigaben");
	}

	default void verifyClearanceDetails(String testingContainerTitle, String status) {
		verifyClearanceDetails("Toyota CarData", testingContainerTitle, status);
	}

}
