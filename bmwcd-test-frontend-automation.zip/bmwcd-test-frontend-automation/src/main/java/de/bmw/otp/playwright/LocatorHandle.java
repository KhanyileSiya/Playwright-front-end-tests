package de.bmw.otp.playwright;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.TimeoutError;
import com.microsoft.playwright.options.AriaRole;
import com.microsoft.playwright.options.WaitForSelectorState;
import org.junit.jupiter.api.Assertions;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

public class LocatorHandle {
	private final PlaywrightHelper helper;
	private final Locator loc;

	public LocatorHandle(PlaywrightHelper helper, Locator loc) {
		this.helper = helper;
		this.loc = loc;
	}

	public LocatorHandle getByText(String text) {
		return toHandle(loc.getByText(text));
	}

	public LocatorHandle getByTestId(String id) {
		return toHandle(loc.getByTestId(id));
	}

	public LocatorHandle select(String selector) {
		return toHandle(loc.locator(selector));
	}

	public LocatorHandle locateRow(String withText) {
		return toHandle(loc
			.getByRole(AriaRole.ROW)
			.filter(new Locator.FilterOptions().setHasText(withText)));
	}

	public LocatorHandle filter(LocatorHandle predicate) {
		return toHandle(loc.filter(new Locator.FilterOptions().setHas(predicate.loc)));
	}

	public LocatorHandle filterHasText(String text) {
		return toHandle(loc.filter(new Locator.FilterOptions().setHasText(text)));
	}

	public LocatorHandle and(LocatorHandle predicate) {
		return toHandle(loc.and(predicate.loc));
	}

	public LocatorHandle andIsHeading() {
		return and(helper.getByRole(AriaRole.HEADING));
	}

	public LocatorHandle first() {
		return nth(0);
	}

	public LocatorHandle nth(int idx) {
		return toHandle(loc.nth(idx));
	}

	public void assertVisible() {
		locateInternal(() -> {
			loc.scrollIntoViewIfNeeded();
			assertThat(loc).isVisible();
		});
	}

	public void assertMissing() {
		boolean present = isPresent(3_000);
		if (present) {
			helper.screenshot("should_be_missing");
			Assertions.fail();
		}
	}

	public void assertIsChecked() {
		if (!isChecked()) {
			helper.screenshot("should_be_checked");
			Assertions.fail();
		}
	}

	public String inputValue() {
		return locateInternal(() -> loc.inputValue());
	}

	public String textContent() {
		return withScreenshotWait("textContent", Locator::textContent);
	}

	public List<String> allTextContents() {
		return withScreenshotNoWait("textContent", Locator::allTextContents);
	}

	public List<LocatorHandle> all() {
		return loc.all()
			.stream()
			.map(this::toHandle)
			.toList();
	}

	public void click() {
		withScreenshotVoid("click", loc, Locator::click);
	}

	public void click(KeyboardModifier modifier) {
		withScreenshotVoid("click", loc, locator -> locator.click(new Locator.ClickOptions().setModifiers(List.of(modifier.internal()))));
	}

	public void check() {
		withScreenshotVoid("check", loc, Locator::check);
	}

	public void fill(String input) {
		withScreenshotVoid("fill", loc, loc -> loc.fill(input));
	}

	public boolean isEnabled() {
		return loc.isEnabled();
	}

	public boolean isChecked() {
		return loc.isChecked();
	}

	public boolean isPresent(double timeoutMillis) {
		try {
			loc.waitFor(new Locator.WaitForOptions()
				.setTimeout(timeoutMillis)
				.setState(WaitForSelectorState.VISIBLE));
			return loc.count() > 0;
		} catch (PlaywrightException e) {
			return false;
		}
	}

	private <T> T locateInternal(Supplier<T> locator) {
		try {
			helper.preLocatorHook();
			var result = locator.get();
			helper.postLocatorHook();
			return result;
		} catch (TimeoutError e) {
			e.printStackTrace();
			helper.onTimeout(e);
			throw e;
		}
	}

	private void locateInternal(Runnable locator) {
		try {
			helper.preLocatorHook();
			locator.run();
			helper.postLocatorHook();
		} catch (TimeoutError e) {
			e.printStackTrace();
			helper.onTimeout(e);
			throw e;
		}
	}

	private <R> R withScreenshotWait(String operation, Function<Locator, R> function) {
		return withScreenshot(operation, function, true);
	}

	private <R> R withScreenshotNoWait(String operation, Function<Locator, R> function) {
		return withScreenshot(operation, function, false);
	}

	private <R> R withScreenshot(String operation, Function<Locator, R> function, boolean shouldWait) {
		try {
			if (shouldWait) {
				loc.waitFor(new Locator.WaitForOptions().setTimeout(helper.getLocatorTimeout()));
				loc.scrollIntoViewIfNeeded();
			}
			helper.screenshot(operation);
			return function.apply(loc);
		} catch (TimeoutError e) {
			e.printStackTrace();
			helper.onTimeout(e);
			throw e;
		}
	}

	private void withScreenshotVoid(String operation, Locator locator, Consumer<Locator> function) {
		try {
			locator.waitFor(new Locator.WaitForOptions().setTimeout(helper.getLocatorTimeout()));
			locator.scrollIntoViewIfNeeded();
			helper.screenshot(operation);
			function.accept(locator);
		} catch (TimeoutError e) {
			e.printStackTrace();
			helper.onTimeout(e);
			throw e;
		}
	}

	private LocatorHandle toHandle(Locator loc) {
		return new LocatorHandle(helper, loc);
	}
}
