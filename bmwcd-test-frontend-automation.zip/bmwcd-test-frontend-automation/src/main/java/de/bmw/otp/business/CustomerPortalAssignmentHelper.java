package de.bmw.otp.business;

import de.bmw.otp.playwright.LocatorHandle;

public interface CustomerPortalAssignmentHelper extends CustomerPortalHelper{

	default LocatorHandle locateFirstAssignmentTile() {
		return locateAssignmentTile().first();
	}

	default void verifyAssignmentDetails(String status) {
		logMethodCall(status);
		var assignmentTile = locateFirstAssignmentTile();

		assertAssignmentTileDetailsAreCorrect(assignmentTile, status);

		assignmentTile.getByTestId("detailsLink").getByText("Service Partner").click();

		assertAssignmentDetailsTextIsCorrect();

		getByText("Playwright Regression Test").assertVisible();

		clickDetailsCancel(getByTestId("backLink"));
	}

	default void assertAssignmentDetailsTextIsCorrect(){
		logMethodCall();
		locateAssignmentPersonalMessage().assertVisible();

		locateAssignmentPartnerDetails().assertVisible();
		getByTestId("applicantName").getByText("BMW AG CA-534 CarData ProconDEV").assertVisible();
		getByTestId("applicantAddress").getByText("Bremer Str. 6, München, 80807, DE").assertVisible();
		getByTestId("customerName").getByText("Test INT").assertVisible();
		getByTestId("customerPhone").getByText("111222333").assertVisible();
		getByTestId("customerEmail").getByText("CarData.Playwright.Automation+360m@byom.de").assertVisible();

	}

	default void assertAssignmentTileDetailsAreCorrect(LocatorHandle tile, String status){
		logMethodCall();
		tile.getByText("BMW AG CA-534 CarData ProconDEV").assertVisible();
		tile.getByTestId("requestStatusKey").getByText("Status").assertVisible();
		tile.getByTestId("requestStatusValue").getByText(status).assertVisible();
		locateAssignmentModifiedDate(tile).assertVisible();
		tile.getByTestId("undefinedKey").getByText("Service").assertVisible();
		tile.getByTestId("undefinedValue").getByText("Service Partner").assertVisible();

	}
}
