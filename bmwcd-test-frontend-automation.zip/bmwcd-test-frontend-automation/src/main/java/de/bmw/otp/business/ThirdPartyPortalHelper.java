package de.bmw.otp.business;

import de.bmw.otp.playwright.LocatorHandle;
import de.bmw.otp.tests.WithCleanup;
import de.bmw.otp.tests.api.MsClearanceClient;

import static org.junit.jupiter.api.Assertions.assertEquals;

public interface ThirdPartyPortalHelper extends TestBase {

	String getTestingContainerTitle();

	default void openAndLogin3rdPartyPortal() {
		this.openAndLogin3rdPartyPortal(true);
	}

	default void openAndLogin3rdPartyPortal(boolean needLogin) {
		var user = getStage().thirdPartyPortal().credentials();
		this.openAndLogin3rdPartyPortal(getStage().thirdPartyPortal().url(), user.getUsername(), user.getPassword(), needLogin);
	}

	default void openAndLogin3rdPartyPortal(String url, String username, String password, boolean needLogin) {
		getPage().navigate(url, 40_000);
		if (needLogin) {
			select("#idToken2").fill(username);
			select("#idToken3").fill(password);
			waitForThirdParty(() -> {
				select("#idToken4_0").click();
			});
		}
		selectLanguageGerman();
	}

	default void selectLanguageGerman() {
		logMethodCall();
		select("app-group-header")
			.select("app-language")
			.select("nz-select")
			.click();
		select("nz-option-container")
			.select("nz-option-item[ng-reflect-value=\"de\"]")
			.click();
	}

	default void openContainerCreation() {
		logMethodCall();
		openMenu("Container erstellen");
		locateButton("Echtzeit-CarData-Container erstellen").click();
	}

	default void openContainerOverview() {
		logMethodCall();
		waitForResponse("**/thirdparty/api/v1/containers", () -> {
			openMenu("Container-Übersicht");
		});
	}

	default void openMenu(String menuItem) {
		locateElementWithText("span", "CarData").click();
		getByText(menuItem).click();
	}

	default WithCleanup<String> createContainerByApi(String title) {
		logMethodCall(title);
		var client = makeMsClearanceClient();
		var containerId = client.createContainer(title, "Das ist ein Playwright Test per API", client.allTelematicKeys());
		return new WithCleanup<>(containerId, client::deleteContainerNoThrow);
	}

	default MsClearanceClient makeMsClearanceClient() {
		return new MsClearanceClient(getStage(), this);
	}

	default String createContainerByGui(String title) {
		return createContainerByGui(title, null);
	}

	default String createContainerByGui(String title, Integer maxKeys) {
		logMethodCall(title, String.valueOf(maxKeys));
		openContainerCreation();

		unfoldTelematicKeySelectionGroupsReversedSoThatAnimationDoesNotBreakThings();

		int countCheckedBoxes = 0;
		LocatorHandle checkboxes = getCheckbox();
		for (LocatorHandle checkbox : checkboxes.all()) {
			if (checkbox.isEnabled()) {
				checkbox.check();
				checkbox.assertIsChecked();
				countCheckedBoxes++;
			}
			if (maxKeys != null) {
				maxKeys--;
				if (maxKeys <= 0) {
					break;
				}
			}
		}

		assertTelematicKeyCreationSummaryValue("Gesamtsumme", 1, countCheckedBoxes+"");

		locateButton("Weiter").click();

		System.out.println("Container Title= " + title);
		select("#title").fill(title);
		select("#clearanceRequestMessage").fill("Das ist ein Playwright Test");
		getByText("Weiter").click();

		waitForContainers(() -> {
			locateButton("Container erstellen").click();
		});

		String containerId = findRegressionContainerAndGetContainerId();

		return containerId;
	}

	default void unfoldTelematicKeySelectionGroupsReversedSoThatAnimationDoesNotBreakThings() {
		var collapsedTelematicKeyGroups = locateTelematicKeySelection()
			.select("nz-collapse-panel:not(.ant-collapse-item-active)")
			.all()
			.reversed();
		for (LocatorHandle collapsed : collapsedTelematicKeyGroups) {
			//collapsed.click();
			clickCheckError(collapsed);
		}
	}

	default LocatorHandle locateTelematicKeySelection() {
		return locateCarDataBody()
			.select("app-create-container")
			.select("app-realtime-container-telematic-keys");
	}

	default String findRegressionContainerAndGetContainerId() {
		return locateRegressionContainer(getTestingContainerTitle())
			.select("td")
			.nth(1)
			.textContent();
	}

	default void findRegressionContainerAndViewDetails() {
		locateRegressionContainer(getTestingContainerTitle())
			.select("i.anticon-eye")
			.click();
	}

	default void findRegressionContainerAndDelete() {
		locateRegressionContainer(getTestingContainerTitle())
			.select("i.anticon-delete")
				.click();
		waitForContainerDelete(() -> {
			locateButton("Ok").click();
		});
	}

	default LocatorHandle locateRegressionContainer(String containerTitle) {
		return locateRowWithText(containerTitle);
	}

	default LocatorHandle locatePriceListLink() {
		return select("[apptranslatedcontent='portal.pricing.upper.limit']").getByText("Preisliste");
	}

	default LocatorHandle locateCarDataBody() {
		return select("app-car-data");
	}

	default LocatorHandle locateContainerDetailHeader() {
		return locateCarDataBody().select("app-container-detail-info");
	}

	default void assertTelematicCatalogueValue(String key, int columnIndex, String expect) {
		assertEquals(expect, locateTelematicCatalogueRowCell(key, columnIndex).textContent());
	}

	default LocatorHandle locateTelematicCatalogueRowCell(String key, int cell) {
		// are we testing the correct thing here?
		return locateContainerDetailCostSummary().locateRow(key).select("td").nth(cell);
	}

	default LocatorHandle locateContainerDetailCostSummary() {
		return locateCarDataBody().select("app-container-cost-summary");
	}

	default void assertTelematicKeyCreationSummaryValue(String key, int columnIndex, String expect) {
		assertEquals(expect, locateTelematicKeyCreationSummaryRowCell(key, columnIndex).textContent());
	}

	default LocatorHandle locateTelematicKeyCreationSummaryRowCell(String key, int cell) {
		return locateContainerCreationCostSummary().locateRow(key).select("td").nth(cell);
	}

	default LocatorHandle locateContainerCreationCostSummary() {
		return locateCarDataBody().select("app-realtime-telematic-keys-summary");
	}

	default LocatorHandle locateButtonBackToOverview() {
		return locateButton("Zurück zur Übersicht");
	}

	default void waitForContainers(Runnable triggerRequest) {
		String url = getStage().urls().thirdPartyPortalBase() + "/api/v1/containers";
		waitForResponse(url, triggerRequest);
	}

	default void waitForContainerDelete(Runnable triggerRequest) {
		String url = getStage().urls().thirdPartyPortalBase() + "/api/v1/containers/*";
		waitForResponse(url, triggerRequest);
	}

	default void waitForThirdParty(Runnable triggerRequest) {
		String url = getStage().urls().thirdPartyPortalBase() + "/api/v1/thirdparty";
		waitForResponse(url, 40_000, triggerRequest);
	}
}
