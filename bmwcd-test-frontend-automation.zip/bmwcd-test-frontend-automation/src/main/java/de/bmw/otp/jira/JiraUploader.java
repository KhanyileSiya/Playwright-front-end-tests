package de.bmw.otp.jira;

import de.bmw.otp.jira.model.JiraIssue;
import de.bmw.otp.jira.model.UploadResult;
import de.bmw.otp.tests.EnvVar;
import de.bmw.otp.tests.Utils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

public record JiraUploader(AtcJiraClient client, Path resultsFolder) {
	private static final String JIRA_USER = "QDBBBA2";

	public static void main(String[] args) throws IOException {
		var cwd = new File(".");
		var testsFolder = cwd.toPath().resolve("results");
		var uploader = new JiraUploader(new AtcJiraClient(getAuthentication()), testsFolder);
		uploader.findAndUploadAll();
	}

	private static String getAuthentication() {
		return EnvVar.JIRA_PASSWORD.val()
			.map(pw -> "Basic " + Base64.getEncoder().encodeToString((JIRA_USER + ":" + pw).getBytes()))
			.or(() -> EnvVar.JIRA_PAT.val().map(pat -> "Bearer " + pat))
			.orElseThrow(() -> new NoSuchElementException("Either jira_password or JIRA_PAT must be set"));
	}

	private void findAndUploadAll() throws IOException {
		// Create a unique upload folder each run
		Path uniqueUploadFolder = createUniqueUploadFolder();

		var reports = findReports();
		System.out.println(reports);
		for (File report : reports) {
			try {
				uploadSingleReport(report, uniqueUploadFolder);
			} catch (IOException | InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private List<File> findReports() throws IOException {
		System.out.println("testFolder=" + resultsFolder.toFile().getAbsolutePath());
		return Files.list(resultsFolder)
			.map(Path::toFile)
			.filter(f -> f.exists() && f.isFile() && f.getName().startsWith("TEST-") && f.getName().endsWith(".xml"))
			.toList();
	}

	private void uploadSingleReport(File report, Path uniqueUploadFolder) throws IOException, InterruptedException {
		var reportXml = Files.readString(report.toPath());

		// Add timestamp suffix to avoid overwriting Jira test executions
		String uniqueReportName = report.getName().replace(".xml", "") + "-" +
			LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".xml";

		var result = this.client.uploadReport(uniqueReportName, reportXml);
		updateTestIssueDescription(result, reportXml);
		cleanupAfterUpload(report, uniqueUploadFolder);
	}

	private void updateTestIssueDescription(UploadResult result, String reportXml) {
		try {
			XrayReportParser.XrayReport report = new XrayReportParser().parse(reportXml);
			for (JiraIssue uploaded : result.testIssues().success()) {
				var summary = client.requestSummary(uploaded);
				findInReportBySummary(report.testcase, summary)
					.forEach(found -> findAndUploadEvidence(uploaded, found, summary));
			}
		} catch (Exception e) {
			System.err.println(e);
		}
	}

	private Stream<XrayReportParser.XrayTestCase> findInReportBySummary(List<XrayReportParser.XrayTestCase> testcases, String summary) {
		return testcases.stream().filter(testCase -> Objects.equals(testCase.name, summary));
	}

	// Upload evidence for both passed and failed testcases
	private void findAndUploadEvidence(JiraIssue uploaded, XrayReportParser.XrayTestCase testcase, String summary) {
		System.out.println("uploading evidence for " + summary);
		ignoreException(() -> {
			// Don’t delete existing attachments; just add new ones
			var screenshots = findScreenshots(resultsFolder, testcase);
			if (!screenshots.isEmpty()) {
				client.uploadJpeg(uploaded, screenshots);
			}

			var downloads = findDownloads(resultsFolder, testcase);
			if (!downloads.isEmpty()) {
				client.uploadDownloads(uploaded, downloads);
			}
		});
	}

	private void ignoreException(Utils.ThrowingRunnable<Exception> r) {
		try {
			r.run();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	private List<File> findScreenshots(Path resultsFolder, XrayReportParser.XrayTestCase xrayTestCase) throws IOException {
		var screenshotFolder = resolveScreenshotFolder(resultsFolder, xrayTestCase);
		if (!Files.exists(screenshotFolder)) return List.of();
		try (var screenshotFiles = Files.list(screenshotFolder)) {
			return screenshotFiles.map(Path::toFile)
				.filter(file -> file.getName().endsWith(".jpg"))
				.toList();
		}
	}

	private List<File> findDownloads(Path resultsFolder, XrayReportParser.XrayTestCase xrayTestCase) throws IOException {
		var downloadsFolder = resolveDownloadsFolder(resultsFolder, xrayTestCase);
		if (!Files.exists(downloadsFolder)) return List.of();
		try (var files = Files.list(downloadsFolder)) {
			return files.map(Path::toFile).toList();
		}
	}

	private Path resolveScreenshotFolder(Path resultsFolder, XrayReportParser.XrayTestCase xrayTestCase) {
		return resolveEvidenceFolder(resultsFolder, xrayTestCase, "screenshots");
	}

	private Path resolveDownloadsFolder(Path resultsFolder, XrayReportParser.XrayTestCase xrayTestCase) {
		return resolveEvidenceFolder(resultsFolder, xrayTestCase, "downloads");
	}

	private Path resolveEvidenceFolder(Path resultsFolder, XrayReportParser.XrayTestCase xrayTestCase, String type) {
		String className = xrayTestCase.classname;
		String summary = xrayTestCase.name;
		final String methodName;
		if (summary.contains(className)) {
			methodName = summary.replace(className + "::", "");
		} else {
			methodName = summary;
		}
		return resultsFolder.resolve(type).resolve(className).resolve(methodName);
	}

	private void cleanupAfterUpload(File reportXml, Path uniqueUploadFolder) {
		ignoreException(() -> move(reportXml.toPath(), uniqueUploadFolder.resolve(reportXml.getName())));
		ignoreException(() -> moveRecursive(resultsFolder.resolve("screenshots"), uniqueUploadFolder.resolve("screenshots")));
		ignoreException(() -> moveRecursive(resultsFolder.resolve("downloads"), uniqueUploadFolder.resolve("downloads")));
	}

	private void move(Path src, Path dst) throws IOException {
		Files.move(src, dst, StandardCopyOption.REPLACE_EXISTING);
	}

	private void moveRecursive(Path src, Path dst) throws IOException {
		if (src.toFile().exists()) {
			Utils.deleteRecursive(dst);
			move(src, dst);
		}
	}

	private Path createUniqueUploadFolder() throws IOException {
		String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
		Path folder = this.resultsFolder.resolve("uploaded_" + timestamp);
		Files.createDirectories(folder);
		return folder;
	}
}
