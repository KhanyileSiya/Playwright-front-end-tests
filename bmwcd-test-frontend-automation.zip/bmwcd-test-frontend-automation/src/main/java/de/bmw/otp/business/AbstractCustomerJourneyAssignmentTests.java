package de.bmw.otp.business;

import de.bmw.otp.tests.WithCleanup;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;

import java.util.List;

public abstract class AbstractCustomerJourneyAssignmentTests extends ThirdPartyBase implements CustomerPortalAssignmentHelper {

	@Override
	public String getSutVin() {
		return getVinPairOfStage().vin();
	}

	@BeforeAll
	static void setUpAll() {
		baseSetUpAll();
	}

	@BeforeEach
	void setUpEach(TestInfo testInfo) {
		getAssignmentClient().revokeAllAssignments(getSutVin());
		baseSetUp(getStage(), testInfo);
	}

	@AfterEach
	void tearDownEach() {
		baseTearDown();
	}

	@AfterAll
	static void tearDownAll() {
		baseTearDownAll();
	}

	@Test
	public void testContentDataAndServiceAccessPermissions() {
		openPageAndLoginAndSelectVin(getSutVin());

		locateServicefreigaben().assertVisible();
		locateServicefreigabenText().assertVisible();

		var parentElementAssignment = locateAssignmentTile().first();
		List<String> paragraphTextsAssignment = parentElementAssignment.select("p").allTextContents();
		for (String text : paragraphTextsAssignment) {
			log("Paragraph text: " + text);
		}
	}

	@Test
	public void testRequestAndRejectAssignmentAndGetStatus() {
		try (var assignment = this.assignmentRequestAndLogin()) {
			String assignmentUuid = assignment.val();

			rejectAssignment(assignmentUuid);
			assertAssignmentStatusRejected(assignmentUuid);
		}
	}

	@Test
	public void testAssignmentDisplayData() {
		try (var assignment = this.assignmentRequestAndLogin()) {
			String assignmentUuid = assignment.val();

			verifyAssignmentDetails(getStatusNew());

			acceptAssignment(assignmentUuid);
			verifyAssignmentDetails(getStatusAccepted());
		}
	}

	@Test
	public void testApproveAssignmentAndCancelRevoke() {
		try (var assignment = this.assignmentRequestAndLogin()) {
			String assignmentUuid = assignment.val();

			acceptAssignment(assignmentUuid);
			assertAssignmentStatusAccepted(assignmentUuid);

			cancelRevokeAssignment();
			assertAssignmentStatusAccepted(assignmentUuid);
		}
	}

	@Test
	public void testCheckAssignmentDetailsAndRejectAssignment() {
		try (var assignment = this.assignmentRequestAndLogin()) {
			String assignmentUuid = assignment.val();

			rejectAssignment(assignmentUuid);
			verifyAssignmentDetails(getStatusRejected());
			assertAssignmentStatusRejected(assignmentUuid);
		}
	}

	@Test
	public void testRevokeAssignmentAndGetStatus() {
		try (var assignment = this.assignmentRequestAndLogin()) {
			String assignmentUuid = assignment.val();

			acceptAssignment(assignmentUuid);
			//TODO Defect (already communicated with UAT): this fails for RR, as the status only goes to ACCEPTED and never changes to ACTIVE as other platforms do.
			assertAssignmentStatusAccepted(assignmentUuid);

			revokeAssignment(assignmentUuid);
			verifyAssignmentDetails(getStatusRevoked());
			assertAssignmentStatusRevoked(assignmentUuid);
		}
	}


	private WithCleanup<String> assignmentRequestAndLogin() {
		return WithCleanup.then(
			assignmentRequest(),
			() -> openPageAndLoginAndSelectVin(getSutVin()));
	}
}
