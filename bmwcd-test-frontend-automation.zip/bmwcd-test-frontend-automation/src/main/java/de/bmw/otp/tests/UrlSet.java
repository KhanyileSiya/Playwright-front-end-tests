package de.bmw.otp.tests;

public record UrlSet(
	String cardataApi,
	String msClearance,
	String thirdPartyPortalBase,
	String myBmwBase,
	String myMiniBase,
	String myRollsRoyceBase,
	String myToyotaBase
) {}
