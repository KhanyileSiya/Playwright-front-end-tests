package de.bmw.otp.business;

import de.bmw.otp.exve.invoker.ApiException;
import de.bmw.otp.exve.model.ExveTelematicValue;
import de.bmw.otp.tests.Utils;
import de.bmw.otp.tests.WithCleanup;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Map;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.not;

public abstract class AbstractDataRetrievalIndependentRegressionTests extends ThirdPartyBase implements CustomerPortalClearanceHelper, ThirdPartyPortalTests, ErrorHelper {

	@Override
	public String getSutVin() {
		return getVinPairOfStage().vin();
	}

	private static final String TESTING_CONTAINER_TITLE = Utils.withIdTrimmed("Playwright Regression ", 30);

	@Override
	public String getTestingContainerTitle() {
		return TESTING_CONTAINER_TITLE;
	}

	@BeforeAll
	static void setUpAll() {
		baseSetUpAll();
	}

	@BeforeEach
	void setUpEach(TestInfo testInfo) {
		baseSetUp(getStage(), testInfo);
	}

	@AfterEach
	void tearDownEach() {
		baseTearDown();
	}

	@AfterAll
	static void tearDownAll() {
		baseTearDownAll();
	}

	@Test
	void testRequestedClearanceDetailsPage() {
		try (var clearance = createContainerAndRequestClearance()) {
			var clearanceId = clearance.val().clearanceId();

			openPageAndLoginAndSelectVin(getSutVin());
			verifyClearanceDetails(getTestingContainerTitle(), getStatusNew());

			acceptClearance(clearanceId, getTestingContainerTitle());
			verifyClearanceDetails(getTestingContainerTitle(), getStatusAccepted());
		}
	}

	@Test
	void testRequestTelematicData() {
		try (var clearance = createContainerAndRequestClearanceAndOpenCustomerPortalAndAccept()) {
			var clearanceId = clearance.val().clearanceId();

			var telematicData = getClearanceClient().requestTelematicData(clearanceId, getSutVin());
			log(telematicData.toString());
		}
	}

	@Test
	void testRequestSpecificTelematicData() {
		try (var clearance = createContainerAndRequestClearanceAndOpenCustomerPortalAndAccept()) {
			var clearanceId = clearance.val().clearanceId();

			var telematicData = getClearanceClient().requestTelematicData(clearanceId, getSutVin(), "Vehicle.Vehicle.TravelledDistance");
			log(telematicData.toString());
		}
	}

	@Test
	void testRequestBasicVehicleData() {
		try (var clearance = createContainerAndRequestClearanceAndOpenCustomerPortalAndAccept()) {
			var clearanceId = clearance.val().clearanceId();

			var telematicData = getClearanceClient().requestVehicleInformation(clearanceId, getSutVin());
			log(telematicData.toString());
		}
	}

	@Test
	void testRequestVehicleImage() {
		try (var clearance = createContainerAndRequestClearanceAndOpenCustomerPortalAndAccept()) {
			var clearanceId = clearance.val().clearanceId();

			var response = getClearanceClient().requestVehicleImage(clearanceId, getSutVin());
			log(response.toString());
		}
	}

	@Test
	void testRequestTyreDiagnosis() {
		try (var clearance = createContainerAndRequestClearanceAndOpenCustomerPortalAndAccept()) {
			var clearanceId = clearance.val().clearanceId();

			var response = getClearanceClient().tyreDiagnosisDataRequest(clearanceId, getSutVin());
			log(response.toString());
		}
	}

	@Test
	void testRequestChargingHistory() {
		try (var clearance = createContainerAndRequestClearanceAndOpenCustomerPortalAndAccept()) {
			var clearanceId = clearance.val().clearanceId();

			var from = LocalDate.now().minusDays(60);
			var response = getClearanceClient().getChargingHistoryForClearanceId(clearanceId, getSutVin(), from);
			log(response.toString());
		}
	}

	@Test
	void testRevokeApprovedClearanceAndRequestTelematicData() {
		try (var clearance = createContainerAndRequestClearanceAndOpenCustomerPortalAndAccept()) {
			var clearanceId = clearance.val().clearanceId();

			revokeClearance(clearanceId, getTestingContainerTitle());

			var e = Assertions.assertThrows(ApiException.class, () -> {
				getClearanceClient().requestTelematicData(clearanceId, getSutVin());
			});

			MatcherAssert.assertThat(e.getCode(), equalTo(403));
			assertErrorCode(e.getResponseBody(), "TP-107");
			MatcherAssert.assertThat(e.getResponseBody(), containsString("\"exveErrorId\":\"TP-107\""));
		}
	}

	@Test
	void testDeleteClearance() {
		try (var clearance = createContainerAndRequestClearanceAndOpenCustomerPortalAndAccept()) {
			var clearanceId = clearance.val().clearanceId();
			var containerId = clearance.val().containerId();

			checkTelematicData(requestTelematicDataAndAssert(clearanceId));

			var response = getClearanceClient().deleteClearance(containerId, getSutVin());
			log(response.toString());

			var e = Assertions.assertThrows(ApiException.class, () -> {
				// bad case
				requestTelematicDataAndAssert(clearanceId);
			});
		}
	}

	private WithCleanup<ContainerAndClearance> createContainerAndRequestClearanceAndOpenCustomerPortalAndAccept() {
		return WithCleanup.then(createContainerAndRequestClearance(), clearance -> {
			var clearanceId = clearance.clearanceId();
			openPageAndLoginAndSelectVin(getSutVin());
			acceptClearance(clearanceId, getTestingContainerTitle());
		});
	}

	private void checkTelematicData(Map<String, ExveTelematicValue> telematicData) {
		logMethodCall(telematicData.toString());
		MatcherAssert.assertThat(telematicData, not(equalTo(Collections.EMPTY_MAP)));
		//TODO: more checks for example: vehicle.vehicle.avgSpeed": {
		//            "timestamp": null,
		//            "unit": "km/h",
		//            "value": null
	}

	private Map<String, ExveTelematicValue> requestTelematicDataAndAssert(String clearanceId) {
		return getClearanceClient().requestTelematicData(clearanceId, getSutVin());
	}
}
