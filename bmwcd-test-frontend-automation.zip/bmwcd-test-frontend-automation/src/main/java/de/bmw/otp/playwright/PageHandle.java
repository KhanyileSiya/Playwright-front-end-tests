package de.bmw.otp.playwright;

import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitUntilState;
import de.bmw.otp.tests.LoggingHelper;

public class PageHandle implements AutoCloseable {
	private final LoggingHelper log;
	private Page page;

	public PageHandle(LoggingHelper log, Page page) {
		this.log = log;
		this.page = page;
	}

//	Page getPage() {
//		return this.page;
//	}

	public Page getPage() {
		return this.page;
	}

	public String getUrl() {
		return page.url();
	}

	public String getContent() {
		return page.content();
	}

	public boolean hasText(String text) {
		return page.locator("text=" + text).count() > 0;
	}

	@Override
	public void close() {
		this.page.close();
		this.page = null;
	}

	public void reload() {
		page.reload(new Page.ReloadOptions().setWaitUntil(WaitUntilState.DOMCONTENTLOADED));
	}

	public void navigate(String url) {
		log.logMethodCall(url);
		page.navigate(url, defaultNavOptions());
	}

	public void navigate(String url, double timeout) {
		log.logMethodCall(url, String.valueOf(timeout));
		page.navigate(url, defaultNavOptions().setTimeout(timeout));
	}

	private Page.NavigateOptions defaultNavOptions() {
		return new Page.NavigateOptions().setWaitUntil(WaitUntilState.DOMCONTENTLOADED);
	}

	public void sleep(long millis) {
		log.logMethodCall(String.valueOf(millis));
		page.waitForTimeout(millis);
	}
}
