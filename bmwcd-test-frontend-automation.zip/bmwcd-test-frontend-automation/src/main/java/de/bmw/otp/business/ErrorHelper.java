package de.bmw.otp.business;

import com.fasterxml.jackson.databind.ObjectMapper;
import de.bmw.otp.exve.model.ExveErrorDto;
import org.junit.jupiter.api.Assertions;

import java.util.Optional;

public interface ErrorHelper {

	default void assertErrorCode(String body, String expected) {
		var error = parseError(body).orElseThrow();
		assertErrorCode(error, expected);
	}

	default void assertErrorCode(ExveErrorDto error, String expected) {
		Assertions.assertEquals(expected, error.getExveErrorId());
	}

	default Optional<ExveErrorDto> parseError(String body) {
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			ExveErrorDto error = objectMapper.readValue(body, ExveErrorDto.class);
			return Optional.of(error);
		} catch (Exception e) {
			return Optional.empty();
		}
	}

}
