package de.bmw.otp.jira.model;

import java.util.List;

public record UploadResult(JiraIssue testExecIssue,
						   JiraTestIssue testIssues,
						   List<String> infoMessages) {
}
