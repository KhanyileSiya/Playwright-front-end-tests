package de.bmw.otp.jira;

import com.fasterxml.jackson.core.JsonProcessingException;
import de.bmw.otp.jira.model.JiraAttachment;
import de.bmw.otp.jira.model.JiraIssue;
import de.bmw.otp.jira.model.JiraSummary;
import de.bmw.otp.jira.model.UploadResult;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class AtcJiraClient {
	//	private static final String JIRA_URL = "http://localhost:12345";
	private static final String JIRA_URL = "https://atc.bmwgroup.net/jira";
	private static final String JIRA_PROJECT_KEY = "CARDATA";
	private static final String JIRA_PROJECT_ID = "35615";
	private static final String JIRA_TEST_EXECUTION_ISSUE_TYPE_ID = "10402";
	private static final String JIRA_SUMMARY = "CarData automated frontend tests (Playwright)";
	private static final String JIRA_FEATURE_TEAM_ID = "224055";
	private static final String JIRA_TEST_DESCRIPTION = "No description provided";

	private final JiraApi api;

	public AtcJiraClient(String authentication) {
		this.api = new JiraApi(JIRA_URL, authentication);
	}

	public UploadResult uploadReport(String reportName, String xml) throws IOException, InterruptedException {
		var result = this.api.uploadReport(reportName, xml, JIRA_PROJECT_KEY, getTestExecInfoJson(), getTestInfoJson());
		var key = result.testExecIssue().key();
		System.out.println("link=" + JIRA_URL + "/browse/" + key);
		if (result.testIssues().error() != null && !result.testIssues().error().isEmpty()) {
			throw new RuntimeException("Not all test cases could be uploaded: " + result);
		}
		return result;
	}

	public String requestSummary(JiraIssue issue) throws InterruptedException, JsonProcessingException {
		return this.api.requestSummary(issue.self())
			.body()
			.fields()
			.summary();
	}

	public Object uploadJpeg(JiraIssue issue, List<File> images) throws IOException, InterruptedException {
		return this.api.uploadJpeg(issue.key(), images);
	}

	public Object uploadDownloads(JiraIssue issue, List<File> files) throws IOException, InterruptedException {
		return this.api.uploadBinary(issue.key(), files);
	}

	public void deleteAllAttachments(JiraIssue issue) throws InterruptedException, JsonProcessingException {
		JiraSummary withAttachments = this.api.requestAttachments(issue.self()).body();
		for (JiraAttachment attachment : withAttachments.fields().attachment()) {
			this.api.deleteAttachment(attachment.self());
		}
	}

	private String getTestInfoJson() {
		String description = JIRA_TEST_DESCRIPTION;
		String customField11400Id = JIRA_FEATURE_TEAM_ID;
		return """
{
	"fields": {
		"description": "%s",
		"customfield_11400": [
			{ "id": "%s" }
		]
	}
}
			""".formatted(description, customField11400Id);
	}

	private String getTestExecInfoJson() {
		var projectId = JIRA_PROJECT_ID;
		var issueTypeId = JIRA_TEST_EXECUTION_ISSUE_TYPE_ID;
		var summary = JIRA_SUMMARY;
		var customField11400Id = JIRA_FEATURE_TEAM_ID;
		return """
{
	"fields": {
		"project": {
			"id": "%s"
		},
		"issuetype": {
			"id": "%s"
		},
		"summary": "%s",
		"customfield_11400": [
			{ "id": "%s" }
		]
	}
}
"""
			.formatted(projectId, issueTypeId, summary, customField11400Id);
	}
}
