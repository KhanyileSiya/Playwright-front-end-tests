package de.bmw.otp.tests.api;

import de.bmw.otp.exve.api.AssignmentsApi;
import de.bmw.otp.exve.model.AssignmentVehicleDto;
import de.bmw.otp.exve.model.ExVeCreateAssignmentRequestDto;
import de.bmw.otp.tests.CardataStage;
import de.bmw.otp.tests.LoggingHelper;
import de.bmw.otp.tests.WithCleanup;

import java.util.List;
import java.util.Optional;

public class AssignmentClient extends ClientBase {
	private final AssignmentsApi api;
	private final LoggingHelper log;

	public AssignmentClient(CardataStage stage, LoggingHelper log) {
		this.log = log;
		var tokenClient = makeTokenClient(stage);
		var currentAccessToken = tokenClient.getAccessToken();
		var apiClient = makeApiClient(stage, () -> currentAccessToken);
		api = new AssignmentsApi(apiClient);
	}

	public WithCleanup<String> requestAssignmentWithCleanup(String vin) {
		return new WithCleanup<>(requestAssignment(vin), this::revokeAssignmentNoThrow);
	}

	private String requestAssignment(String vin) {
		log.logMethodCall(vin);
		return api.addAssignmentRequest(vin, new ExVeCreateAssignmentRequestDto()
			.serviceType(ExVeCreateAssignmentRequestDto.ServiceTypeEnum.SERVICE_PARTNER)
			.message("Playwright Regression Test"), "IMMEDIATE"
		).getAssignmentUuid();
	}

	public void revokeAssignmentNoThrow(String uuid) {
		log.logMethodCall(uuid);
		try {
			revokeAssignment(uuid);
		} catch (Exception e) {
			System.err.println("WARN: error revoking assignment uuid=" + uuid);
		}
	}

	public void revokeAssignment(String uuid) {
		log.logMethodCall(uuid);
		api.revokeAssignmentRequestAsProviderById(uuid);
	}

	public String getAssignmentStatus(String uuid) {
		log.logMethodCall(uuid);
		return api.findAssignmentRequestStatus(uuid).getStatus();
	}

	public List<AssignmentVehicleDto> getAllAssignments() {
		var response = api.findAllAssignmentRequestStatusByServiceType(ExVeCreateAssignmentRequestDto.ServiceTypeEnum.SERVICE_PARTNER.getValue());
		return Optional.ofNullable(response)
			.flatMap(res -> Optional.ofNullable(res.getVehicles()))
			.orElse(List.of());
	}

	public void revokeAllAssignments(String vin) {
		log.logMethodCall(vin);
		var allAssignments = getAllAssignments();
		try {
			for (AssignmentVehicleDto assignment : allAssignments) {
				if (!vin.equals(assignment.getVin())) {
					continue;
				}
				if (List.of("REQUESTED", "ACCEPTED", "ACTIVE").contains(assignment.getAssignmentState())) {
					revokeAssignmentNoThrow(assignment.getAssignmentId());
				}
			}
		} catch(Exception e) {
			System.err.println("WARN: error revoking assignments" + e.getMessage());
		}
	}
}
