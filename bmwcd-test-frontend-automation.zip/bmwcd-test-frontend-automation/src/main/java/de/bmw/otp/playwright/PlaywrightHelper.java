package de.bmw.otp.playwright;

import com.microsoft.playwright.Download;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.TimeoutError;
import com.microsoft.playwright.options.AriaRole;
import com.microsoft.playwright.options.LoadState;
import com.microsoft.playwright.options.ScreenshotType;
import de.bmw.otp.tests.EnvVar;
import de.bmw.otp.tests.LoggingHelper;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import java.util.function.Supplier;

public interface PlaywrightHelper extends LoggingHelper {

	PageHandle getPage();

	Optional<String> testClass();
	String testMethod();

	default void screenshot(String reason) {
		if (EnvVar.DEBUG_LOGGING.isTrue()) {
			System.out.println("screenshot");
		}
		getPage().getPage().waitForLoadState(LoadState.DOMCONTENTLOADED);
		var fileName = "screenshot_%d_%s.jpg".formatted(System.currentTimeMillis(), reason);
		var file = getScreenshotFolder().resolve(fileName);
		getPage().getPage().screenshot(new Page.ScreenshotOptions()
			.setType(ScreenshotType.JPEG)
			.setPath(file)
			.setFullPage(true));
	}

	default void preLocatorHook() {
	}

	default void postLocatorHook() {
	}

	default void onTimeout(TimeoutError e) {
		screenshot("timeout");
	}

	default <T> T locateInternal(Supplier<T> locator) {
		try {
			preLocatorHook();
			var result = locator.get();
			postLocatorHook();
			return result;
		} catch (TimeoutError e) {
			e.printStackTrace();
			onTimeout(e);
			throw new RuntimeException(e);
		}
	}

	default File download(Runnable triggerDownload) {
		Download download = getPage().getPage().waitForDownload(triggerDownload);
		var parent = getDownloadFolder();
		var localPath = parent.resolve(download.suggestedFilename());
		download.saveAs(localPath);
		return localPath.toFile();
	}

	default Path getDownloadFolder() {
		return getEvidenceFolder(Path.of("downloads"));
	}

	default Path getScreenshotFolder() {
		return getEvidenceFolder(Path.of("screenshots"));
	}

	default Path getEvidenceFolder(Path type) {
		try {
			var testCaseDir = testClass().orElse("unknown_class");
			var parent = Path.of("results").resolve(type).resolve(testCaseDir).resolve(testMethod());
			Files.createDirectories(parent);
			return parent;
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	default LocatorHandle select(String selector) {
		try {
			return toHandle(getPage().getPage().locator(selector));
		} catch (PlaywrightException e) {
			throw new MyPlaywrightException(e);
		}
	}

	default LocatorHandle getByTestId(String testId) {
		try {
			return toHandle(getPage().getPage().getByTestId(testId));
		} catch (PlaywrightException e) {
			throw new MyPlaywrightException(e);
		}
	}

	default LocatorHandle getByText(String text) {
		return toHandle(getPage().getPage().getByText(text));
	}

	default LocatorHandle getByText(String text, boolean exact) {
		if(exact){
			return toHandle(getPage().getPage().getByText(text, new Page.GetByTextOptions().setExact(true)));
		}
		return getByText(text);
	}


	default LocatorHandle getByRole(AriaRole role) {
		return toHandle(getPage().getPage().getByRole(role));
	}

	default LocatorHandle getRoleLink() {
		return getByRole(AriaRole.LINK);
	}

	default LocatorHandle getCheckbox() {
		return getByRole(AriaRole.CHECKBOX);
	}

	default void waitForResponse(String urlOrPredicate, Runnable triggerRequest) {
		locateInternal(() -> getPage().getPage().waitForResponse(urlOrPredicate, triggerRequest));
	}
	default void waitForResponse(String urlOrPredicate, int timeoutMillis, Runnable triggerRequest) {
		locateInternal(() -> getPage().getPage().waitForResponse(urlOrPredicate, new Page.WaitForResponseOptions().setTimeout(timeoutMillis), triggerRequest));
	}

	default void waitForSelector(String selector) {
		locateInternal(() -> getPage().getPage().waitForSelector(selector));
	}

	default PageHandle waitForPopup(Runnable callback) {
		return new PageHandle(this, getPage().getPage().waitForPopup(callback));
	}

	default LocatorHandle locateButton(String name) {
		return new LocatorHandle(this, getPage().getPage().getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName(name)));
	}

	default LocatorHandle locateElementWithText(String element, String text) {
		return this.select("%s:has-text('%s')".formatted(element, text));
	}

	default LocatorHandle locateClassWithText(String clazz, String text) {
		return this.select(".%s:has-text('%s')".formatted(clazz, text));
	}

	default LocatorHandle locateRowWithText(String text) {
		return getByRole(AriaRole.ROW).filterHasText(text);
	}

	default double getNavigationTimeout() {
		return EnvVar.NAVIGATION_TIMEOUT.toInt().orElse(30_000);
	}

	default double getLocatorTimeout() {
		return EnvVar.LOCATOR_TIMEOUT.toInt().orElse(30_000);
	}

	default LocatorHandle toHandle(Locator loc) {
		return new LocatorHandle(this, loc);
	}

}
