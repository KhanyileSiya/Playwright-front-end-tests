package de.bmw.otp.jira.model;

public record JiraIssue(String id, String key, String self, long testVersionId) {
}
