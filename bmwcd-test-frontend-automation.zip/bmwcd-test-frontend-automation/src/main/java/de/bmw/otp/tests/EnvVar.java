package de.bmw.otp.tests;

import java.util.NoSuchElementException;
import java.util.Optional;

public enum EnvVar {
	CARDATA_STAGE("CARDATA_STAGE"),
	SIMULATOR_STAGE("SIMULATOR_STAGE"),
	JIRA_PASSWORD("jira_password"),
	JIRA_PAT("JIRA_PAT"),
	IS_CI("IS_CI"),

	CARDATA_CLIENT_ID_INT("CARDATA_CLIENT_ID_INT"),
	CARDATA_CLIENT_SECRET_INT("CARDATA_CLIENT_SECRET_INT"),
	CARDATA_CLIENT_ID_E2E("CARDATA_CLIENT_ID_E2E"),
	CARDATA_CLIENT_SECRET_E2E("CARDATA_CLIENT_SECRET_E2E"),
	CARDATA_CLIENT_ID_PROD("CARDATA_CLIENT_ID_PROD"),
	CARDATA_CLIENT_SECRET_PROD("CARDATA_CLIENT_SECRET_PROD"),

	CLEARANCE_BACKEND_USER_INT("CLEARANCE_BACKEND_USER_INT"),
	CLEARANCE_BACKEND_PW_INT("CLEARANCE_BACKEND_PW_INT"),
	CLEARANCE_BACKEND_USER_E2E("CLEARANCE_BACKEND_USER_E2E"),
	CLEARANCE_BACKEND_PW_E2E("CLEARANCE_BACKEND_PW_E2E"),
	CLEARANCE_BACKEND_USER_PROD("CLEARANCE_BACKEND_USER_PROD"),
	CLEARANCE_BACKEND_PW_PROD("CLEARANCE_BACKEND_PW_PROD"),

	THIRD_PARTY_ID_INT("THIRD_PARTY_ID_INT"),
	THIRD_PARTY_ID_E2E("THIRD_PARTY_ID_E2E"),
	THIRD_PARTY_ID_PROD("THIRD_PARTY_ID_PROD"),

	THIRD_PARTY_PORTAL_USER_E2E("THIRD_PARTY_PORTAL_USER_E2E"),
	THIRD_PARTY_PORTAL_PW_E2E("THIRD_PARTY_PORTAL_PW_E2E"),
	THIRD_PARTY_PORTAL_USER_PROD("THIRD_PARTY_PORTAL_USER_PROD"),
	THIRD_PARTY_PORTAL_PW_PROD("THIRD_PARTY_PORTAL_PW_PROD"),

	THIRD_PARTY_SIM_USER_TEST("THIRD_PARTY_SIM_USER_TEST"),
	THIRD_PARTY_SIM_PW_TEST("THIRD_PARTY_SIM_PW_TEST"),
	THIRD_PARTY_SIM_USER_PROD("THIRD_PARTY_SIM_USER_PROD"),
	THIRD_PARTY_SIM_PW_PROD("THIRD_PARTY_SIM_PW_PROD"),

	CUSTOMER_PORTAL_USER_NAME_E2E("CUSTOMER_PORTAL_USER_NAME_E2E"),
	CUSTOMER_PORTAL_PASSWORD_E2E("CUSTOMER_PORTAL_PASSWORD_E2E"),
	CUSTOMER_PORTAL_USER_NAME_PROD("CUSTOMER_PORTAL_USER_NAME_PROD"),
	CUSTOMER_PORTAL_PASSWORD_PROD("CUSTOMER_PORTAL_PASSWORD_PROD"),

	CUSTOMER_PORTAL_BASIC_USER_NAME_E2E("CUSTOMER_PORTAL_BASIC_USER_NAME_E2E"),
	CUSTOMER_PORTAL_BASIC_PASSWORD_E2E("CUSTOMER_PORTAL_BASIC_PASSWORD_E2E"),

	LOCATOR_TIMEOUT("LOCATOR_TIMEOUT", false),
	NAVIGATION_TIMEOUT("NAVIGATION_TIMEOUT", false),
	REQUEST_LOGGING("REQUEST_LOGGING", false),
	DEBUG_LOGGING("DEBUG_LOGGING", false),
	BROWSER_LOGGING("BROWSER_LOGGING", false),
	HEADLESS("HEADLESS", false);

	private final String name_;
	private final boolean mandatory;

	EnvVar(String name) {
		this(name, true);
	}

	EnvVar(String name, boolean mandatory) {
		this.name_ = name;
		this.mandatory = mandatory;
	}

	public Optional<String> val() {
		return Optional.ofNullable(System.getenv(this.name_))
			.filter(val -> !val.isEmpty())
			.or(() -> {
				if (this.mandatory) {
					System.err.println("WARN: Environment variable is requested but undefined: " + this.name_);
				}
				return Optional.empty();
			});
	}

	public String valOrThrow() {
		return val().orElseThrow(() -> new NoSuchElementException("Missing environment variable: " + this.name_));
	}

	public boolean isTrue() {
		return this.val().map("true"::equalsIgnoreCase).orElse(false);
	}

	public boolean isFalse() {
		return !isTrue();
	}

	public Optional<Integer> toInt() {
		return val().flatMap(str -> {
			try {
				return Optional.of(Integer.parseInt(str));
			} catch (Exception e) {
				return Optional.empty();
			}
		});
	}
}
