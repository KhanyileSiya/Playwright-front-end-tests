package de.bmw.otp.business;

import de.bmw.otp.tests.Utils;
import de.bmw.otp.tests.WithCleanup;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;

import java.util.List;


public abstract class AbstractCustomerJourneyClearanceTests extends ThirdPartyBase implements CustomerPortalClearanceHelper, ThirdPartyPortalTests {

	@Override
	public String getSutVin() {
		return getVinPairOfStage().vin();
	}

	private static final String TESTING_CONTAINER_TITLE = Utils.withIdTrimmed("Playwright Reset Account ", 30);

	@Override
	public String getTestingContainerTitle() {
		return TESTING_CONTAINER_TITLE;
	}

	@BeforeAll
	static void setUpAll() {
		baseSetUpAll();
	}

	@BeforeEach
	void setUpEach(TestInfo testInfo) {
		baseSetUp(getStage(), testInfo);
	}

	@AfterEach
	void tearDownEach() {
		baseTearDown();
	}

	@AfterAll
	static void tearDownAll() {
		baseTearDownAll();
	}

	@Test
	public void testContentDataAndServiceAccessPermissions() {
		openPageAndLoginAndSelectVin(getSutVin());

		locateAccessPermission().assertVisible();
		locateAccessPermissionText().assertVisible();

		List<String> paragraphTextsClearance = locateClearanceTiles()
			.first()
			.select("p")
			.allTextContents();
		for (String text : paragraphTextsClearance) {
			log("Paragraph text: " + text);
		}
	}

	@Test
	public void testCancelRejectClearanceAndCheckDetails() {
		try (var clearance = createContainerAndRequestClearance()) {
			var clearanceId = clearance.val().clearanceId();

			openPageAndLoginAndSelectVin(getSutVin());
			assertClearanceStatusRequested(clearance.val().containerId(), getSutVin(), clearanceId);
			verifyClearanceDetails(getTestingContainerTitle(), this.getStatusNew());

			cancelRejectClearance(clearanceId, getTestingContainerTitle());
			assertClearanceStatusRequested(clearance.val().containerId(), getSutVin(), clearanceId);
			verifyClearanceDetails(getTestingContainerTitle(), this.getStatusNew());
		}
	}

	@Test
	public void testRejectClearanceAndCheckDetails() {
		try (var clearance = createContainerAndRequestClearance()) {
			var clearanceId = clearance.val().clearanceId();

			openPageAndLoginAndSelectVin(getSutVin());
			assertClearanceStatusRequested(clearance.val().containerId(), getSutVin(), clearanceId);
			verifyClearanceDetails(getTestingContainerTitle(), this.getStatusNew());

			rejectClearance(clearanceId, getTestingContainerTitle());
			assertClearanceStatusRejected(clearance.val().containerId(), getSutVin(), clearanceId);
			verifyClearanceDetails(getTestingContainerTitle(), this.getStatusRejected());
		}
	}

	@Test
	public void testAcceptClearanceAndCheckDetails() {
		try (var clearance = createContainerAndRequestClearance()) {
			var clearanceId = clearance.val().clearanceId();

			openPageAndLoginAndSelectVin(getSutVin());
			assertClearanceStatusRequested(clearance.val().containerId(), getSutVin(), clearanceId);
			verifyClearanceDetails(getTestingContainerTitle(), this.getStatusNew());

			acceptClearance(clearanceId, getTestingContainerTitle());
			assertClearanceStatusApproved(clearance.val().containerId(), getSutVin(), clearanceId);
			verifyClearanceDetails(getTestingContainerTitle(), this.getStatusAccepted());
		}
	}

	@Test
	public void testCancelRevokeClearanceAndCheckDetails() {
		try (var clearance = createContainerAndRequestClearance()) {
			var clearanceId = clearance.val().clearanceId();

			openPageAndLoginAndSelectVin(getSutVin());
			assertClearanceStatusRequested(clearance.val().containerId(), getSutVin(), clearanceId);
			verifyClearanceDetails(getTestingContainerTitle(), this.getStatusNew());

			acceptClearance(clearanceId, getTestingContainerTitle());
			assertClearanceStatusApproved(clearance.val().containerId(), getSutVin(), clearanceId);
			verifyClearanceDetails(getTestingContainerTitle(), this.getStatusAccepted());

			cancelRevokeClearance(getTestingContainerTitle());
			assertClearanceStatusApproved(clearance.val().containerId(), getSutVin(), clearanceId);
			verifyClearanceDetails(getTestingContainerTitle(), this.getStatusAccepted());
		}
	}

	@Test
	public void testRevokeClearanceAndCheckDetails() {
		try (var clearance = createContainerAndRequestClearance()) {
			var clearanceId = clearance.val().clearanceId();

			openPageAndLoginAndSelectVin(getSutVin());
			assertClearanceStatusRequested(clearance.val().containerId(), getSutVin(), clearanceId);
			verifyClearanceDetails(getTestingContainerTitle(), this.getStatusNew());

			acceptClearance(clearanceId, getTestingContainerTitle());
			assertClearanceStatusApproved(clearance.val().containerId(), getSutVin(), clearanceId);
			verifyClearanceDetails(getTestingContainerTitle(), this.getStatusAccepted());

			revokeClearance(clearanceId, getTestingContainerTitle());
			assertClearanceStatusRevoked(clearance.val().containerId(), getSutVin(), clearanceId);
			verifyClearanceDetails(getTestingContainerTitle(), this.getStatusRevoked());
		}
	}

	@Test
	void testRequestTelematicData() {
		try (var clearance = createContainerAndRequestClearanceAndOpenCustomerPortalAndAccept()) {
			var clearanceId = clearance.val().clearanceId();

			var telematicData = getClearanceClient().requestTelematicData(clearanceId, getSutVin());
			log(telematicData.toString());
		}
	}

	private WithCleanup<ContainerAndClearance> createContainerAndRequestClearanceAndOpenCustomerPortalAndAccept() {
		return WithCleanup.then(createContainerAndRequestClearance(), clearance -> {
			var clearanceId = clearance.clearanceId();
			openPageAndLoginAndSelectVin(getSutVin());
			acceptClearance(clearanceId, getTestingContainerTitle());
		});
	}
}
