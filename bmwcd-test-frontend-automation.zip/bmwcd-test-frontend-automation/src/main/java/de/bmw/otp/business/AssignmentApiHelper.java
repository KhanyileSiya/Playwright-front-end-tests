package de.bmw.otp.business;

import de.bmw.otp.playwright.PlaywrightHelper;
import de.bmw.otp.tests.Utils;
import de.bmw.otp.tests.WithCleanup;
import de.bmw.otp.tests.api.AssignmentClient;
import org.junit.jupiter.api.Assertions;

import java.time.Duration;

public interface AssignmentApiHelper extends PlaywrightHelper {

	AssignmentClient getAssignmentClient();

	String getSutVin();

	default WithCleanup<String> assignmentRequest() {
		return assignmentRequest(getSutVin());
	}

	default WithCleanup<String> assignmentRequest(String vin) {
		return WithCleanup.then(
			getAssignmentClient().requestAssignmentWithCleanup(vin),
			this::assertAssignmentStatusRequested);
	}

	default void assertAssignmentStatusRequested(String uuid) {
		getAndAssertAssignmentStatus("REQUESTED", uuid);
	}

	default void assertAssignmentStatusAccepted(String uuid) {
		String ACTIVE = "ACTIVE";
		String ACCEPTED = "ACCEPTED";
		var status = getAssignmentClient().getAssignmentStatus(uuid);
		if (ACCEPTED.equals(status)) {
			System.out.println("====== assertStatusAccepted: status=ACCEPTED");
			int maxRetries = 10;
			var maxWait = Duration.ofSeconds(10);
			for (int i=0; i<maxRetries; i++) {
				status = getAssignmentClient().getAssignmentStatus(uuid);
				if (ACTIVE.equals(status)) {
					break;
				}
				long exponentialBackoffSeconds = 0x1L<<i;
				Duration waitExponentialBackoff = Duration.ofSeconds(exponentialBackoffSeconds);
				Duration waitExponentialBackoffTruncated = Utils.min(waitExponentialBackoff, maxWait);
				System.err.println("====== assertStatusAccepted: status=" + status + " Retry attempt " + i + " waiting " + waitExponentialBackoffTruncated);
				getPage().sleep(waitExponentialBackoffTruncated.toMillis());
			}
		}
		Assertions.assertEquals(ACTIVE, status);
	}

	default void assertAssignmentStatusRejected(String uuid) {
		getAndAssertAssignmentStatus("REJECTED", uuid);
	}

	default void assertAssignmentStatusRevoked(String uuid) {
		getAndAssertAssignmentStatus("REVOKED_BY_CUSTOMER", uuid);
	}

	default void getAndAssertAssignmentStatus(String expected, String uuid) {
		Assertions.assertEquals(expected, getAssignmentClient().getAssignmentStatus(uuid));
	}
}
