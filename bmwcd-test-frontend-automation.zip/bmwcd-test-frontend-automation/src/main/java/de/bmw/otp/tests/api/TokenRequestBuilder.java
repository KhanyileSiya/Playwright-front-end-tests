package de.bmw.otp.tests.api;

public interface TokenRequestBuilder {
}
