package de.bmw.otp.business;

import de.bmw.otp.playwright.LocatorHandle;
import de.bmw.otp.tests.VinPair;

import java.nio.file.Path;

public interface MyMiniHelper extends CustomerPortalHelper {

	default VinPair getVinPairOfStage() {
		return getStage().vins().myMini();
	}
	default String getClearancePopupButtonTextReject(){return "Bestätigen";}

	@Override
	default void openPageAndLogin() {
		openPageAndLogin("Weiter", "Jetzt anmelden");
		LocatorHandle buttonRejectCookies = locateClassWithText("button-text", "Cookies verbieten");
		if (buttonRejectCookies.isPresent(getNavigationTimeout())) {
			buttonRejectCookies.click();
		}
	}

	default Path getRegressionCustomerPortalFolder() {
		return getRegressionFolder().resolve("mymini");
	}

	default String getBaseUrl() {
		return getStage().urls().myMiniBase();
	}

	default void assertTransactionReportRequested() {
		assertTransactionReportRequested("MINI CarData");
	}

	default LocatorHandle locateAccessPermission() {
		return locateClassWithText("chakra-heading", "MINI CarData Datenfreigaben");
	}

	default LocatorHandle locateServicefreigaben() {
		return locateClassWithText("chakra-heading", "MINI CarData Servicefreigaben");
	}

	default void verifyClearanceDetails(String testingContainerTitle, String status) {
		verifyClearanceDetails("MINI CarData", testingContainerTitle, status);
	}

}
