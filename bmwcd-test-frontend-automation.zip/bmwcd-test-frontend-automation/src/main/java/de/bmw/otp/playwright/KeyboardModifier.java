package de.bmw.otp.playwright;

public enum KeyboardModifier {
	ALT(com.microsoft.playwright.options.KeyboardModifier.ALT);

	private final com.microsoft.playwright.options.KeyboardModifier internal_;

	KeyboardModifier(com.microsoft.playwright.options.KeyboardModifier internal) {
		internal_ = internal;
	}

	com.microsoft.playwright.options.KeyboardModifier internal() {
		return internal_;
	}
}
