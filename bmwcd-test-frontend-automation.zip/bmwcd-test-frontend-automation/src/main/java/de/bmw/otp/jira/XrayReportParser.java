package de.bmw.otp.jira;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlCData;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlText;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

public class XrayReportParser {

	public static void main(String[] args) throws IOException {
		var reportFile = new File("./results/uploaded/TEST-frontend-automation.xml");
		var report = Files.readString(reportFile.toPath());
		var reportParsed = new XrayReportParser().parse(report);
		System.out.println(reportParsed);
	}

	public XrayReport parse(String report) throws JsonProcessingException {
		XmlMapper mapper = XmlMapper.builder()
			.disable(JsonParser.Feature.IGNORE_UNDEFINED)
			.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
			.build();
		return mapper.readValue(report, XrayReport.class);
	}

	@JsonRootName("testsuite")
	public static class XrayReport {
		public String name;
		public Integer tests;
		public Integer skipped;
		public Integer failures;
		public Integer errors;
		@JacksonXmlElementWrapper(useWrapping = false)
		public List<XrayTestCase> testcase = new ArrayList<>();
	}

	public static class XrayTestCase {
		public String name;
		public String classname;
		@JacksonXmlElementWrapper(useWrapping = true, localName = "properties")
		public List<XrayProperty> property = new ArrayList<>();
		public XrayFailure failure;
	}

	public static class XrayProperty {
		public String name;
		@JacksonXmlCData
		@JacksonXmlText
		public String content;
	}

	public static class XrayFailure {
		public String type;
		public String message;
		@JacksonXmlText
		public String content;
	}
}
