package de.bmw.otp.tests.api;

import de.bmw.otp.exve.invoker.auth.OAuth;
import de.bmw.otp.exve.invoker.auth.OAuthFlow;
import okhttp3.Interceptor;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.Map;

public class RetryingOAuth extends OAuth implements Interceptor {
	public RetryingOAuth(String tokenUrl, String clientId, OAuthFlow oAuthFlow, String clientSecret, Map<String, String> parameters) {

	}

	public TokenRequestBuilder getTokenRequestBuilder() {
		return null;
	}

	@NotNull
	@Override
	public Response intercept(@NotNull Chain chain) throws IOException {
		return chain.proceed(chain.request());
	}
}
