package de.bmw.otp.jira;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

class MultipartBody {
	public record BodyPart(String name, String filename, Consumer<PrintStream> writeContent, String contentType) {
		private static final String CONTENT_TYPE_JSON = "application/json";
		private static final String CONTENT_TYPE_XML = "text/xml";
		private static final String CONTENT_TYPE_JPEG = "image/jpeg";
		private static final String CONTENT_TYPE_BINARY = "application/octet-stream";

		static BodyPart json(String name, String filename, String content) {
			return new BodyPart(name, filename, out -> out.print(content), CONTENT_TYPE_JSON);
		}

		static BodyPart xml(String name, String filename, String content) {
			return new BodyPart(name, filename, out -> out.print(content), CONTENT_TYPE_XML);
		}

		static BodyPart jpeg(String name, String filename, byte[] content) {
			return binary(name, filename, content, CONTENT_TYPE_JPEG);
		}

		static BodyPart binary(String name, String filename, byte[] content) {
			return binary(name, filename, content, CONTENT_TYPE_BINARY);
		}

		private static BodyPart binary(String name, String filename, byte[] content, String contentType) {
			return new BodyPart(name, filename, out -> {
				try {
					out.write(content);
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			}, contentType);
		}

		void print(PrintStream out) {
			this.writeContent.accept(out);
		}
	}

	private final List<BodyPart> parts = new ArrayList<>();
	private final String boundary = new BigInteger(32, new SecureRandom()).toString();

	void addPart(String name, String filename, String content) {
		parts.add(BodyPart.json(name, filename, content));
	}

	void addPart(BodyPart part) {
		parts.add(part);
	}

	String getBoundary() {
		return "--------------------------" + boundary;
	}

	byte[] getBody() {
		var out_ = new ByteArrayOutputStream();
		var out = new PrintStream(out_);
		for (BodyPart part : parts) {
			writeBoundary(out, false);
			out.printf("Content-Disposition: form-data; name=\"%s\"; filename=\"%s\"\r\n", part.name(), part.filename());
			out.printf("Content-Type: %s\r\n", part.contentType());
			out.print("\r\n");
			part.print(out);
			out.print("\r\n");
		}

		writeBoundary(out, true);
		return out_.toByteArray();
	}

	private void writeBoundary(PrintStream out, boolean isEnd) {
		out.print("--");
		out.print(getBoundary());
		if (isEnd) {
			out.print("--");
		}
		out.print("\r\n");
	}
}
