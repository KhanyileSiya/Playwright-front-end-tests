package de.bmw.otp.business;

import de.bmw.otp.playwright.LocatorHandle;
import de.bmw.otp.tests.VinPair;

import java.nio.file.Path;

public interface MyBmwHelper extends CustomerPortalHelper {

	default VinPair getVinPairOfStage() {
		return getStage().vins().myBmw();
	}

	@Override
	default void openPageAndLogin() {
		openPageAndLogin("Weiter", "Jetzt anmelden");
		LocatorHandle buttonRejectCookies = locateClassWithText("button-text", "Cookies verbieten");
		if (buttonRejectCookies.isPresent(getNavigationTimeout())) {
			buttonRejectCookies.click();
		}
	}

	default Path getRegressionCustomerPortalFolder() {
		return getRegressionFolder().resolve("mybmw");
	}

	default String getBaseUrl() {
		return getStage().urls().myBmwBase();
	}

	default void assertTransactionReportRequested() {
		assertTransactionReportRequested("BMW CarData");
	}

	default LocatorHandle locateAccessPermission() {
		return locateClassWithText("chakra-heading", "BMW CarData Datenfreigaben");
	}

	default LocatorHandle locateServicefreigaben() {
		return locateClassWithText("chakra-heading", "BMW CarData Servicefreigaben");
	}

	default void verifyClearanceDetails(String testingContainerTitle, String status) {
		verifyClearanceDetails("BMW CarData", testingContainerTitle, status);
	}

}
