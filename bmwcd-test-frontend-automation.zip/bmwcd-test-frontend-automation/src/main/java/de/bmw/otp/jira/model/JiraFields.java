package de.bmw.otp.jira.model;

import java.util.List;

public record JiraFields(String summary, List<JiraAttachment> attachment) {
}
