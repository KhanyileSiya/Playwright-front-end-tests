package de.bmw.otp.business;

import de.bmw.otp.playwright.PlaywrightHelper;
import de.bmw.otp.tests.WithCleanup;
import de.bmw.otp.tests.api.ClearanceClient;
import org.junit.jupiter.api.Assertions;

public interface ClearanceApiHelper extends PlaywrightHelper {

	String getSutVin();

	ClearanceClient getClearanceClient();

	default WithCleanup<String> clearanceRequest(String containerId) {
		return clearanceRequest(containerId, getSutVin());
	}

	default WithCleanup<String> clearanceRequest(String containerId, String vin) {
		return WithCleanup.then(
			getClearanceClient().requestClearanceWithCleanup(containerId, vin),
			(String clearanceId) -> assertClearanceStatusRequested(containerId, vin, clearanceId));
	}

	default void assertClearanceStatusApproved(String containerId, String vin, String clearanceId) {
		getAndAssertClearanceStatus("APPROVED", containerId, vin, clearanceId);
	}

	default void assertClearanceStatusRequested(String containerId, String vin, String clearanceId) {
		getAndAssertClearanceStatus("REQUESTED", containerId, vin, clearanceId);
	}

	default void assertClearanceStatusRejected(String containerId, String vin, String clearanceId) {
		getAndAssertClearanceStatus("REJECTED", containerId, vin, clearanceId);
	}

	default void assertClearanceStatusRevoked(String containerId, String vin, String clearanceId) {
		getAndAssertClearanceStatus("REVOKED", containerId, vin, clearanceId);
	}

	default void getAndAssertClearanceStatus(String expected, String containerId, String vin, String clearanceId) {
		Assertions.assertEquals(expected, getClearanceClient().getClearanceStatus(containerId, vin, clearanceId));
	}
}
