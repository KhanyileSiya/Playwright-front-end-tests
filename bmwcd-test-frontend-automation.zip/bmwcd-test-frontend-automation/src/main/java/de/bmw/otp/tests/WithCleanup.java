package de.bmw.otp.tests;

import java.io.Closeable;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;

public class WithCleanup<T> implements Closeable {
	private final T val_;
	private final Consumer<T> destructor;
	private boolean skipDestruction = false;

	public T val() {
		return val_;
	}

	public WithCleanup(T val, Consumer<T> destructor) {
		this.val_ = val;
		this.destructor = destructor;
		if (EnvVar.DEBUG_LOGGING.isTrue()) {
			System.out.println("====== WithCleanup construct val=" + val);
		}
	}

	@Override
	public void close() {
		if (skipDestruction) {
			return;
		}
		destruct();
	}

	private void destruct() {
		if (EnvVar.DEBUG_LOGGING.isTrue()) {
			System.out.println("====== WithCleanup destruct val=" + val_);
		}
		destructor.accept(val_);
	}

	public static <T> WithCleanup<T> then(WithCleanup<T> t, Consumer<T> then) {
		try (var val = t) {
			then.accept(t.val());
			t.skipDestruction = true;
		}
		return new WithCleanup<>(t.val(), v -> t.destruct());
	}

	public static <T> WithCleanup<T> then(WithCleanup<T> t, Runnable then) {
		try (var val = t) {
			then.run();
			t.skipDestruction = true;
		}
		return new WithCleanup<>(t.val(), v -> t.destruct());
	}

	public static <T, S, R> WithCleanup<R> combine(WithCleanup<T> t, Function<T, S> map, BiFunction<T, S, R> combine) {
		try (var val = t) {
			var b = map.apply(t.val());
			var pair = combine.apply(t.val(), b);
			t.skipDestruction = true;
			return new WithCleanup<>(pair, v -> t.destruct());
		}
	}
}
