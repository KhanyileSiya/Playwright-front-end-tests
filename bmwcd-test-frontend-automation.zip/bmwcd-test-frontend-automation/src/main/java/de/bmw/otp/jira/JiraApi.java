package de.bmw.otp.jira;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.bmw.otp.jira.model.JiraSummary;
import de.bmw.otp.jira.model.UploadResult;
import de.bmw.otp.tests.Utils;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.time.Duration;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;

public record JiraApi(String baseUrl, String authentication) {

	public UploadResult uploadReport(String reportName, String reportXml, String projectKey, String testExecInfo, String testInfo) throws IOException, InterruptedException {
		URI uri = URI.create("%s/rest/raven/1.0/import/execution/junit/multipart?projectKey=%s".formatted(baseUrl, projectKey));
		var files = List.of(
			MultipartBody.BodyPart.xml("file", reportName, reportXml),
			MultipartBody.BodyPart.json("info", "test_exec_info.json", testExecInfo),
			MultipartBody.BodyPart.json("testInfo", "test_info.json", testInfo)
		);
		return multipartUploadSafe(uri, files, UploadResult.class);
	}

	public Object uploadJpeg(String key, List<File> images) throws IOException, InterruptedException {
		return uploadAttachment(key, images, image -> MultipartBody.BodyPart.jpeg("file", image.getName(), Utils.uncheck(() -> Files.readAllBytes(image.toPath()))));
	}

	public Object uploadBinary(String key, List<File> files) throws IOException, InterruptedException {
		return uploadAttachment(key, files, file -> MultipartBody.BodyPart.binary("file", file.getName(), Utils.uncheck(() -> Files.readAllBytes(file.toPath()))));
	}

	public Object uploadAttachment(String key, List<File> images, Function<File, MultipartBody.BodyPart> toBodyPart) throws IOException, InterruptedException {
		URI uri = URI.create("%s/rest/api/2/issue/%s/attachments".formatted(baseUrl, key));
		var files = images.stream()
			.map(toBodyPart)
			.toList();
		return multipartUploadSafe(uri, files, Object.class);
	}

	private <T> T multipartUploadSafe(URI uri, List<MultipartBody.BodyPart> files, Class<T> resultClass) throws IOException, InterruptedException {
		var result = request(makeUploadRequest(uri, files), resultClass);
		if (result.statusCode() >= 400) {
			throw new RuntimeException("Unexpected JIRA API error " + result);
		}
		return result.body();
	}

	public void deleteAttachment(String self) throws JsonProcessingException, InterruptedException {
		request(makeDeleteRequest(URI.create(self)), Object.class);
	}

	public ApiResult<JiraSummary> requestAttachments(String self) throws InterruptedException, JsonProcessingException {
		return request(makeGetRequest(URI.create(self + "?fields=attachment")), JiraSummary.class);
	}

	public ApiResult<JiraSummary> requestSummary(String self) throws InterruptedException, JsonProcessingException {
		return request(makeGetRequest(URI.create(self + "?fields=summary")), JiraSummary.class);
	}

	private HttpRequest makeUploadRequest(URI uri, List<MultipartBody.BodyPart> files) {
		var bodyParts = new MultipartBody();
		files.forEach(bodyParts::addPart);
		return makeRequest(uri)
			.POST(HttpRequest.BodyPublishers.ofByteArray(bodyParts.getBody()))
			.header("Content-Type", "multipart/form-data; boundary=" + bodyParts.getBoundary())
			.build();
	}

	private HttpRequest makeGetRequest(URI uri) {
		return makeRequest(uri)
			.GET()
			.build();
	}

	private HttpRequest makeDeleteRequest(URI uri) {
		return makeRequest(uri)
			.DELETE()
			.build();
	}

	private HttpRequest.Builder makeRequest(URI uri) {
		return HttpRequest.newBuilder()
			.uri(uri)
			.header("X-Atlassian-Token", "nocheck")
			.header("Authorization", authentication);
	}

	private <T> ApiResult<T> request(HttpRequest request, Class<T> resultType) throws JsonProcessingException, InterruptedException {
		try (var http = HttpClient.newHttpClient()) {
			var response = withRetry(() -> sendRequest(http, request), 10, Duration.ofMinutes(5));
			var result = response.statusCode() == 200
				? readJson(response.body(), resultType)
				: null;
			return new ApiResult<>(response.statusCode(), result);
		}
	}

	private HttpResponse<String> withRetry(Supplier<HttpResponse<String>> sendRequest, int maxRetries, Duration maxWait) throws InterruptedException {
		for (int i=0; i<maxRetries; i++) {
			var response = sendRequest.get();
			if (response.statusCode() != 429) {
				return response;
			}
			long exponentialBackoffSeconds = 0x1L<<i;
			Duration waitExponentialBackoff = Duration.ofSeconds(exponentialBackoffSeconds);
			Duration waitExponentialBackoffTruncated = Utils.min(waitExponentialBackoff, maxWait);
			System.err.println("====== HTTP Response 429. Too many requests. Retry attempt " + i + " waiting " + waitExponentialBackoffTruncated);
			Thread.sleep(waitExponentialBackoffTruncated);
		}
		return sendRequest.get();
	}

	private HttpResponse<String> sendRequest(HttpClient http, HttpRequest request) {
		try {
			HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
			System.out.println(response);
			System.out.println(response.body());
			return response;
		} catch (IOException | InterruptedException e) {
			throw new RuntimeException(e);
		}
	}

	private <T> T readJson(String s, Class<T> clazz) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper()
			.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		return objectMapper.readValue(s, clazz);
	}

	public record ApiResult<T>(int statusCode, T body) {}

}
