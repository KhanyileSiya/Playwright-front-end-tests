package de.bmw.otp.tests.api;

import de.bmw.otp.exve.invoker.ApiClient;
import de.bmw.otp.tests.CardataStage;

import java.util.function.Supplier;

public class ClientBase {

	protected static TokenClient makeTokenClient(CardataStage stage) {
		return new TokenClient(
			stage.urls().cardataApi(),
			stage.apiClient().getUsername(),
			stage.apiClient().getPassword());
	}

	protected ApiClient makeApiClient(CardataStage stage, Supplier<String> accessTokenSource) {
		var client = new ApiClient();
		client.setBearerToken(accessTokenSource);
		client.setBasePath(stage.urls().cardataApi());
		return client;
	}
}
