package de.bmw.otp.tests.api;

import de.bmw.otp.exve.api.ContainersApi;
import de.bmw.otp.exve.api.VehiclesApi;
import de.bmw.otp.exve.model.ChargingSessionDto;
import de.bmw.otp.exve.model.ContainerVinResponseDto;
import de.bmw.otp.exve.model.ContainerVinVehiclesResponseDto;
import de.bmw.otp.exve.model.ExveTelematicValue;
import de.bmw.otp.exve.model.SmartMaintenanceTyreDiagnosisDto;
import de.bmw.otp.exve.model.VehicleInformationResponseDto;
import de.bmw.otp.tests.CardataStage;
import de.bmw.otp.tests.LoggingHelper;
import de.bmw.otp.tests.WithCleanup;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class ClearanceClient extends ClientBase {
	private final ContainersApi containersApi;
	private final VehiclesApi vehiclesApi;
	private final LoggingHelper log;

	public ClearanceClient(CardataStage stage, LoggingHelper log) {
		this.log = log;
		var tokenClient = makeTokenClient(stage);
		var currentAccessToken = tokenClient.getAccessToken();
		var apiClient = makeApiClient(stage, () -> currentAccessToken);
		containersApi = new ContainersApi(apiClient);
		vehiclesApi = new VehiclesApi(apiClient);
	}

	public String requestClearance(String containerId, String vin) {
		log.logMethodCall(containerId, vin);
		return Objects.requireNonNull(containersApi.createDataAccessClearanceRequestForVinConsent(containerId, vin, null)
				.getVehicles())
			.stream()
			.filter(vehicle -> vin.equals(vehicle.getVin()))
			.findFirst()
			.map(ContainerVinVehiclesResponseDto::getClearanceId)
			.orElseThrow();
	}

	public WithCleanup<String> requestClearanceWithCleanup(String containerId, String vin) {
		return new WithCleanup<>(requestClearance(containerId, vin), (String ignore) -> deleteClearanceNoThrow(containerId, vin));
	}

	public void deleteClearanceNoThrow(String containerId, String vin) {
		try {
			deleteClearance(containerId, vin);
		} catch (Exception e) {
			System.err.println("WARN: error delete clearanceId");
		}
	}

	public ContainerVinResponseDto deleteClearance(String containerId, String vin) {
		log.logMethodCall(containerId, vin);
		return containersApi.deleteClearanceForVinConsent(vin, containerId);
	}

	public Map<String, ExveTelematicValue> requestTelematicData(String clearanceId, String vin) {
		log.logMethodCall(clearanceId, vin);
		return vehiclesApi.telematicData(clearanceId, vin).getTelematicData();
	}

	public Map<String, ExveTelematicValue> requestTelematicData(String clearanceId, String vin, String telematicKey) {
		log.logMethodCall(clearanceId, vin, telematicKey);
		return vehiclesApi.getSingleTelematicDataForClearanceId(telematicKey, clearanceId, vin).getTelematicData();
	}

	public VehicleInformationResponseDto requestVehicleInformation(String clearanceId, String vin) {
		log.logMethodCall(clearanceId, vin);
		return vehiclesApi.getVehicleInformationForClearanceId(vin, clearanceId).getBasicData();
	}

	public File requestVehicleImage(String clearanceId, String vin) {
		log.logMethodCall(clearanceId, vin);
		return vehiclesApi.getVehicleImageForClearanceId(clearanceId, vin);
	}

	public Map<String, SmartMaintenanceTyreDiagnosisDto> tyreDiagnosisDataRequest(String clearanceId, String vin) {
		log.logMethodCall(clearanceId, vin);
		return vehiclesApi.getVehicleSmartMaintenanceTyreDiagnosisForClearanceId(clearanceId, vin).getSmartMaintenanceTyreDiagnosis();
	}

	public List<ChargingSessionDto> getChargingHistoryForClearanceId(String clearanceId, String vin, LocalDate from) {
		log.logMethodCall(clearanceId, vin, from.toString());
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		return vehiclesApi.getChargingHistoryForClearanceId(clearanceId, vin, from.format(formatter), null, null).getChargingHistory();
	}

	public String getClearanceStatus(String containerId, String vin, String clearanceId) {
		log.logMethodCall(containerId, vin, clearanceId);
		return Objects.requireNonNull(containersApi.getClearanceStatusesForVinConsent(containerId, vin, clearanceId).getVehicles()).getFirst().getClearanceState();
	}
}
