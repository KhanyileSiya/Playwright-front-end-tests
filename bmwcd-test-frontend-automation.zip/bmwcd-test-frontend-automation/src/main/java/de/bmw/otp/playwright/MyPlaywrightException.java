package de.bmw.otp.playwright;

import com.microsoft.playwright.PlaywrightException;

public class MyPlaywrightException extends RuntimeException {
	public MyPlaywrightException(PlaywrightException delegate) {
		super(delegate);
	}
}
