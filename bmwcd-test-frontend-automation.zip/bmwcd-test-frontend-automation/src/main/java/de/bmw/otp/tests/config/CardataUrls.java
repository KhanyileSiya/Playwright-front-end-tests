package de.bmw.otp.tests.config;

import de.bmw.otp.tests.UrlSet;

public class CardataUrls {
	private static final String CARDATA_API_INT = "https://api-cardata-int.bmwgroup.com";
	private static final String CARDATA_API_E2E = "https://api-cardata-e2e.bmwgroup.com";
	private static final String CARDATA_API_PROD = "https://api-cardata.bmwgroup.com";

	public static final String CARDATA_MS_CLEARANCE_INT = "https://clearance.int.apps.4wm-de-odp-nonprod.eu-central-1.aws.cloud.bmw";
	public static final String CARDATA_MS_CLEARANCE_E2E = "https://clearance.e2e.apps.4wm-de-odp-nonprod.eu-central-1.aws.cloud.bmw";
	public static final String CARDATA_MS_CLEARANCE_PROD = "https://clearance.prod.apps.4wm-de-odp-nonprod.eu-central-1.aws.cloud.bmw";

	public static final String THIRD_PARTY_PORTAL_INT = "https://bmwcardata-int.bmwgroup.com/thirdparty";
	public static final String THIRD_PARTY_PORTAL_E2E = "https://bmwcardata-e2e.bmwgroup.com/thirdparty";
	public static final String THIRD_PARTY_PORTAL_PROD = "https://bmw-cardata.bmwgroup.com/thirdparty";

	private static final String MY_BMW_INT = withBmw("https://bmw-de-awsint-b1.int.bmwweb.eu-central-1.aws.bmw.cloud");
	private static final String MY_BMW_E2E = withBmw("https://bmw-de-awsint-b2.int.bmwweb.eu-central-1.aws.bmw.cloud");
	private static final String MY_BMW_PROD = withBmw("https://www.bmw.de");

	private static final String MY_MINI_INT = withMini("https://mini-de-awsint-m2.int.miniweb.eu-central-1.aws.bmw.cloud");
	private static final String MY_MINI_E2E = withMini("https://mini-de-awsint-m4.int.miniweb.eu-central-1.aws.bmw.cloud");
	private static final String MY_MINI_PROD = withMini("https://www.mini.de");

	private static final String MY_ROLLS_ROYCE_INT = withRR("https://int.mybmw.com");
	private static final String MY_ROLLS_ROYCE_E2E = withRR("https://e2e.mybmw.com");
	private static final String MY_ROLLS_ROYCE_PROD = withRR("https://cardata.rolls-roycemotorcars.com");

	private static final String MY_TOYOTA_INT = withToyota("https://int.mybmw.com");
	private static final String MY_TOYOTA_E2E = withToyota("https://e2e.mybmw.com");
	private static final String MY_TOYOTA_PROD = withToyota("https://www.toyota-supraconnect.de");

	private static String withBmw(String baseUrl) {
		return baseUrl + "/de-de/mybmw";
	}

	private static String withMini(String baseUrl) {
		return baseUrl + "/de-de/mymini";
	}

	private static String withRR(String baseUrl) {
		return baseUrl + "/en-gb/myrr";
	}

	private static String withToyota(String baseUrl) {
		return baseUrl + "/de-de/mytoyota";
	}

	public static final UrlSet URLS_INT = new UrlSet(CARDATA_API_INT, CARDATA_MS_CLEARANCE_INT, THIRD_PARTY_PORTAL_INT, MY_BMW_INT, MY_MINI_INT, MY_ROLLS_ROYCE_INT, MY_TOYOTA_INT);
	public static final UrlSet URLS_E2E = new UrlSet(CARDATA_API_E2E, CARDATA_MS_CLEARANCE_E2E, THIRD_PARTY_PORTAL_E2E, MY_BMW_E2E, MY_MINI_E2E, MY_ROLLS_ROYCE_E2E, MY_TOYOTA_E2E);
	public static final UrlSet URLS_PROD = new UrlSet(CARDATA_API_PROD, CARDATA_MS_CLEARANCE_PROD, THIRD_PARTY_PORTAL_PROD, MY_BMW_PROD, MY_MINI_PROD, MY_ROLLS_ROYCE_PROD, MY_TOYOTA_PROD);
}
