package de.bmw.otp.tests;

import de.bmw.otp.tests.config.CardataCredentials;
import de.bmw.otp.tests.config.CardataThirdPartyPortals;
import de.bmw.otp.tests.config.CardataUrls;
import de.bmw.otp.tests.config.CardataVins;

import java.nio.file.Path;
import java.util.Optional;
import java.util.function.Supplier;

public enum CardataStage {
	INT(CardataUrls.URLS_INT, CardataCredentials.API_CLIENT_INT, CardataCredentials.CLEARANCE_BACKEND_BASIC_INT, CardataThirdPartyPortals.THIRD_PARTY_PORTAL_INT, CardataCredentials.CUSTOMER_PORTAL_E2E, CardataCredentials.CUSTOMER_PORTAL_BASIC_E2E, CardataVins.VINS_E2E),
	E2E(CardataUrls.URLS_E2E, CardataCredentials.API_CLIENT_E2E, CardataCredentials.CLEARANCE_BACKEND_BASIC_E2E, CardataThirdPartyPortals.THIRD_PARTY_PORTAL_E2E, CardataCredentials.CUSTOMER_PORTAL_E2E, CardataCredentials.CUSTOMER_PORTAL_BASIC_E2E, CardataVins.VINS_E2E),
	PROD(CardataUrls.URLS_PROD, CardataCredentials.API_CLIENT_PROD, CardataCredentials.CLEARANCE_BACKEND_BASIC_PROD, CardataThirdPartyPortals.THIRD_PARTY_PORTAL_PROD, CardataCredentials.CUSTOMER_PORTAL_PROD, null, CardataVins.VINS_PROD);

	private final UrlSet urls;
	private final Credentials apiClient;
	private final Credentials clearanceBackendBasic;
	private final ThirdPartyPortal thirdPartyPortal;
	private final Credentials customerPortalLogin;
	private final Credentials customerPortalBasic;
	private final VinSet vins;

	CardataStage(UrlSet urls, Credentials apiClient, Credentials clearanceBackendBasic, ThirdPartyPortal thirdPartyPortal, Credentials customerPortalLogin, Credentials customerPortalBasic, VinSet vins) {
		this.urls = urls;
		this.apiClient = apiClient;
		this.clearanceBackendBasic = clearanceBackendBasic;
		this.thirdPartyPortal = thirdPartyPortal;
		this.customerPortalLogin = customerPortalLogin;
		this.customerPortalBasic = customerPortalBasic;
		this.vins = vins;
	}

	public Credentials apiClient() {
		return apiClient;
	}

	public Credentials getClearanceBackendBasic() {
		return clearanceBackendBasic;
	}

	public UrlSet urls() {
		return urls;
	}

	public ThirdPartyPortal thirdPartyPortal() {
		return thirdPartyPortal;
	}

	public Credentials customerPortalLogin() {
		return customerPortalLogin;
	}

	public Optional<Credentials> customerPortalBasic() {
		return Optional.ofNullable(customerPortalBasic);
	}

	public VinSet vins() {
		return vins;
	}

	public Path resolveStageSpecificPath(Path parent) {
		// this is a hook for future use
		return parent;
	}

	public static CardataStage get() {
		return memoizedGet.get();
	}
	private static final Supplier<CardataStage> memoizedGet = Utils.memoize(CardataStage::determine);

	private static CardataStage determine() {
		return EnvVar.CARDATA_STAGE.val()
			.map(stage -> switch (stage) {
				case "INT" -> CardataStage.INT;
				case "E2E" -> CardataStage.E2E;
				case "PROD" -> CardataStage.PROD;
				default -> CardataStage.E2E;
			})
			.orElse(E2E);
	}
}
