package de.bmw.otp.business;

import de.bmw.otp.playwright.PlaywrightBase;
import de.bmw.otp.tests.api.AssignmentClient;
import de.bmw.otp.tests.api.ClearanceClient;

public abstract class ThirdPartyBase extends PlaywrightBase implements TestBase, AssignmentApiHelper, ClearanceApiHelper {
	private final AssignmentClient assignments = new AssignmentClient(getStage(), this);
	private final ClearanceClient clearanceClient = new ClearanceClient(getStage(), this);

	@Override
	public AssignmentClient getAssignmentClient() {
		return assignments;
	}

	@Override
	public ClearanceClient getClearanceClient() {
		return clearanceClient;
	}
}
