package de.bmw.otp.tests;

public record VinPair(String vin, String resetVin) {
}
