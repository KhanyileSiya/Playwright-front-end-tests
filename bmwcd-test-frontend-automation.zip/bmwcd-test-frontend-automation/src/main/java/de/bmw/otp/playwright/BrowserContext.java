package de.bmw.otp.playwright;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.Page;
import de.bmw.otp.tests.CardataStage;
import de.bmw.otp.tests.EnvVar;
import de.bmw.otp.tests.LoggingHelper;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

public class BrowserContext implements AutoCloseable {
	private final double navigationTimeout;
	private final double locatorTimeout;
	private com.microsoft.playwright.BrowserContext context;
	private Page page;

//	public BrowserContext(Browser browser, CardataStage stage, double navigationTimeout, double locatorTimeout) {
//		this.navigationTimeout = navigationTimeout;
//		this.locatorTimeout = locatorTimeout;
//		Browser.NewContextOptions options = new Browser.NewContextOptions()
//			.setViewportSize(1280, 1024)
//			.setLocale("de-DE")
//			.setIgnoreHTTPSErrors(true);
//		Browser.NewContextOptions optionsWithAuth = stage.customerPortalBasic()
//			.map(credentials -> options.setHttpCredentials(credentials.getUsername(), credentials.getPassword()))
//			.orElse(options);
//		this.context = browser.newContext(optionsWithAuth);
//	}
	//Replaced above code with the following
// Static flag to track if a clean session has already been created in this JVM run

private static boolean sessionCreatedThisRun = false;

	public BrowserContext(Browser browser, CardataStage stage, double navigationTimeout, double locatorTimeout) {
		this.navigationTimeout = navigationTimeout;
		this.locatorTimeout = locatorTimeout;

		Browser.NewContextOptions options = new Browser.NewContextOptions()
			.setViewportSize(1280, 1024)
			.setLocale("de-DE")
			.setIgnoreHTTPSErrors(true);

		Browser.NewContextOptions optionsWithAuth = stage.customerPortalBasic()
			.map(credentials -> options.setHttpCredentials(credentials.getUsername(), credentials.getPassword()))
			.orElse(options);

		Path sessionFile = Paths.get("src/main/resources/seeds/session-state.json");

		try {
			System.out.println("======Launching Playwright with session reuse support ======");

			// Step 1: First test run - delete any existing session, start fresh
			if (!sessionCreatedThisRun) {
				if (Files.exists(sessionFile)) {
					System.out.println("Deleting old session file before creating new context: " + sessionFile);
					Files.delete(sessionFile);
				}
				this.context = browser.newContext(optionsWithAuth);
				sessionCreatedThisRun = true;
				System.out.println("Created fresh Playwright BrowserContext (new session).");
				return;
			}

			// Step 2: All subsequent tests - always reuse session, never delete again
			if (Files.exists(sessionFile)) {
				System.out.println("====== Found existing session file → " + sessionFile.toAbsolutePath());
				this.context = browser.newContext(
					optionsWithAuth.setStorageStatePath(sessionFile)
				);
				System.out.println("====== Reused existing Playwright session successfully.");
				return;
			}

			// Step 3: In the rare case no file exists (should not happen), create new context
			System.out.println("====== No session file found — creating fallback clean context.");
			this.context = browser.newContext(optionsWithAuth);

		} catch (Exception e) {
			System.out.println("======Unexpected error creating Playwright context: " + e.getMessage());
			this.context = browser.newContext(optionsWithAuth);
		}
	}

//==============

	public PageHandle getPage(LoggingHelper log) {
		this.page = createPage(log);
		return new PageHandle(log, this.page);
	}

	private Page createPage(LoggingHelper log) {
		var page = context.newPage();
		page.setDefaultNavigationTimeout(navigationTimeout);
		page.setDefaultTimeout(locatorTimeout);
		if (EnvVar.REQUEST_LOGGING.isTrue()) {
			page.onRequest(request -> log.log(">> " + request.method() + " " + request.url()));
			page.onResponse(response -> log.log("<< " + response.url()));
		}
		return page;
	}

	public Optional<String> getCookie(String name) {
		return this.context.cookies()
			.stream()
			.filter(cookie -> name.equals(cookie.name))
			.findFirst()
			.map(cookie -> cookie.value);
	}

	@Override
	public void close() {
		this.page.close();
		this.page = null;
		this.context.close();
		this.context = null;
	}
}
