package de.bmw.otp.business;

import de.bmw.otp.exve.invoker.ApiException;
import de.bmw.otp.exve.model.ExveTelematicValue;
import de.bmw.otp.tests.Utils;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.TestMethodOrder;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Map;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.not;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public abstract class AbstractDataRetrievalRegressionTests extends ThirdPartyBase implements CustomerPortalClearanceHelper, ThirdPartyPortalTests, ErrorHelper {

	@Override
	public String getSutVin() {
		return getVinPairOfStage().vin();
	}

	private static final String TESTING_CONTAINER_TITLE = Utils.withIdTrimmed("Playwright Regression ", 30);

	@Override
	public String getTestingContainerTitle() {
		return TESTING_CONTAINER_TITLE;
	}

	@BeforeAll
	static void setUpAll() {
		baseSetUpAll();
	}

	@BeforeEach
	void setUpEach(TestInfo testInfo) {
		getAssignmentClient().revokeAllAssignments(getSutVin());
		baseSetUp(getStage(), testInfo);
		var skipLogin = getCookie("weni").isPresent() || getCookie("wen").isPresent();
		var needLogin = !skipLogin;
		openAndLogin3rdPartyPortal(needLogin);
	}

	@AfterEach
	void tearDownEach() {
		baseTearDown();
	}

	@AfterAll
	static void tearDownAll() {
		baseTearDownAll();
	}

	@Test
	@Order(1)
	void testCreateContainer() {
		abortTests();
		testingCreateContainer();
		continueTests();
	}

	@Test
	@Order(2)
	void testCheckRequestedClearanceAndApproveAndRequestTelematicData() {
		abortTests();
		try {
			var clearanceId = openContainerOverviewAndRequestClearance();
			openPageAndLoginAndSelectVin(getSutVin());

			verifyClearanceDetails(getTestingContainerTitle(), getStatusNew());

			acceptClearance(clearanceId, getTestingContainerTitle());

			verifyClearanceDetails(getTestingContainerTitle(), getStatusAccepted());

			var telematicData = getClearanceClient().requestTelematicData(clearanceId, getSutVin());
			System.out.println(telematicData);
		} catch (Exception e) {
			openAndLogin3rdPartyPortal(false);
			openContainerOverviewAndDeleteContainer();
			throw e;
		}
		continueTests();
	}

	@Test
	@Order(3)
	void testRequestSpecificTelematicData() {
		var clearanceId = openContainerOverviewAndRequestClearance();

		var telematicData = getClearanceClient().requestTelematicData(clearanceId, getSutVin(), "Vehicle.Vehicle.TravelledDistance");
		System.out.println(telematicData);
	}

	@Test
	@Order(4)
	void testRequestBasicVehicleData() {
		var clearanceId = openContainerOverviewAndRequestClearance();

		var response = getClearanceClient().requestVehicleInformation(clearanceId, getSutVin());
		System.out.println(response);
	}

	@Test
	@Order(5)
	void testRequestVehicleImage() {
		var clearanceId = openContainerOverviewAndRequestClearance();

		var response = getClearanceClient().requestVehicleImage(clearanceId, getSutVin());
		System.out.println(response);
	}

	@Test
	@Order(6)
	void testRequestTyreDiagnosis() {
		var clearanceId = openContainerOverviewAndRequestClearance();

		var response = getClearanceClient().tyreDiagnosisDataRequest(clearanceId, getSutVin());
		System.out.println(response);
	}

	@Test
	@Order(7)
	void testRequestChargingHistory() {
		var clearanceId = openContainerOverviewAndRequestClearance();

		var from = LocalDate.now().minusDays(60);
		var response = getClearanceClient().getChargingHistoryForClearanceId(clearanceId, getSutVin(), from);
		System.out.println(response);
	}

	@Test
	@Order(8)
	void testRevokeApprovedClearanceAndRequestTelematicData() {
		var clearanceId = openContainerOverviewAndRequestClearance();

		openPageAndLoginAndSelectVin(getSutVin());
		revokeClearance(clearanceId, getTestingContainerTitle());

		var e = Assertions.assertThrows(ApiException.class, () -> {
			getClearanceClient().requestTelematicData(clearanceId, getSutVin());
		});

		MatcherAssert.assertThat(e.getCode(), equalTo(403));
		assertErrorCode(e.getResponseBody(), "TP-107");
		MatcherAssert.assertThat(e.getResponseBody(), containsString("\"exveErrorId\":\"TP-107\""));
	}

	@Test
	@Order(9)
	void testDeleteClearanceId() {
		var clearanceId = openContainerOverviewAndRequestClearance();
		String containerId = findRegressionContainerAndGetContainerId();

		openPageAndLoginAndSelectVin(getSutVin());
		acceptClearance(clearanceId, getTestingContainerTitle());

		checkTelematicData(requestTelematicDataAndAssert(clearanceId));

		var response = getClearanceClient().deleteClearance(containerId, getSutVin());
		System.out.println(response);

		var e = Assertions.assertThrows(ApiException.class, () -> {
			// bad case
			requestTelematicDataAndAssert(clearanceId);
		});
	}

	@Test
	@Order(10)
	void testDeleteCreatedContainer() {
		var containerId = openContainerOverviewAndDeleteContainer();

		locateElementWithText("tr", getTestingContainerTitle()).assertMissing();

		var e = Assertions.assertThrows(ApiException.class, () -> {
			// bad case
			getClearanceClient().requestClearance(containerId, getSutVin());
		});
	}

	private void checkTelematicData(Map<String, ExveTelematicValue> telematicData) {
		System.out.println(telematicData);
		MatcherAssert.assertThat(telematicData, not(equalTo(Collections.EMPTY_MAP)));
		//TODO: more checks
	}

	private Map<String, ExveTelematicValue> requestTelematicDataAndAssert(String clearanceId) {
		return getClearanceClient().requestTelematicData(clearanceId, getSutVin());
	}
}
