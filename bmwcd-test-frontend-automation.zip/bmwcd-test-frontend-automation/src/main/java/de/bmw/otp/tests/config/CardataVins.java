package de.bmw.otp.tests.config;

import de.bmw.otp.tests.VinPair;
import de.bmw.otp.tests.VinSet;

public class CardataVins {
	private static final VinPair MYTOYOTA_VINS_E2E = new VinPair("WBADB45080HY53059", "WBADB45060HY53058");
	private static final VinPair MYTOYOTA_VINS_PROD = new VinPair("todo_unknown", "todo_unknown");

	private static final VinPair MYBMW_VINS_E2E = new VinPair("WBA21CS010HY45099", "WBA31AW0X0HY53009");
	private static final VinPair MYBMW_VINS_PROD = new VinPair("todo_unknown", "todo_unknown");

	private static final VinPair MYROLLSROYCE_VINS_E2E = new VinPair("SCATK210X0Q000OGX", "SCATK21080Q000OGW");
	private static final VinPair MYROLLSROYCE_VINS_PROD = new VinPair("todo_unknown", "todo_unknown");

	private static final VinPair MYMINI_VINS_E2E = new VinPair("WMW11GD080HY53054", "WMW11GD0X0HY53055");
	private static final VinPair MYMINI_VINS_PROD = new VinPair("todo_unknown", "todo_unknown");

	public static final VinSet VINS_E2E = new VinSet(MYBMW_VINS_E2E, MYROLLSROYCE_VINS_E2E, MYMINI_VINS_E2E, MYTOYOTA_VINS_E2E);
	public static final VinSet VINS_PROD = new VinSet(MYBMW_VINS_PROD, MYROLLSROYCE_VINS_PROD, MYMINI_VINS_PROD, MYTOYOTA_VINS_PROD);
}
