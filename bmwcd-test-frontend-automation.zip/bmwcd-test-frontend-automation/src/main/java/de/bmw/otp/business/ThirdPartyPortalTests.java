package de.bmw.otp.business;

import de.bmw.otp.tests.WithCleanup;
import de.bmw.otp.tests.api.ClearanceClient;

public interface ThirdPartyPortalTests extends ThirdPartyPortalHelper {

	ClearanceClient getClearanceClient();

	String getSutVin();

	default ContainerAndClearance testingCreateContainer() {
		return testingCreateContainer(null);
	}

	default ContainerAndClearance testingCreateContainer(Integer maxKeys) {
		try {
			String containerId = createContainerByGui(getTestingContainerTitle(), maxKeys);
			log("containerId= " + containerId);
			log("Number of Keys= " + maxKeys);

			String clearanceId = getClearanceClient().requestClearance(containerId, getSutVin());
			log("clearanceId= " + clearanceId);
			return new ContainerAndClearance(containerId, clearanceId);
		} catch (Exception e) {
			e.printStackTrace();
			openAndLogin3rdPartyPortal(false);
			openContainerOverviewAndDeleteContainer();
			throw e;
		}
	}

	default String openContainerOverviewAndDeleteContainer() {
		openContainerOverview();
		var containerId = findRegressionContainerAndGetContainerId();
		findRegressionContainerAndDelete();
		return containerId;
	}

	default String openContainerOverviewAndRequestClearance() {
		openContainerOverview();
		String containerId = findRegressionContainerAndGetContainerId();
		String clearanceId = getClearanceClient().requestClearance(containerId, getSutVin());
		return clearanceId;
	}

	default WithCleanup<ContainerAndClearance> createContainerAndRequestClearance() {
		return WithCleanup.combine(
			createContainerByApi(getTestingContainerTitle()),
			containerId -> getClearanceClient().requestClearance(containerId, getSutVin()),
			ContainerAndClearance::new
			);
	}

	record ContainerAndClearance(String containerId, String clearanceId) {
	}
}
