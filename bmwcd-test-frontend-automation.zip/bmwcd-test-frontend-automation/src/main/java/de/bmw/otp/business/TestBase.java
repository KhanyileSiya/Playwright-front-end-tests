package de.bmw.otp.business;

import de.bmw.otp.playwright.LocatorHandle;
import de.bmw.otp.playwright.MyPlaywrightException;
import de.bmw.otp.playwright.PlaywrightHelper;
import de.bmw.otp.tests.CardataStage;
import de.bmw.otp.tests.EnvVar;
import de.bmw.otp.tests.LoggingHelper;

import java.nio.file.Path;

public interface TestBase extends PlaywrightHelper, LoggingHelper {
	default CardataStage getStage() {
		return CardataStage.get();
	}

	default Path getRegressionFolder() {
		return getStage().resolveStageSpecificPath(Path.of("regression"));
	}

	default void clickCheckError(LocatorHandle loc) {
		loc.click();
		postClickHook();
	}

	default void postClickHook() {
		checkForErrorMessage();
	}

	default void checkForErrorMessage() {
		try {
			if (locateLoginError().isPresent(3_000)) {
				throw new RuntimeException("Login error message");
			}
			if (locateErrorNotification().isPresent(3_000)) {
				throw new RuntimeException("Error notification present");
			}
		} catch (MyPlaywrightException e) {
			if (EnvVar.DEBUG_LOGGING.isTrue()) {
				System.err.println(e.getMessage());
			}
		}
	}

	default LocatorHandle locateLoginError() {
		return select("#app-notification-message.error");
	}

	default LocatorHandle locateErrorNotification() {
		return getByTestId("errorNotificationTitle");
	}
}
