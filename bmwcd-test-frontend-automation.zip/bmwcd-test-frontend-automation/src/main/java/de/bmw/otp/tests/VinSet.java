package de.bmw.otp.tests;

public record VinSet(
	VinPair myBmw,
	VinPair myRollsRoyce,
	VinPair myMini,
	VinPair myToyota) {
}
