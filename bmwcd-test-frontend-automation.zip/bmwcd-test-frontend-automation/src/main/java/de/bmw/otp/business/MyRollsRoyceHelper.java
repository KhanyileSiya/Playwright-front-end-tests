package de.bmw.otp.business;

import de.bmw.otp.playwright.KeyboardModifier;
import de.bmw.otp.playwright.LocatorHandle;
import de.bmw.otp.tests.VinPair;

import java.io.File;
import java.nio.file.Path;

public interface MyRollsRoyceHelper extends ResetHelper, CustomerPortalHelper {

	default VinPair getVinPairOfStage() {
		return getStage().vins().myRollsRoyce();
	}

	@Override
	default String getStatusNew(){return "New";}
	@Override
	default String getStatusAccepted(){return "Permitted";}
	@Override
	default String getStatusRejected(){return "Rejected";}
	@Override
	default String getStatusRevoked(){return "Revoked";}
	@Override
	default String getStatusWithdrawn(){return "Withdrawn";}

	@Override
	default String getTextRequestTransactionReport(){
		return "Request transaction report";
	}
	@Override
	default String getDataPacketText(){ return "Data package"; }
	@Override
	default String getDownloadTransactionReportButtonText() { return "Download transaction report";}
	@Override
	default String getTransactionReportAssertText() {
		return "Folgende Unternehmen haben die meisten Datenabrufe durchgeführt";
	}//TODO: Transaction Report PDF has a Defect atm - Naming has to be changed in english text

	@Override
	default void openPageAndLogin() {
		openPageAndLogin("Continue", "Login");

		LocatorHandle buttonRejectCookies = locateClassWithText("reject-button", "Reject");
		if (buttonRejectCookies.isPresent(getNavigationTimeout())) {
			buttonRejectCookies.click();
		}
	}

	@Override
	default void clickTilePopupAccept(LocatorHandle popup) {clickCheckError(popup.getByText("Confirm"));}
	@Override
	default void clickAssignmentTilePopupReject(LocatorHandle popup) {clickCheckError(popup.getByText("Reject"));}
	@Override
	default void clickClearanceTilePopupReject(LocatorHandle popup) {clickCheckError(popup.getByText("Confirm"));}
	@Override
	default void clickTilePopupRevoke(LocatorHandle popup) {clickCheckError(popup.getByText("Revoke"));}
	@Override
	default String getClearancePopupButtonTextCancel() {return "Cancel";}
	@Override
	default String getAssignmentPopupButtonTextCancel() {return "Back";}
	@Override
	default String getTacButtonText() {return "Terms of Use";}
	@Override
	default String getPrivacyButtonText() {return "Privacy Policy";}


	default Path getRegressionCustomerPortalFolder() {
		return getRegressionFolder().resolve("myrr");
	}

	default String getBaseUrl() {
		return getStage().urls().myRollsRoyceBase();
	}

	default void assertTransactionReportRequested() {
		logMethodCall();
		select("#chakra-toast-manager-top")
			.getByTestId("successNotificationTitle")
			.getByText("If you have enabled notifications, you will be informed as soon as the Rolls‑Royce CarData transaction report is available.")
			.assertVisible();
		getByTestId("reportIsBeingCreated").assertVisible();
		getByTestId("reportIsBeingCreated").getByText("Your Rolls‑Royce CarData transaction report is being created").assertVisible();
	}

	default LocatorHandle locateAccessPermission() {
		return locateClassWithText("chakra-heading", "Rolls‑Royce CarData data access permissions");
	}

	@Override
	default LocatorHandle locateAccessPermissionText() {
		return locateClassWithText("chakra-text", "The following overview shows to whom you have granted permission to use certain telematics data");
	}

	default LocatorHandle locateServicefreigaben() {
		return locateClassWithText("chakra-heading", "Rolls‑Royce CarData service permissions");
	}

	@Override
	default LocatorHandle locateServicefreigabenText() {
		return locateClassWithText("chakra-text", "The following overview shows to which independent providers you have granted permission to provide certain services");
	}

	@Override
	default LocatorHandle locateAssignmentModifiedDate(LocatorHandle tile) {
		return tile.getByTestId("modifiedDateKey").getByText("Status changed");
	}

	@Override
	default LocatorHandle locateAssignmentPersonalMessage() {
		return locateClassWithText("chakra-heading", "Personal message to the request");
	}

	@Override
	default LocatorHandle locateAssignmentPartnerDetails() {
		return getByText("Details on service Service Partner");
	}
	@Override
	default LocatorHandle locateTransactionConfirmButton(){
		return getByTestId("transactionReportConfirmationPopupConfirmButton").getByText("Confirm");
	}

	@Override
	default File downloadDpp() {
		logMethodCall();
		return download(() -> {
			clickCheckError(getByText("Terms of Use", true), KeyboardModifier.ALT);
		});
	}

	@Override
	default void clickResetButtonAndCancel() {
		clickResetButton();
		getByTestId("resetCardataConfirmationPopupCancelButton").getByText("Cancel").click();
	}

	@Override
	default void clickResetButtonAndApprove() {
		clickResetButton();
		getByTestId("resetCardataConfirmationPopupConfirmButton").getByText("Confirm").click();
	}

	@Override
	default void clickResetButton() {
		getByText("Perform reset").click();
	}

	default void verifyClearanceDetails(String testingContainerTitle, String status) {
		verifyClearanceDetails("Rolls-Royce CarData", testingContainerTitle, status);
	}
	@Override
	default void clickDetailsCancel(LocatorHandle popup) {
		clickCheckError(popup.getByText("Back"));
	}

	@Override
	default LocatorHandle locateClearanceRequestDetails() {
		return getByText("Details on the request", true);
	}
	@Override
	default String getTextShowMoreButton() { return "Show more";}
	@Override
	default void assertClearanceHeadingIsCorrect(String identifier) {
		locateClassWithText("chakra-heading",
			"Rolls‑Royce CarData – details on the data access request of BMW AG CA-534 CarData ProconDEV.").assertVisible();
	}
	@Override
	default void assertContainerKeyElements() {
		checkContainerKeyElements("Status of engine (on/off)", "This value indicates whether the engine was on or off at the time of data collection or whether the status is unknown.");
		checkContainerKeyElements("Basic vehicle data", "This value indicates a list of basic vehicle data, e.g. vehicle brand and full model name.");
		checkContainerKeyElements("Measured tyre pressure, rear left", "This value indicates the measured tyre pressure on the rear left in kPa.");
	}

}
