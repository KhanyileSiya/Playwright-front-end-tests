package de.bmw.otp.tests;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.junit.jupiter.api.Assertions;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.function.BiConsumer;

public interface PdfHelper extends LoggingHelper {

	default void validatePdf(File pdf, BiConsumer<PDDocument, String> validatePdf) throws IOException {
		logMethodCall();
		try (PDDocument document = PDDocument.load(pdf)) {
			PDFTextStripper stripper = new PDFTextStripper();
			String pdfContent = stripper.getText(document);
			validatePdf.accept(document, pdfContent);
		}
	}

	default void assertPdfsAreEqual(File expect, File actual) throws IOException {
		logMethodCall();
		Assertions.assertTrue(equalsPdf(expect, actual));
	}

	default boolean equalsPdf(File expect, File actual) throws IOException {
		return -1 == Files.mismatch(expect.toPath(), actual.toPath());
	}
}
