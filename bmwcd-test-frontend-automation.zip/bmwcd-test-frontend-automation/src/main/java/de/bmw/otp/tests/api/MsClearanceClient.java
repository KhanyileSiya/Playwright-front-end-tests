package de.bmw.otp.tests.api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.bmw.otp.tests.CardataStage;
import de.bmw.otp.tests.LoggingHelper;
import de.bmw.otp.tests.Utils;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Base64;
import java.util.List;

public class MsClearanceClient {

	private final CardataStage stage;
	private final LoggingHelper log;

	public MsClearanceClient(CardataStage stage, LoggingHelper log) {
		this.stage = stage;
		this.log = log;
	}

	public String createContainer(String title, String description, List<TelematicBusinessId> keys) {
		log.logMethodCall(title, description, String.valueOf(keys.size()));
		try (HttpClient client = HttpClient.newHttpClient()) {
			HttpRequest request = makeRequest(makeContainersUri())
				.header("Content-Type", "application/json")
				.POST(HttpRequest.BodyPublishers.ofString(makeCreateRequestBody(title, description, keys)))
				.build();
			var response = client.send(request, HttpResponse.BodyHandlers.ofString());
			log.log("createContainer " + response);
			Utils.assertHttpIsOkay(response, "createContainer");
			var body = Utils.emptyToJsonObject(response.body());
			var responseObject = new ObjectMapper()
				.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
				.readValue(body, CreateContainerResponse.class);
			return responseObject.containerId();
		} catch (InterruptedException | IOException e) {
			throw new RuntimeException(e);
		}
	}

	public void deleteContainerNoThrow(String containerId) {
		try {
			deleteContainer(containerId);
		} catch (Exception e) {
			System.err.println("WARN: error deleting container id=" + containerId);
		}
	}

	public void deleteContainer(String containerId) throws IOException, InterruptedException {
		log.logMethodCall(containerId);
		try (HttpClient client = HttpClient.newHttpClient()) {
			HttpRequest request = makeRequest(makeContainersUri(containerId))
				.DELETE()
				.build();
			var response = client.send(request, HttpResponse.BodyHandlers.ofString());
			log.log("deleteContainer " + response);
		}
	}

	public List<TelematicBusinessId> fetchAvailableTelematicKeys() throws IOException, InterruptedException {
		log.logMethodCall();
		try (HttpClient client = HttpClient.newHttpClient()) {
			HttpRequest request = HttpRequest.newBuilder()
				.uri(makeTelematicKeysUri())
				.header("X-language", "de")
				.header("X-availableIn", "THIRD_PARTY")
				.GET()
				.build();
			var response = client.send(request, HttpResponse.BodyHandlers.ofString());
			log.log("fetchTelematicKeys " + response);
			Utils.assertHttpIsOkay(response, "fetchTelematicKeys");
			var body = Utils.emptyToJsonObject(response.body());
			var responseObject = new ObjectMapper()
				.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
				.readValue(body, new TypeReference<List<TelematicBusinessId>>() {});
			return responseObject;
		}
	}

	private HttpRequest.Builder makeRequest(URI uri) {
		var credentials = stage.getClearanceBackendBasic();
		String encodedCredentials = Base64.getEncoder().encodeToString((credentials.getUsername() + ":" + credentials.getPassword()).getBytes());
		return HttpRequest.newBuilder()
			.uri(uri)
			.header("Authorization", "Basic " + encodedCredentials);
	}

	private URI makeTelematicKeysUri() {
		var baseUrl = stage.urls().msClearance();
		return URI.create(baseUrl + "/otpclearance/api/tpadmin/v1/telematickeys");
	}

	private URI makeContainersUri() {
		return makeContainersUri(null);
	}

	private URI makeContainersUri(String containerId) {
		var baseUrl = stage.urls().msClearance();
		var thirdPartyId = stage.thirdPartyPortal().id().get();
		var appendix = containerId != null ? "/" + containerId : "";
		return URI.create(baseUrl + "/otpclearance/api/tpadmin/v1/thirdparties/" + thirdPartyId + "/containers" + appendix);
	}

	private String makeCreateRequestBody(String title, String description, List<TelematicBusinessId> keys) throws JsonProcessingException {
		var dto = new CreateContainerRequest(title, description, description, keys);
		return new ObjectMapper().writeValueAsString(dto);
	}

	private record CreateContainerRequest(String title, String description, String clearanceRequestMessage, List<TelematicBusinessId> telematicKeys) {}
	private record CreateContainerResponse(String containerId, String description, String clearanceRequestMessage, List<TelematicBusinessId> telematicKeys) {}
	public record TelematicBusinessId(String businessId) {}

	public List<TelematicBusinessId> allTelematicKeys() {
		try {
			return fetchAvailableTelematicKeys();
		} catch (IOException | InterruptedException e) {
			throw new RuntimeException(e);
		}
	}

	public List<TelematicBusinessId> allTelematicKeysStatic() {
		return allTelematicKeyStrings()
			.stream()
			.map(TelematicBusinessId::new)
			.toList();
	}

	private List<String> allTelematicKeyStrings() {
		return List.of(
			"vehicle.body.chargingPort.dcStatus",
			"vehicle.body.chargingPort.isHospitalityActive",
			"vehicle.body.chargingPort.status",
			"vehicle.body.flap.isLocked",
			"vehicle.body.flap.isPermanentlyUnlocked",
			"vehicle.body.hood.isOpen",
			"vehicle.body.lights.isRunningOn",
			"vehicle.body.trunk.isOpen",
			"vehicle.body.trunk.window.isOpen",
			"vehicle.cabin.convertible.roofStatus",
			"Vehicle.Cabin.Door.Lock.Status",
			"vehicle.cabin.door.row1.driver.isOpen",
			"vehicle.cabin.door.row1.passenger.isOpen",
			"vehicle.cabin.door.row2.driver.isOpen",
			"vehicle.cabin.door.row2.passenger.isOpen",
			"vehicle.cabin.door.status",
			"Vehicle.Cabin.Hvac.AmbientAirTemperature",
			"vehicle.cabin.infotainment.displayUnit.distance",
			"vehicle.cabin.infotainment.isMobilePhoneConnected",
			"vehicle.cabin.infotainment.navigation.currentLocation.altitude",
			"vehicle.cabin.infotainment.navigation.currentLocation.heading",
			"vehicle.cabin.infotainment.navigation.currentLocation.latitude",
			"vehicle.cabin.infotainment.navigation.currentLocation.longitude",
			"Vehicle.Cabin.Infotainment.Navigation.CurrentLocation.PositionUpdate.Notification",
			"vehicle.cabin.infotainment.navigation.destinationSet.arrivalTime",
			"vehicle.cabin.infotainment.navigation.destinationSet.distance",
			"Vehicle.Cabin.Infotainment.Navigation.DestinationSet.Latitude",
			"Vehicle.Cabin.Infotainment.Navigation.DestinationSet.Longitude",
			"vehicle.cabin.infotainment.navigation.pointsOfInterests.available",
			"vehicle.cabin.infotainment.navigation.pointsOfInterests.max",
			"vehicle.cabin.infotainment.navigation.remainingRange",
			"vehicle.cabin.sunroof.position",
			"vehicle.cabin.sunroof.status",
			"vehicle.cabin.sunroof.tiltStatus",
			"vehicle.cabin.window.row1.driver.status",
			"vehicle.cabin.window.row1.passenger.status",
			"vehicle.cabin.window.row2.driver.status",
			"vehicle.cabin.window.row2.passenger.status",
			"vehicle.channel.ngtp.timeVehicle",
			"vehicle.channel.teleservice.lastAutomaticServiceCallTime",
			"vehicle.channel.teleservice.lastBatteryGuardCallTime",
			"vehicle.channel.teleservice.status",
			"vehicle.chassis.axle.row1.wheel.center.tire.pressure",
			"vehicle.chassis.axle.row1.wheel.center.tire.pressureLow",
			"vehicle.chassis.axle.row1.wheel.left.tire.pressure",
			"vehicle.chassis.axle.row1.wheel.left.tire.pressureTarget",
			"vehicle.chassis.axle.row1.wheel.right.tire.pressure",
			"vehicle.chassis.axle.row1.wheel.right.tire.pressureTarget",
			"vehicle.chassis.axle.row2.wheel.center.tire.pressure",
			"vehicle.chassis.axle.row2.wheel.center.tire.pressureLow",
			"vehicle.chassis.axle.row2.wheel.left.tire.pressure",
			"vehicle.chassis.axle.row2.wheel.left.tire.pressureTarget",
			"vehicle.chassis.axle.row2.wheel.right.tire.pressure",
			"vehicle.chassis.axle.row2.wheel.right.tire.pressureTarget",
			"vehicle.chassis.axle.wheel.tire.diagnosis",
			"vehicle.chassis.axle.wheel.tire.serviceDemand.notification",
			"vehicle.drivetrain.avgElectricRangeConsumption",
			"vehicle.drivetrain.batteryManagement.batterySizeMax",
			"vehicle.drivetrain.batteryManagement.header",
			"vehicle.drivetrain.batteryManagement.maxEnergy",
			"vehicle.drivetrain.batteryManagement.statusBatteryGuard",
			"vehicle.drivetrain.electricEngine.charging.acAmpere",
			"vehicle.drivetrain.electricEngine.charging.acRestriction.isChosen",
			"vehicle.drivetrain.electricEngine.charging.acVoltage",
			"vehicle.drivetrain.electricEngine.charging.connectionType",
			"vehicle.drivetrain.electricEngine.charging.hvpmFinishReason",
			"vehicle.drivetrain.electricEngine.charging.isSingleImmediateCharging",
			"vehicle.drivetrain.electricEngine.charging.level",
			"vehicle.drivetrain.electricEngine.charging.method",
			"vehicle.drivetrain.electricEngine.charging.notification",
			"vehicle.drivetrain.electricEngine.charging.phaseNumber",
			"vehicle.drivetrain.electricEngine.charging.profile.mode",
			"vehicle.drivetrain.electricEngine.charging.remainingTimeSme",
			"vehicle.drivetrain.electricEngine.charging.smeEnergyDeltaFullyCharged",
			"vehicle.drivetrain.electricEngine.charging.status",
			"vehicle.drivetrain.electricEngine.charging.timeRemaining",
			"vehicle.drivetrain.electricEngine.charging.timeToFullyCharged",
			"vehicle.drivetrain.electricEngine.charging.windowSelection",
			"vehicle.drivetrain.electricEngine.hvsMaxEnergyAbsolute",
			"vehicle.drivetrain.electricEngine.kombiRemainingElectricRange",
			"vehicle.drivetrain.electricEngine.remainingElectricRange",
			"vehicle.drivetrain.engine.isActive",
			"vehicle.drivetrain.engine.isIgnitionOn",
			"vehicle.drivetrain.fuelSystem.averageConsumption",
			"vehicle.drivetrain.fuelSystem.level",
			"vehicle.drivetrain.fuelSystem.remainingFuel",
			"vehicle.drivetrain.internalCombustionEngine.engine.ect",
			"vehicle.drivetrain.totalRemainingRange",
			"vehicle.electricalSystem.battery.serviceDemand.recharge",
			"vehicle.electricalSystem.battery.serviceDemand.replace",
			"Vehicle.ElectricalSystem.Battery.StateOfCharge",
			"Vehicle.ElectricalSystem.Battery.StateOfChargePlausibility",
			"vehicle.electricalSystem.battery.voltage",
			"Vehicle.ElectricalSystem.Battery48V.StateOfHealth.Displayed",
			"vehicle.electronicControlUnit.diagnosticTroubleCodes.raw",
			"vehicle.extras.optionalEquipment.code",
			"vehicle.isMoving",
			"vehicle.learningNavigation",
			"vehicle.look.image",
			"vehicle.powertrain.electric.battery.charging.acLimit.isActive",
			"vehicle.powertrain.electric.battery.charging.acLimit.max",
			"vehicle.powertrain.electric.battery.charging.acLimit.min",
			"vehicle.powertrain.electric.battery.charging.acLimit.selected",
			"vehicle.powertrain.electric.battery.charging.acousticLimit",
			"vehicle.powertrain.electric.battery.charging.history.sessionsList",
			"vehicle.powertrain.electric.battery.charging.preferenceSmartCharging",
			"Vehicle.Powertrain.Electric.Battery.Charging.SettingsList",
			"vehicle.powertrain.electric.battery.stateOfCharge.displayed",
			"vehicle.powertrain.electric.battery.stateOfCharge.target",
			"Vehicle.Powertrain.Electric.Battery.StateOfHealth.Displayed",
			"vehicle.powertrain.electric.chargingDuration.displayControl",
			"vehicle.powertrain.electric.departureTime.displayControl",
			"vehicle.powertrain.electric.range.target",
			"vehicle.powertrain.tractionBattery.demandNotifications",
			"vehicle.serviceDemand.ccm.notification",
			"vehicle.sim.status",
			"Vehicle.Status.CallEvents.AutomaticAccidentCall.Notification",
			"Vehicle.Status.CallEvents.AutomaticEmergencyCall.Notification",
			"Vehicle.Status.CallEvents.ManualAccidentCall.Notification",
			"Vehicle.Status.CallEvents.ManualEmergencyCall.Notification",
			"Vehicle.Status.CallEvents.RoadsideAssistanceCall.Notification",
			"vehicle.status.checkControlMessages",
			"vehicle.status.conditionBasedServices",
			"vehicle.status.conditionBasedServicesCount",
			"vehicle.status.lastService.mileage",
			"vehicle.status.lastService.timestamp",
			"vehicle.status.serviceDistance.next",
			"vehicle.status.serviceDistance.yellow",
			"vehicle.status.serviceTime.hUandAuServiceYellow",
			"vehicle.status.serviceTime.inspectionDateLegal",
			"vehicle.status.serviceTime.yellow",
			"vehicle.trip.segment.accumulated.acceleration.starsAverage",
			"vehicle.trip.segment.accumulated.chassis.brake.starsAverage",
			"vehicle.trip.segment.accumulated.drivetrain.electricEngine.energyConsumptionComfort",
			"vehicle.trip.segment.accumulated.drivetrain.electricEngine.recuperationTotal",
			"vehicle.trip.segment.accumulated.drivetrain.transmission.setting.fractionDriveEcoPro",
			"vehicle.trip.segment.accumulated.drivetrain.transmission.setting.fractionDriveEcoProPlus",
			"vehicle.trip.segment.accumulated.drivetrain.transmission.setting.fractionDriveElectric",
			"vehicle.trip.segment.end.drivetrain.batteryManagement.hvSoc",
			"vehicle.trip.segment.end.time",
			"vehicle.trip.segment.end.travelledDistance",
			"vehicle.tripMeterReading1",
			"vehicle.tripMeterReading2",
			"vehicle.vehicle.averageWeeklyDistanceLongTerm",
			"vehicle.vehicle.averageWeeklyDistanceShortTerm",
			"vehicle.vehicle.avgAuxPower",
			"vehicle.vehicle.avgSpeed",
			"vehicle.vehicle.deepSleepModeActive",
			"vehicle.vehicle.preConditioning.activity",
			"vehicle.vehicle.preConditioning.error",
			"vehicle.vehicle.preConditioning.isRemoteEngineRunning",
			"vehicle.vehicle.preConditioning.isRemoteEngineStartAllowed",
			"vehicle.vehicle.preConditioning.remainingTime",
			"vehicle.vehicle.timeSetting",
			"vehicle.vehicle.travelledDistance",
			"vehicle.vehicle.tripDuration",
			"vehicle.vehicleIdentification.basicVehicleData"
		);
	}
}
