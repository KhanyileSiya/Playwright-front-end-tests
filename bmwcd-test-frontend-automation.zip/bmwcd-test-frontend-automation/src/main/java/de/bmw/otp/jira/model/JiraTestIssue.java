package de.bmw.otp.jira.model;

import java.util.List;

public record JiraTestIssue(List<JiraIssue> success, List<Object> error) {
}
