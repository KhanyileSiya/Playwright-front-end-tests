package de.bmw.otp.jira.model;

public record JiraAttachment(String id, String self, String filename) {
}
