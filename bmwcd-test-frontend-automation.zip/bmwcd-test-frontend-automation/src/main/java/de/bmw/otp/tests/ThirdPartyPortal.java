package de.bmw.otp.tests;

import java.util.function.Supplier;

public record ThirdPartyPortal(String url, Credentials credentials, Supplier<String> id) {
}
