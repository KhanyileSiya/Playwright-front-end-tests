package de.bmw.otp.tests.config;

import de.bmw.otp.tests.Credentials;
import de.bmw.otp.tests.EnvVar;

public class CardataCredentials {
	public static final Credentials API_CLIENT_INT = Credentials.fromEnv(EnvVar.CARDATA_CLIENT_ID_INT, EnvVar.CARDATA_CLIENT_SECRET_INT);
	public static final Credentials API_CLIENT_E2E = Credentials.fromEnv(EnvVar.CARDATA_CLIENT_ID_E2E, EnvVar.CARDATA_CLIENT_SECRET_E2E);
	public static final Credentials API_CLIENT_PROD = Credentials.fromEnv(EnvVar.CARDATA_CLIENT_ID_PROD, EnvVar.CARDATA_CLIENT_SECRET_PROD);

	public static final Credentials CLEARANCE_BACKEND_BASIC_INT = Credentials.fromEnv(EnvVar.CLEARANCE_BACKEND_USER_INT, EnvVar.CLEARANCE_BACKEND_PW_INT);
	public static final Credentials CLEARANCE_BACKEND_BASIC_E2E = Credentials.fromEnv(EnvVar.CLEARANCE_BACKEND_USER_E2E, EnvVar.CLEARANCE_BACKEND_PW_E2E);
	public static final Credentials CLEARANCE_BACKEND_BASIC_PROD = Credentials.fromEnv(EnvVar.CLEARANCE_BACKEND_USER_PROD, EnvVar.CLEARANCE_BACKEND_PW_PROD);

	public static final Credentials THIRD_PARTY_SIM_TEST = Credentials.fromEnv(EnvVar.THIRD_PARTY_SIM_USER_TEST, EnvVar.THIRD_PARTY_SIM_PW_TEST);
	public static final Credentials THIRD_PARTY_SIM_PROD = Credentials.fromEnv(EnvVar.THIRD_PARTY_SIM_USER_PROD, EnvVar.THIRD_PARTY_SIM_PW_PROD);

	public static final Credentials THIRD_PARTY_PORTAL_E2E = Credentials.fromEnv(EnvVar.THIRD_PARTY_PORTAL_USER_E2E, EnvVar.THIRD_PARTY_PORTAL_PW_E2E);
	public static final Credentials THIRD_PARTY_PORTAL_PROD = Credentials.fromEnv(EnvVar.THIRD_PARTY_PORTAL_USER_PROD, EnvVar.THIRD_PARTY_PORTAL_PW_PROD);

	public static final Credentials CUSTOMER_PORTAL_E2E = Credentials.fromEnv(EnvVar.CUSTOMER_PORTAL_USER_NAME_E2E, EnvVar.CUSTOMER_PORTAL_PASSWORD_E2E);
	public static final Credentials CUSTOMER_PORTAL_PROD = Credentials.fromEnv(EnvVar.CUSTOMER_PORTAL_USER_NAME_PROD, EnvVar.CUSTOMER_PORTAL_PASSWORD_PROD);

	public static final Credentials CUSTOMER_PORTAL_BASIC_E2E = Credentials.fromEnv(EnvVar.CUSTOMER_PORTAL_BASIC_USER_NAME_E2E, EnvVar.CUSTOMER_PORTAL_BASIC_PASSWORD_E2E);
}
