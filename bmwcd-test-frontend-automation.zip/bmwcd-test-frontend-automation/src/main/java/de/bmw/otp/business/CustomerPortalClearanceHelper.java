package de.bmw.otp.business;

public interface CustomerPortalClearanceHelper extends CustomerPortalHelper {
	@Override
	default String getAssignmentPopupButtonTextReject(){return "Bestätigen";}

}
