package de.bmw.otp.business;

import de.bmw.otp.tests.PdfHelper;
import de.bmw.otp.tests.Utils;
import de.bmw.otp.tests.WithCleanup;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.TestMethodOrder;

import java.io.IOException;
import java.util.Collections;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.not;
import static org.junit.jupiter.api.Assertions.assertTrue;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public abstract class AbstractResetAccountTests extends ThirdPartyBase implements CustomerPortalClearanceHelper, CustomerPortalAssignmentHelper, CustomerPortalHelper, ThirdPartyPortalHelper, ResetHelper, PdfHelper {

	@Override
	public String getSutVin() {
		return getVinPairOfStage().resetVin();
	}

	private static final String TESTING_CONTAINER_TITLE = Utils.withIdTrimmed("Playwright Reset Account ", 30);

	@Override
	public String getTestingContainerTitle() {
		return TESTING_CONTAINER_TITLE;
	}

	@BeforeAll
	static void setUpAll() {
		baseSetUpAll();
	}

	@BeforeEach
	void setUpEach(TestInfo testInfo) {
		getAssignmentClient().revokeAllAssignments(getSutVin());
		baseSetUp(getStage(), testInfo);
	}

	@AfterEach
	void tearDownEach() {
		baseTearDown();
	}

	@AfterAll
	static void tearDownAll() {
		baseTearDownAll();
	}

	@Test
	@Order(1)
	void testRequestTransactionReport() {
		openPageAndLoginAndSelectVin(getSutVin());

		requestTransactionReport();

		assertTransactionReportRequested();
	}

	@Test
	@Order(2)
	void testCreateContainer() {
		openAndLogin3rdPartyPortal();

		String containerId = createContainerByGui(getTestingContainerTitle());

		getClearanceClient().requestClearance(containerId, getSutVin());
	}


	@Test
	@Order(3)
	void testCheckRequestedClearanceAndApproveAndRequestTelematicData() {
		openAndLogin3rdPartyPortal();
		openContainerOverview();

		String containerId = findRegressionContainerAndGetContainerId();

		String clearanceId = getClearanceClient().requestClearance(containerId, getSutVin());

		openPageAndLoginAndSelectVin(getSutVin());

		acceptClearance(clearanceId, getTestingContainerTitle());
		//TODO: fails for brand = RR and DRITTKUNDE - current defect
		assertClearanceStatusApproved(containerId, getSutVin(), clearanceId);

		var response = getClearanceClient().requestTelematicData(clearanceId, getSutVin());
		log(response.toString());
		MatcherAssert.assertThat(response, not(equalTo(Collections.EMPTY_MAP)));
	}

	@Test
	@Order(4)
	void testApproveAssignmentAndGetStatus() {
		try (var assignment = this.assignmentRequestAndLogin()) {
			String assignmentUuid = assignment.val();

			acceptAssignment(assignmentUuid);
			assertAssignmentStatusAccepted(assignmentUuid);

			cancelRevokeAssignment();
			assertAssignmentStatusAccepted(assignmentUuid);
		}
	}

	@Test
	@Order(5)
	void testClickResetButtonAndCancel() {
		openPageAndLoginAndSelectVin(getSutVin());

		clickResetButtonAndCancel();
	}

	@Test
	@Order(6)
	void testClickResetButtonAndApprove() {
		openPageAndLoginAndSelectVin(getSutVin());

		clickResetButtonAndApprove();
	}

	@Test
	@Order(7)
	void testCheckResetClearance() {
		openPageAndLoginAndSelectVin(getSutVin());

		verifyClearanceDetails(getTestingContainerTitle(), getStatusRevoked());
	}

	@Test
	@Order(8)
	void testCheckResetAssignment() {
		openPageAndLoginAndSelectVin(getSutVin());

		verifyAssignmentDetails(getStatusWithdrawn());
	}

	@Test
	@Order(9)
	void testCheckTransactionReportStillAvailable() throws IOException {
		openPageAndLoginAndSelectVin(getSutVin());


		var pdf = download(() -> {
			getByText(getDownloadTransactionReportButtonText()).first().click();
		});
		validatePdf(pdf, (document, content) -> {
			assertTrue(content.contains(getTransactionReportAssertText()));
		});
	}

	@Test
	@Order(10)
	void testDeleteCreatedContainer() {
		openAndLogin3rdPartyPortal();
		openContainerOverview();

		findRegressionContainerAndDelete();

		locateElementWithText("tr", getTestingContainerTitle()).assertMissing();
	}

	@Test
	@Order(11)
	void testCheckAssignmentAfterReset() {
		try (var assignment = this.assignmentRequestAndLogin()) {
			String assignmentUuid = assignment.val();

			acceptAssignment(assignmentUuid);
			assertAssignmentStatusAccepted(assignmentUuid);

			revokeAssignment(assignmentUuid);
			assertAssignmentStatusRevoked(assignmentUuid);
		}
	}

	private WithCleanup<String> assignmentRequestAndLogin() {
		return WithCleanup.then(
			assignmentRequest(),
			() -> openPageAndLoginAndSelectVin(getSutVin()));
	}
}
