package de.bmw.otp.tests;

public interface Credentials {

	String getUsername();
	String getPassword();

	// Add this default HOTP secret getter
	default String getOtpSecret() {
		// Try to load from environment variable (recommended)
		String secret = System.getenv("OTP_SECRET");

		// ✅ Fallback for local testing (dummy base64 string)
		if (secret == null || secret.isBlank()) {
			// "mysecretkey123" base64-encoded
			secret = java.util.Base64.getEncoder().encodeToString("mysecretkey123".getBytes());
			System.out.println("⚠️  OTP_SECRET not set, using default local secret for testing.");
		}

		return secret;
	}

	static Credentials fromEnv(EnvVar user, EnvVar pw) {
		return new Credentials() {
			@Override
			public String getUsername() { return user.valOrThrow(); }

			@Override
			public String getPassword() { return pw.valOrThrow(); }
		};
	}
}
