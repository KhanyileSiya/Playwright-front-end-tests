package de.bmw.otp.jira.model;

public record JiraSummary(String id, String key, String self, JiraFields fields) {
}
