package de.bmw.otp.tests;

import static de.bmw.otp.tests.config.CardataCredentials.THIRD_PARTY_SIM_PROD;
import static de.bmw.otp.tests.config.CardataCredentials.THIRD_PARTY_SIM_TEST;

public enum SimulatorStage {
	TEST("https://thirdpartysim-test.otp.bmwhub.cloud", THIRD_PARTY_SIM_TEST),
	PROD("https://thirdpartysim.otp.bmwhub.cloud", THIRD_PARTY_SIM_PROD);

	private final String url;
	private final Credentials thirdPartySim;

	SimulatorStage(String url, Credentials thirdPartySim) {
		this.url = url;
		this.thirdPartySim = thirdPartySim;
	}

	public static SimulatorStage get() {
		return EnvVar.SIMULATOR_STAGE.val()
			.map(stage -> switch (stage) {
				case "TEST" -> SimulatorStage.TEST;
				case "PROD" -> SimulatorStage.PROD;
				default -> SimulatorStage.TEST;
			})
			.orElse(TEST);
	}

	public Credentials getUser() {
		return thirdPartySim;
	}

	public String getUrl() {
		return this.url;
	}
}
