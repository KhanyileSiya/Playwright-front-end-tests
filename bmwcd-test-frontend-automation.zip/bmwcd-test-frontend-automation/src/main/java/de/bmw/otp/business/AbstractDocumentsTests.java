package de.bmw.otp.business;

import de.bmw.otp.playwright.PlaywrightBase;
import de.bmw.otp.tests.PdfHelper;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertTrue;

public abstract class AbstractDocumentsTests extends PlaywrightBase implements CustomerPortalHelper, PdfHelper {

	public String getSutVin() {
		return getVinPairOfStage().vin();
	}

	@BeforeAll
	static void setUpAll() {
		baseSetUpAll();
	}

	@BeforeEach
	void setUpEach(TestInfo testInfo) {
		baseSetUp(getStage(), testInfo);
	}

	@AfterEach
	void tearDownEach() {
		baseTearDown();
	}

	@AfterAll
	static void tearDownAll() {
		baseTearDownAll();
	}

	@Test
	void testPdfTaC() throws IOException {
		openPageAndLoginAndSelectVin(getSutVin());
		var pdf = downloadTac();
		assertPdfsAreEqual(getRegressionFileTaC(), pdf);
	}

	@Test
	void testPdfDPP() throws IOException {
		openPageAndLoginAndSelectVin(getSutVin());
		var pdf = downloadDpp();
		assertPdfsAreEqual(getRegressionFileDPP(), pdf);
	}

	@Test
	void testRequestTransactionReport() throws IOException {
		openPageAndLoginAndSelectVin(getSutVin());
		requestTransactionReport();
		assertTransactionReportRequested();

		getPage().reload();

		var pdf = download(() -> {
			getByText(getDownloadTransactionReportButtonText()).first().click();
		});
		validatePdf(pdf, (document, content)-> {
			assertTrue(content.contains(getTransactionReportAssertText()));
		});
	}
}
