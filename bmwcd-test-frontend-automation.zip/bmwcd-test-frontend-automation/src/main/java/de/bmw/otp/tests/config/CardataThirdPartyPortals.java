package de.bmw.otp.tests.config;

import de.bmw.otp.tests.EnvVar;
import de.bmw.otp.tests.ThirdPartyPortal;

public interface CardataThirdPartyPortals {
	ThirdPartyPortal THIRD_PARTY_PORTAL_INT = new ThirdPartyPortal(CardataUrls.THIRD_PARTY_PORTAL_INT + "/public/home?withlogin=true", CardataCredentials.THIRD_PARTY_PORTAL_E2E, EnvVar.THIRD_PARTY_ID_INT::valOrThrow);
	ThirdPartyPortal THIRD_PARTY_PORTAL_E2E = new ThirdPartyPortal(CardataUrls.THIRD_PARTY_PORTAL_E2E + "/public/home?withlogin=true", CardataCredentials.THIRD_PARTY_PORTAL_E2E, EnvVar.THIRD_PARTY_ID_E2E::valOrThrow);
	ThirdPartyPortal THIRD_PARTY_PORTAL_PROD = new ThirdPartyPortal(CardataUrls.THIRD_PARTY_PORTAL_PROD + "/public/home?withlogin=true", CardataCredentials.THIRD_PARTY_PORTAL_PROD, EnvVar.THIRD_PARTY_ID_PROD::valOrThrow);
}
