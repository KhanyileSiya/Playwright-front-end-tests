package de.bmw.otp.business;

import de.bmw.otp.playwright.PlaywrightHelper;

public interface ResetHelper extends PlaywrightHelper {

	default void clickResetButtonAndCancel() {
		clickResetButton();
		getByTestId("resetCardataConfirmationPopupCancelButton").getByText("Zurück").click();
	}

	default void clickResetButtonAndApprove() {
		clickResetButton();
		getByTestId("resetCardataConfirmationPopupConfirmButton").getByText("Bestätigen").click();
	}

	default void clickResetButton() {
		getByText("Reset ausführen").click();
	}

}
