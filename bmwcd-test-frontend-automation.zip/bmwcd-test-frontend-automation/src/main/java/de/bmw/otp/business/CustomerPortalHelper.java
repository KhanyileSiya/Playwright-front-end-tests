package de.bmw.otp.business;

import com.microsoft.playwright.Frame;
import com.microsoft.playwright.Page;
import de.bmw.otp.playwright.KeyboardModifier;
import de.bmw.otp.playwright.LocatorHandle;
import de.bmw.otp.playwright.PageHandle;
import de.bmw.otp.tests.EnvVar;
import de.bmw.otp.tests.VinPair;

import java.io.File;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.Random;
import de.bmw.otp.tests.Utils;
import com.microsoft.playwright.Page;
import de.bmw.otp.tests.Utils;

import java.util.List;

public interface CustomerPortalHelper extends TestBase {

	VinPair getVinPairOfStage();

	String getBaseUrl();

	void verifyClearanceDetails(String testingContainerTitle, String status);

	default String getStatusNew() {
		return "Neu";
	}

	default String getStatusAccepted() {
		return "Zugestimmt";
	}

	default String getStatusRejected() {
		return "Abgelehnt";
	}

	default String getStatusRevoked() {
		return "Widerrufen";
	}

	default String getStatusWithdrawn() {
		return "Zurückgezogen";
	}

	default String getAssignmentPopupButtonTextReject() {
		return "Bestätigen";
	}

	default String getClearancePopupButtonTextReject() {
		return "Bestätigen";
	}

	default String getClearancePopupButtonTextCancel() {
		return "Abbrechen";
	}

	;

	default String getAssignmentPopupButtonTextCancel() {
		return "Zurück";
	}

	;

	default String getTextRequestTransactionReport() {
		return "Transaktionsreport anfordern";
	}

	default String getDataPacketText() {
		return "Datenpaket";
	}

	default String getDownloadTransactionReportButtonText() {
		return "Transaktionsreport herunterladen";
	}

	default String getTransactionReportAssertText() {
		return "Folgende Unternehmen haben die meisten Datenabrufe durchgeführt";
	}

	default String getTacButtonText() {
		return "Nutzungsbedingungen";
	}

	default String getPrivacyButtonText() {
		return "Datenschutzbestimmungen";
	}

	Path getRegressionCustomerPortalFolder();

	default File getRegressionFileTaC() {
		return getRegressionFile(Path.of("CARDATA_TAC.pdf")).toFile();
	}

	default File getRegressionFileDPP() {
		return getRegressionFile(Path.of("CARDATA_DPP.pdf")).toFile();
	}

	default Path getRegressionFile(Path filename) {
		return getRegressionCustomerPortalFolder().resolve(filename);
	}

	void openPageAndLogin();

	default void openPageAndLogin(String textContinue, String textLogin) {
		logMethodCall();
		var credentials = getStage().customerPortalLogin();
		var page = getPage();
		var url = getBaseUrl() + "/vehicle-overview";
		page.navigate(url);

//===================Pre-Authentication
		boolean isPreLoginVisible = false;

		try {
			System.out.println("====== Checking for BMW pre-authentication screen...");
			System.out.println("====== DEBUG: Current page methods ===========");
			for (Method m : page.getClass().getMethods()) {
				System.out.println(" -> " + m.getName());
			}
			System.out.println("==============================================");

			// Wait a bit for page to stabilize after navigation or refresh
			Utils.waitForPageStable(page, 8000);


			String rawHtml = Utils.getPageHtmlDebug(page);
			System.out.println("====== DEBUG: Captured HTML Snippet (first 500 chars) ======");
			System.out.println(rawHtml == null ? "NULL HTML" :
				rawHtml.substring(0, Math.min(500, rawHtml.length())));
			System.out.println("============================================================");

			// Check current URL first (fastest)
			String currentUrl = Utils.getPageUrl(page).toLowerCase();
			if (currentUrl.contains("auth.bmwgroup.net") || currentUrl.contains("login.bmwgroup.com")) {
				isPreLoginVisible = true;
				System.out.println("Detected pre-auth via URL: " + currentUrl);
			}

			// Look for pre-auth text (handles multiple languages and variants)
			if (!isPreLoginVisible) {
				String[] preAuthTexts = {
					"authentis methode",
					"authentication method",
					"starke authentifizierung",
					"strong authentication",
					"yubikey",
					"pin+yubikey",
					"aep pin"
				};

				for (String text : preAuthTexts) {
					if (Utils.textExists(page, text, 5000)) {
						isPreLoginVisible = true;
						System.out.println("Detected pre-auth text: " + text);
						break;
					}
				}
			}

			// Look for key elements on screen
			if (!isPreLoginVisible) {
				String[] selectors = {
					"button:has-text('PIN+Yubikey')",
					"input[name='aepPin']",
					"input[id*='PIN']",
					"input[type='password']",
					"[data-testid='authentication-method']"
				};

				for (String selector : selectors) {
					if (Utils.elementExists(page, selector, 5000)) {
						isPreLoginVisible = true;
						System.out.println("Detected pre-auth element: " + selector);
						break;
					}
				}
			}

			// Fallback: detect iframe pointing to BMW auth domain
			if (!isPreLoginVisible && Utils.pageContainsIframe(page, "auth.bmwgroup.net")) {
				isPreLoginVisible = true;
				System.out.println("Detected pre-auth iframe containing BMW auth domain.");
			}

			if (isPreLoginVisible) {
				System.out.println("====== Pre-authentication screen detected.");

				try {
					// 🔐 Step 1: Perform pre-login authentication (PIN + YubiKey)
					performPreLoginAuth(page);

					// 🔍 Step 2: Unwrap Playwright Page
					com.microsoft.playwright.Page rawPage;
					try {
						var field = page.getClass().getDeclaredField("page");
						field.setAccessible(true);
						rawPage = (com.microsoft.playwright.Page) field.get(page);
					} catch (Exception e) {
						throw new RuntimeException("Unable to unwrap Playwright Page from PageHandle", e);
					}

					// 💾 Step 3: Save session immediately after pre-auth
					System.out.println("====== Saving session immediately after YubiKey pre-auth...");
					Utils.saveCleanSession(rawPage);

					Path sessionPath = Paths.get("src/main/resources/seeds/session-state.json");
					if (Files.exists(sessionPath)) {
						System.out.println("====== Pre-auth session successfully saved at: " + sessionPath.toAbsolutePath());
					} else {
						System.out.println("====== Session file missing after save attempt!");
					}

				} catch (Exception e) {
					System.out.println("Failed to save session after pre-auth: " + e.getMessage());
					e.printStackTrace();
				}

			} else {
				System.out.println("====== No pre-authentication detected, proceeding with standard login...");
			}


		} catch (Exception e) {
			System.out.println("====== Error during pre-auth detection: " + e.getMessage());
			isPreLoginVisible = false;
		}


// Perform pre-login step if detected
		if (isPreLoginVisible) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException ignored) {
				Thread.currentThread().interrupt();
			}
			performPreLoginAuth(page);
				}

// ============
		// Step 2: Continue with username/password login
		select("#username").fill(credentials.getUsername());
		clickCheckError(locateButton(textContinue));
		waitForSelector("#password");
		select("#password").fill(credentials.getPassword());
		clickCheckError(locateButton(textLogin));
	}

	// ------------------------------------------------------------------------
	// Detect if pre-authentication page or frame is visible
	// ------------------------------------------------------------------------
	default boolean isPreAuthVisible(PageHandle page, int timeoutMillis, String... selectors) {
		com.microsoft.playwright.Page rawPage;
		try {
			var field = page.getClass().getDeclaredField("page");
			field.setAccessible(true);
			rawPage = (com.microsoft.playwright.Page) field.get(page);
		} catch (Exception e) {
			throw new RuntimeException("====== Unable to unwrap Playwright Page from PageHandle", e);
		}

		Frame authFrame = null;
		System.out.println("====== Checking for BMW pre-authentication frame or redirect...");

		// Check if redirected directly to auth.bmwgroup.net
		if (rawPage.url().contains("auth.bmwgroup.net")) {
			authFrame = rawPage.mainFrame();
		} else {
			try {
				rawPage.waitForSelector("iframe",
					new com.microsoft.playwright.Page.WaitForSelectorOptions().setTimeout(timeoutMillis));
				for (Frame frame : rawPage.frames()) {
					if (frame.url().contains("auth.bmwgroup.net")) {
						authFrame = frame;
						break;
					}
				}
			} catch (Exception e) {
				// No iframe found within timeout
			}
		}

		if (authFrame == null) {
			System.out.println("====== No pre-authentication frame or redirect detected.");
			return false;
		}

		// Now check for visible text in that auth frame
		for (String selector : selectors) {
			try {
				authFrame.waitForSelector(selector,
					new com.microsoft.playwright.Frame.WaitForSelectorOptions().setTimeout(timeoutMillis));
				System.out.println("====== Found pre-auth locator: " + selector);
				return true;
			} catch (Exception e) {
				// Try next selector
			}
		}

		System.out.println("====== Pre-authentication frame found, but expected text not visible yet.");
		return false;
	}

	// ------------------------------------------------------------------------
	// Handles pre-login step with AEP PIN + HOTP (YubiKey-based)
	// ------------------------------------------------------------------------
	default void performPreLoginAuth(PageHandle page) {
		logMethodCall("performPreLoginAuth");

		// --- Safely unwrap Playwright Page ---
		com.microsoft.playwright.Page rawPage;
		try {
			var field = page.getClass().getDeclaredField("page");
			field.setAccessible(true);
			rawPage = (com.microsoft.playwright.Page) field.get(page);
		} catch (Exception e) {
			throw new RuntimeException("Unable to unwrap Playwright Page from PageHandle", e);
		}

		// --- Detect auth frame or redirect ---
		Frame authFrame = null;
		rawPage.waitForTimeout(2000);

		if (rawPage.url().contains("auth.bmwgroup.net")) {
			authFrame = rawPage.mainFrame();
		} else {
			try {
				rawPage.waitForSelector("iframe");
				for (Frame frame : rawPage.frames()) {
					if (frame.url().contains("auth.bmwgroup.net")) {
						authFrame = frame;
						break;
					}
				}
			} catch (Exception ignored) {}
		}

		if (authFrame == null) {
			throw new RuntimeException("Could not find BMW authentication frame!");
		}

		System.out.println("====== Using authentication frame: " + authFrame.url());

		// --- Perform login steps ---
		authFrame.waitForSelector("text=/authentis.*methode/i");

		authFrame.locator("input[placeholder='Nutzername'], input[placeholder='Username']").fill("QDBBBA2");

		if (authFrame.getByText("WEITER").isVisible()) {
			authFrame.getByText("WEITER").click();
		} else {
			authFrame.getByText("NEXT").click();
		}

		authFrame.waitForSelector("input[placeholder='AEP PIN']");
		authFrame.locator("input[placeholder='AEP PIN']").fill("3698");

// --- Generate HOTP for PROD seed ---
		String hotp;
		try {
			System.out.println("====== Generating HOTP from PROD YubiKey seed...");

			// Generate or reuse single session HOTP
			hotp = Utils.getOrCreateSessionHotp();

			System.out.println("==============================================");
			System.out.println("====== Generated YubiKey HOTP (via PROD seed file)");
			System.out.println("   HOTP    = " + hotp);
			System.out.println("==============================================");

		} catch (Exception e) {
			System.err.println("Failed to generate HOTP: " + e.getMessage());
			e.printStackTrace();
			throw new RuntimeException("Error generating PROD HOTP", e);
		}

// --- Fill in HOTP ---
		logMethodCall("====== Generated HOTP (YubiKey)", "value=" + hotp);
		authFrame.locator("input[placeholder='HOTP(Yubikey)'], input[placeholder='HOTP (Yubikey)']").fill(hotp);

// --- Submit ---
		if (authFrame.getByText("SENDEN").isVisible()) {
			authFrame.getByText("SENDEN").click();
		} else {
			authFrame.getByText("SUBMIT").click();
		}

// --- Wait until login completes ---
		rawPage.waitForSelector("#username");
	}

	default void openPageAndLoginAndSelectVin(String vin) {
		openPageAndLogin();
		selectVin(vin);
	}

	default void selectVin(String vin) {
		logMethodCall(vin);
		clickCheckError(locateVehicleSelection(vin));
	}

	default LocatorHandle locateVehicleSelection(String vin) {
		return getByTestId("fullyMapped")
			.filterHasText("VIN: " + vin)
			.select("[data-tracking-linkid='myb > link to car data']");
	}

	default void requestTransactionReport() {
		logMethodCall();
		clickCheckError(getByTestId("createReport").getByText(getTextRequestTransactionReport()));
		//The following check only happens if there is already a report that will be overridden
		clickCheckError(locateTransactionConfirmButton());
	}

	void assertTransactionReportRequested();

	default void assertTransactionReportRequested(String identifier) {
		logMethodCall();
		select("#chakra-toast-manager-top")
			.getByTestId("successNotificationTitle")
			.getByText("Wenn Sie die Benachrichtigungsfunktion aktiviert haben, werden Sie informiert, sobald der " + identifier + " Transaktionsreport verfügbar ist.")
			.assertVisible();

		locateClassWithText("chakra-alert", "Ihr " + identifier + " Transaktionsreport wird erstellt").assertVisible();
	}

	LocatorHandle locateAccessPermission();

	LocatorHandle locateServicefreigaben();

	default LocatorHandle locateAccessPermissionText(){
		return locateClassWithText("chakra-text", "wer bereits dazu berechtigt ist");
	}

	default LocatorHandle locateServicefreigabenText(){
		return locateClassWithText("chakra-text", "welchen unabhängigen Anbietern Sie");
	}

	default LocatorHandle locateAssignmentTile() {
		return getByTestId("serviceAccessPermissionTile");
	}

	default LocatorHandle locateClearanceTiles() {
		return getByTestId("clearanceTile");
	}

	default LocatorHandle locateClearanceTile(String testingContainerTitle) {
		logMethodCall(testingContainerTitle);
		if(testingContainerTitle != null) {
			return locateClearanceTiles().filterHasText(testingContainerTitle);
		} else {
			return locateClearanceTiles();
		}
	}

	default LocatorHandle locateAssignmentPopupButtonConfirm() {
		return getByTestId("serviceAccessPermissionPopupConfirmButton");
	}

	default LocatorHandle locateAssignmentPopupButtonCancel() {
		return getByTestId("serviceAccessPermissionPopupCancelButton");
	}

	default LocatorHandle locateClearancePopupButtonConfirm() {
		return getByTestId("clearancePermissionPopupConfirmButton");
	}

	default LocatorHandle locateClearancePopupButtonCancel() {
		return getByTestId("clearancePermissionPopupCancelButton");
	}

	default LocatorHandle locateAccessPopupButtonConfirm() {
		return getByTestId("accessPermissionConfirmationPopupConfirmButton");
	}

	default LocatorHandle locateAccessPopupButtonCancel() {
		return getByTestId("accessPermissionConfirmationPopupCancelButton");
	}

	default LocatorHandle locateAssignmentModifiedDate(LocatorHandle tile) {
		return tile.getByTestId("modifiedDateKey").getByText("Geändert am");
	}

	default LocatorHandle locateAssignmentPersonalMessage() {
		return locateClassWithText("chakra-heading", "Persönliche Nachricht zum Antrag mit Verwendungszweck");
	}

	default LocatorHandle locateAssignmentPartnerDetails() {
		return getByText("Details zum Service Service Partner");
	}

	default LocatorHandle locateClearanceRequestDetails() {
		return getByText("Details zum Antrag", true);
	}

	default LocatorHandle locateTransactionConfirmButton(){
		return getByTestId("transactionReportConfirmationPopupConfirmButton").getByText("Bestätigen");
	}

	default void clickTileAccept(LocatorHandle tile) {
		clickCheckError(tile.getByTestId("accept"));
	}

	default void clickTileReject(LocatorHandle tile) {
		clickCheckError(tile.getByTestId("reject"));
	}

	default void clickTilePopupAccept(LocatorHandle popup) {
		clickCheckError(popup.getByText("Bestätigen"));
	}

	default void clickTilePopupRevoke(LocatorHandle popup) {clickCheckError(popup.getByText("Widerrufen"));}

	default void clickClearanceTilePopupCancel(LocatorHandle popup) {clickCheckError(popup.getByText(getClearancePopupButtonTextCancel()));}
	default void clickAssignmentTilePopupCancel(LocatorHandle popup) {clickCheckError(popup.getByText(getAssignmentPopupButtonTextCancel()));}
	default void clickDetailsCancel(LocatorHandle popup) {clickCheckError(popup.getByText("Zurück"));}

	default void clickAssignmentTilePopupReject(LocatorHandle popup) {
		clickCheckError(popup.getByText(getAssignmentPopupButtonTextReject()));
	}
	default void clickClearanceTilePopupReject(LocatorHandle popup) {
		clickCheckError(popup.getByText(getClearancePopupButtonTextReject()));
	}

	default void acceptClearance(String clearanceId, String testingContainerTitle) {
		logMethodCall(clearanceId, testingContainerTitle);
		clickTileAccept(locateClearanceTile(testingContainerTitle));
		waitForClearanceAccept(clearanceId, () -> {
			clickTilePopupAccept(locateAccessPopupButtonConfirm());
		});
	}

	default void rejectClearance(String clearanceId, String testingContainerTitle) {
		logMethodCall(clearanceId, testingContainerTitle);
		clickTileReject(locateClearanceTile(testingContainerTitle));
		waitForClearanceReject(clearanceId, () -> {
			clickClearanceTilePopupReject(locateAccessPopupButtonConfirm());
		});
	}

	default void revokeClearance(String clearanceId, String clearanceTitle) {
		logMethodCall(clearanceId, clearanceTitle);
		clickClearanceRevoke(clearanceTitle);
		waitForClearanceRevoke(clearanceId, () -> {
			clickTilePopupAccept(locateAccessPopupButtonConfirm());
		});
	}

	default void cancelRejectClearance(String clearanceId, String testingContainerTitle) {
		logMethodCall(clearanceId);
		clickClearanceReject(testingContainerTitle);
		clickClearanceTilePopupCancel(locateAccessPopupButtonCancel());
	}

	default void cancelRevokeClearance(String testingContainerTitle) {
		logMethodCall(testingContainerTitle);
		clickClearanceRevoke(testingContainerTitle);
		clickClearanceTilePopupCancel(locateAccessPopupButtonCancel());
	}

	default void clickClearanceReject(String testingContainerTitle) {
		logMethodCall(testingContainerTitle);
		clickCheckError(locateClearanceTile(testingContainerTitle).getByTestId("reject"));
	}

	default void clickClearanceRevoke(String testingContainerTitle) {
		clickCheckError(locateClearanceTile(testingContainerTitle).getByTestId("revoke"));
	}

	default void acceptAssignment(String uuid) {
		logMethodCall(uuid);
		clickTileAccept(locateAssignmentTile());
		waitForAssignmentAccept(uuid, () -> {
			clickTilePopupAccept(locateAssignmentPopupButtonConfirm());
		});
	}

	default void rejectAssignment(String uuid) {
		logMethodCall(uuid);
		clickCheckError(locateAssignmentTile().getByTestId("reject"));
		waitForAssignmentReject(uuid, () -> {
			clickAssignmentTilePopupReject(locateAssignmentPopupButtonConfirm());
		});
	}

	default void revokeAssignment(String uuid) {
		logMethodCall(uuid);
		clickLatestAssignmentRevoke();
		waitForAssignmentRevoke(uuid, () -> {
			clickTilePopupRevoke(locateAssignmentPopupButtonConfirm());
		});
	}

	default void cancelRevokeAssignment() {
		logMethodCall();
		clickLatestAssignmentRevoke();
		clickAssignmentTilePopupCancel(locateAssignmentPopupButtonCancel());
	}

	default void clickLatestAssignmentRevoke() {
		logMethodCall();
		clickCheckError(locateAssignmentTile().getByTestId("revoke"));
	}

	default void waitForClearanceAccept(String clearanceId, Runnable triggerRequest) {
		waitForClearanceStatus(clearanceId, "APPROVED", triggerRequest);
	}

	default void waitForClearanceRevoke(String clearanceId, Runnable triggerRequest) {
		waitForClearanceStatus(clearanceId, "REVOKED", triggerRequest);
	}

	default void waitForClearanceReject(String clearanceId, Runnable triggerRequest) {
		waitForClearanceStatus(clearanceId, "REJECTED", triggerRequest);
	}

	private void waitForAssignmentAccept(String assignmentUuid, Runnable triggerRequest) {
		waitForAssignmentStatus(assignmentUuid, "ACCEPT", triggerRequest);
	}

	private void waitForAssignmentRevoke(String assignmentUuid, Runnable triggerRequest) {
		waitForAssignmentStatus(assignmentUuid, "WITHDRAW", triggerRequest);
	}

	private void waitForAssignmentReject(String assignmentUuid, Runnable triggerRequest) {
		waitForAssignmentStatus(assignmentUuid, "REJECT", triggerRequest);
	}

	private void waitForClearanceStatus(String clearanceId, String status, Runnable triggerRequest) {
		var id = new Random().nextInt();
		if (EnvVar.DEBUG_LOGGING.isTrue()) {
			System.out.printf("WAITING id=%d thread=%s%n", id, Thread.currentThread().threadId());
		}
		waitForResponse("**/cardata/clearance/%s/status?status=%s".formatted(clearanceId, status), triggerRequest);
		if (EnvVar.DEBUG_LOGGING.isTrue()) {
			System.out.printf("WAITING id=%d thread=%s done%n", id, Thread.currentThread().threadId());
		}
		postResponseHook();
	}

	private void waitForAssignmentStatus(String assignmentUuid, String status, Runnable triggerRequest) {
		var id = new Random().nextInt();
		if (EnvVar.DEBUG_LOGGING.isTrue()) {
			System.out.printf("WAITING id=%d thread=%s%n", id, Thread.currentThread().threadId());
		}
		waitForResponse("**/cardata/service-access-permission/%s/status?statusUpdate=%s".formatted(assignmentUuid, status), triggerRequest);
		if (EnvVar.DEBUG_LOGGING.isTrue()) {
			System.out.printf("WAITING id=%d thread=%s done%n", id, Thread.currentThread().threadId());
		}
		postResponseHook();
	}

	default File downloadTac() {
		logMethodCall();
		return download(() -> {
			clickCheckError(getByText(getTacButtonText()).and(getRoleLink()), KeyboardModifier.ALT);
		});
	}

	default File downloadDpp() {
		logMethodCall();
		return download(() -> {
			clickCheckError(getByText(getPrivacyButtonText()), KeyboardModifier.ALT);
		});
	}

	default void clickCheckError(LocatorHandle loc, KeyboardModifier modifier) {
		loc.click(modifier);
		postClickHook();
	}

	default void postResponseHook() {
		postClickHook();
	}

	default LocatorHandle locateFirstClearanceTile(String testingContainerTitle) {
		return locateClearanceTile(testingContainerTitle).first();
	}

	default void checkContainerKeyElements(String cardataElement, String description) {
		var row = getByTestId("table")
			.locateRow(cardataElement);
		row.select("td").nth(1).getByText(cardataElement).assertVisible();
		row.select("td").nth(2).getByText(description).assertVisible();
	}

	default String getTextShowMoreButton() { return "Mehr anzeigen";}

	default void verifyClearanceDetails(String identifier, String testingContainerTitle, String status) {
		logMethodCall(testingContainerTitle, status);
		var clearanceTile = locateFirstClearanceTile(testingContainerTitle);

		assertClearanceTileDetailsAreCorrect(clearanceTile, status);

		clearanceTile.getByTestId("dataPackageLink").getByText(testingContainerTitle).click();

		assertClearanceDetailsTextIsCorrect();
		getByTestId("shortenContentToggleContent").getByText(getTextShowMoreButton()).click();

		assertClearanceHeadingIsCorrect(identifier);
		assertContainerKeyElements();

		clickDetailsCancel(getByTestId("backLink"));
	}

	default void assertClearanceHeadingIsCorrect(String identifier){
		locateClassWithText("chakra-heading",
			identifier + " – Details zum Antrag auf Datenfreigabe von BMW AG CA-534 CarData ProconDEV.").assertVisible();
	}

	default void assertContainerKeyElements() {
		checkContainerKeyElements("Zustand des Motors (an/aus)", "Der Wert gibt an, ob der Motor zum Zeitpunkt der Datenerfassung aus oder an war oder ob der Status unbekannt ist.");
		checkContainerKeyElements("Fahrzeugbasisdaten", "Dieser Wert zeigt eine Liste der grundlegenden Fahrzeugdaten an, z.B. Fahrzeugmarke und vollständige Modellbezeichnung.");
		checkContainerKeyElements("Gemessener Reifendruck hinten links", "Der Wert gibt den gemessenen Reifendruck hinten links in kPa an");

	}

	default void assertClearanceTileDetailsAreCorrect(LocatorHandle tile, String status){
		logMethodCall();
		tile.getByText("BMW AG CA-534 CarData ProconDEV").assertVisible();
		tile.getByTestId("requestStatusKey").getByText("Status").assertVisible();
		tile.getByTestId("requestStatusValue").getByText(status).assertVisible();
		locateAssignmentModifiedDate(tile).assertVisible();
		tile.getByTestId("undefinedKey").getByText(getDataPacketText()).assertVisible();
	}

	default void assertClearanceDetailsTextIsCorrect(){
		logMethodCall();
		locateAssignmentPersonalMessage().assertVisible();

		locateClearanceRequestDetails().assertVisible();
		//TODO: assert the clearance table and contents are there

	}

}
