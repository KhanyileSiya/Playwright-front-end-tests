package de.bmw.otp.tests.api;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Base64;

public class TokenClient {

	private final String baseUrl;
	private final String clientId;
	private final String clientSecret;

	public TokenClient(String baseUrl, String clientId, String clientSecret) {
		this.baseUrl = baseUrl;
		this.clientId = clientId;
		this.clientSecret = clientSecret;
	}

	public String getAccessToken() {
		String encodedCredentials = Base64.getEncoder().encodeToString((clientId + ":" + clientSecret).getBytes());

		try (HttpClient client = HttpClient.newHttpClient()) {
			HttpRequest request = HttpRequest.newBuilder()
				.uri(new URI(baseUrl + "/oauth2/token"))
				.header("Authorization", "Basic " + encodedCredentials)
				.header("Content-Type", "application/json")
				.POST(HttpRequest.BodyPublishers.ofString("{}"))
				.build();

			var response = client.send(request, HttpResponse.BodyHandlers.ofString());
			if (response.statusCode() >= 300) {
				throw new RuntimeException("Cannot acquire access token. Status " + response.statusCode() + " body: " + response.body());
			}
			var body = emptyToJsonObject(response.body());
			var responseObject = new ObjectMapper()
				.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
				.readValue(body, AccessTokenResponse.class);
			return responseObject.access_token();
		} catch (InterruptedException | URISyntaxException | IOException e) {
			throw new RuntimeException(e);
		}
	}

	private String emptyToJsonObject(String s) {
		if (s == null || s.isEmpty()) {
			return "{}";
		}
		return s;
	}

	private record AccessTokenResponse(String access_token) {

	}
}
