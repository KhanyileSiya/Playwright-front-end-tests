package de.bmw.otp.playwright;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Playwright;
import de.bmw.otp.tests.CardataStage;
import de.bmw.otp.tests.EnvVar;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;

public class PlaywrightContext implements AutoCloseable {
	private Playwright playwright;
	private Browser browser;

	public PlaywrightContext() {
		this.playwright = Playwright.create();
		this.browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(EnvVar.HEADLESS.isTrue()));
	}

//	public BrowserContext browserContext(CardataStage stage, double navigationTimeout, double locatorTimeout) {
//		return new BrowserContext(Objects.requireNonNull(this.browser), stage, navigationTimeout, locatorTimeout);
//	}

	// replaced above with ==

	public BrowserContext browserContext(CardataStage stage, double navigationTimeout, double locatorTimeout) {
		System.out.println("======Launching Playwright with session reuse support ======");

		try {
			Path sessionPath = Paths.get("src/main/resources/seeds/session-state.json");
			com.microsoft.playwright.Browser.NewContextOptions options = new com.microsoft.playwright.Browser.NewContextOptions();

			if (Files.exists(sessionPath)) {
				System.out.println("Found existing session file → " + sessionPath.toAbsolutePath());
				options.setStorageStatePath(sessionPath);
			} else {
				System.out.println("No session file found — login will be required.");
			}

			com.microsoft.playwright.BrowserContext pwContext = browser.newContext(options);

			// Create your custom wrapper as before
			return new BrowserContext(browser, stage, navigationTimeout, locatorTimeout);

		} catch (Exception e) {
			System.out.println("Failed to create Playwright context: " + e.getMessage());
			e.printStackTrace();
			// fallback — open a clean context
			com.microsoft.playwright.BrowserContext pwContext = browser.newContext();
			return new BrowserContext(browser, stage, navigationTimeout, locatorTimeout);
		}
	}
	// end

	@Override
	public void close() {
		browser.close();
		browser = null;
		playwright.close();
		playwright = null;
	}

}
