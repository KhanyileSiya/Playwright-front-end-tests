package de.bmw.otp.tests;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.http.HttpResponse;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.GeneralSecurityException;
import java.util.*;
import java.util.function.Supplier;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import java.io.FileNotFoundException;
import java.io.*;

import com.fasterxml.jackson.databind.JsonNode;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.Cookie;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.nio.file.Paths;
import java.io.File;
import java.util.List;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.options.LoadState;
import de.bmw.otp.playwright.PageHandle;


import java.lang.reflect.Method;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.File;
import java.nio.file.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import  com.microsoft.playwright.*;
import com.microsoft.playwright.options.*;



import com.microsoft.playwright.options.Cookie;
import jdk.swing.interop.SwingInterOpUtils;

/**
 * Utility class providing HOTP generation, file utilities, and helper methods.
 * Includes secure YubiKey seed counter management for synchronization with backend.
 */
public class Utils {

	// ------------------------------------------------------------------------
	// GENERAL UTILITIES
	// ------------------------------------------------------------------------

	public static String withIdTrimmed(String s, int length) {
		var idStr = "" + System.nanoTime();
		StringBuilder sBuilder = new StringBuilder(s);
		for (int i = idStr.length() - 1; i > 0; i--) {
			sBuilder.append(idStr.charAt(i));
		}
		return truncate(sBuilder.toString(), length);
	}

	public static String truncate(String s, int length) {
		return s.length() <= length ? s : s.substring(0, length);
	}

	public static <T extends Comparable<T>> T min(T a, T b) {
		return a.compareTo(b) < 0 ? a : b;
	}

	public static <R, E extends Exception> R uncheck(ThrowingFunction<Void, R, E> func) {
		try {
			return func.call(null);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static <R, E extends Exception> R uncheck(ThrowingSupplier<R, E> func) {
		try {
			return func.get();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static <T> Supplier<T> memoize(Supplier<T> supplier) {
		Map<String, T> store = new HashMap<>();
		return () -> store.computeIfAbsent("key", ignore -> supplier.get());
	}

	public interface ThrowingRunnable<E extends Exception> {
		void run() throws E;
	}

	public interface ThrowingFunction<T, R, E extends Exception> {
		R call(T t) throws E;
	}

	public interface ThrowingSupplier<R, E extends Exception> {
		R get() throws E;
	}

	public static void deleteRecursive(Path path) throws IOException {
		if (!path.toFile().exists()) return;
		try (Stream<Path> files = Files.walk(path)) {
			files.sorted(Comparator.reverseOrder()).map(Path::toFile).forEach(File::delete);
		}
	}

	public static String emptyToJsonObject(String s) {
		return (s != null && !s.isBlank()) ? s : "{}";
	}

	public static boolean httpIsOkay(int statusCode) {
		return 200 <= statusCode && statusCode <= 299;
	}

	public static <T> void assertHttpIsOkay(HttpResponse<T> response, String errorMsg) {
		if (!httpIsOkay(response.statusCode())) {
			throw new RuntimeException("HTTP error: %s status=%d body=%s"
				.formatted(errorMsg, response.statusCode(), response.body()));
		}
	}


	// Local seed
	private static final String LOCAL_SEED_PATH =
		"src/main/resources/seeds/qdbbba2_prod_seed.json";


	// Prevent concurrent updates (parallel tests)
	private static final Object LOCK = new Object();

	public static void main(String[] args) throws Exception {
		System.out.println("==========================================");
		System.out.println("BMW HOTP Generator");
		System.out.println("==========================================");

		// Detect mode: enrollment (3 HOTP) or session (1 HOTP)
		if (args.length > 0 && args[0].equalsIgnoreCase("enroll")) {
			generateEnrollmentHotps();
		} else {
			String hotp = getOrCreateSessionHotp();
			System.out.println("------------------------------------------");
			System.out.println("Generated HOTP for current session: " + hotp);
			System.out.println("==========================================");
		}
	}

	/**
	 * Generates first 3 HOTPs for enrollment and increments counter accordingly.
	 */
	public static void generateEnrollmentHotps() {
		synchronized (LOCK) {
			try {
				ObjectMapper mapper = new ObjectMapper();
				File seedFile = resolveSeedFile();

				if (!seedFile.exists()) {
					throw new FileNotFoundException("Seed file not found: " + seedFile.getAbsolutePath());
				}

				// Load JSON seed data
				Map<String, Object> seedData = mapper.readValue(seedFile, HashMap.class);
				String seedHex = (String) seedData.get("seed");
				String serial = (String) seedData.get("serial");
				long counter = Long.parseLong((String) seedData.get("counter"));

				System.out.printf("Loaded YubiKey seed (serial %s)%n", serial);
				System.out.printf("Seed: ****%s | Counter: %d%n",
					seedHex.substring(seedHex.length() - 4), counter);

				byte[] secretBytes = hexStringToBytes(seedHex);

				// Generate 3 HOTPs for enrollment
				List<String> hotps = new ArrayList<>();
				for (int i = 0; i < 3; i++) {
					String hotp = generateHotp(secretBytes, "HmacSHA1", 6, counter);
					hotps.add(hotp);
					System.out.printf("Counter %d → HOTP: %s%n", counter, hotp);
					counter++;
				}

				// Update counter in seed file
				seedData.put("counter", String.valueOf(counter));
				mapper.writerWithDefaultPrettyPrinter().writeValue(seedFile, seedData);
				System.out.println("Updated counter to " + counter + " and saved to file.");
				System.out.println("==========================================");
				System.out.println("First 3 HOTPs for enrollment:");
				for (int i = 0; i < hotps.size(); i++) {
					System.out.printf("HOTP %d: %s%n", i + 1, hotps.get(i));
				}
				System.out.println("==========================================");

			} catch (Exception e) {
				e.printStackTrace();
				throw new RuntimeException("Error generating enrollment HOTPs", e);
			}
		}
	}

	/**
	 * Returns the HOTP for the current test session.
	 * If none exists yet, generates one and locks it for all tests.
	 */
	public static String getOrCreateSessionHotp() {
		synchronized (LOCK) {
			try {
				ObjectMapper mapper = new ObjectMapper();
				File seedFile = resolveSeedFile();

				if (!seedFile.exists()) {
					throw new FileNotFoundException("Seed file not found: " + seedFile.getAbsolutePath());
				}

				// Load JSON seed data
				Map<String, Object> seedData = mapper.readValue(seedFile, HashMap.class);
				String seedHex = (String) seedData.get("seed");
				String serial = (String) seedData.get("serial");
				long counter = Long.parseLong((String) seedData.get("counter"));

				System.out.printf("Loaded YubiKey seed (serial %s)%n", serial);
				System.out.printf("Seed: ****%s | Counter: %d%n", seedHex.substring(seedHex.length() - 4), counter);

				byte[] secretBytes = hexStringToBytes(seedHex);

				// Always generate a *new* HOTP
				String hotp = generateHotp(secretBytes, "HmacSHA1", 6, counter);
				System.out.printf("Counter %d → HOTP: %s%n", counter, hotp);

				// Increment and persist counter immediately
				seedData.put("counter", String.valueOf(counter + 1));
				mapper.writerWithDefaultPrettyPrinter().writeValue(seedFile, seedData);
				System.out.println("Incremented YubiKey counter to " + (counter + 1));

				return hotp;
			} catch (Exception e) {
				e.printStackTrace();
				throw new RuntimeException("Error generating session HOTP", e);
			}
		}
	}

	/**
	 * Resolve which seed file to use:
	 * - Environment override (BMW_HOTP_SEED_PATH)
	 * - Local file fallback
	 */
	private static File resolveSeedFile() {
		String envSeedPath = System.getenv("BMW_HOTP_SEED_PATH");
		if (envSeedPath != null && !envSeedPath.isBlank()) {
			File envFile = new File(envSeedPath);
			if (envFile.exists()) {
				System.out.println("Using seed file from environment: " + envFile.getAbsolutePath());
				return envFile;
			} else {
				System.err.println("Environment seed file not found: " + envFile.getAbsolutePath());
			}
		}

		File localFile = new File(LOCAL_SEED_PATH);
		if (localFile.exists()) {
			System.out.println("Using local seed file: " + localFile.getAbsolutePath());
			return localFile;
		}

		throw new RuntimeException("No valid seed file found (expected local JSON seed).");
	}

	/**
	 * RFC 4226 HOTP generator (HMAC-SHA1 / 6 digits).
	 */
	public static String generateHotp(byte[] secretKey, String algorithm, int digits, long counter)
		throws GeneralSecurityException {

		ByteBuffer buffer = ByteBuffer.allocate(8);
		buffer.putLong(counter);

		Mac mac = Mac.getInstance(algorithm);
		SecretKeySpec keySpec = new SecretKeySpec(secretKey, "RAW");
		mac.init(keySpec);
		byte[] hash = mac.doFinal(buffer.array());

		int offset = hash[hash.length - 1] & 0x0F;
		int binary = ((hash[offset] & 0x7F) << 24)
			| ((hash[offset + 1] & 0xFF) << 16)
			| ((hash[offset + 2] & 0xFF) << 8)
			| (hash[offset + 3] & 0xFF);

		int otp = binary % (int) Math.pow(10, digits);
		return String.format("%0" + digits + "d", otp);
	}

	/**
	 * Converts hex string to byte array.
	 */
	private static byte[] hexStringToBytes(String hex) {
		int len = hex.length();
		byte[] data = new byte[len / 2];
		for (int i = 0; i < len; i += 2) {
			data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
				+ Character.digit(hex.charAt(i + 1), 16));
		}
		return data;
	}
	//==========================================================================================


	/**
	 * Safely checks if visible text or page content contains a given pattern.
	 * Fully111 compatible with PageHandle wrappers (no direct Playwright calls).
	 */
	public static boolean elementExists(PageHandle page, String textPattern) {
		try {
			// Normalize the search text
			String normalizedPattern = textPattern
				.replace("text=", "")
				.replace("input[placeholder=", "")
				.replace("]", "")
				.replaceAll("[^a-zA-Z0-9\\s+]", "")
				.trim()
				.toLowerCase();

			// Attempt to get visible text or description of page
			String pageText = page.toString().toLowerCase();

			// Basic contains match
			if (pageText.contains(normalizedPattern)) {
				return true;
			}

			// Try reading raw page URL if available
			try {
				Object rawPage = page.getClass().getMethod("rawPage").invoke(page);
				if (rawPage != null) {
					String url = (String) rawPage.getClass().getMethod("url").invoke(rawPage);
					if (url != null && url.toLowerCase().contains("auth.bmwgroup.net")) {
						return true;
					}
				}
			} catch (Exception ignored) {
			}

		} catch (Exception e) {
			// fallback - assume not found
		}

		return false;
	}

	/**
	 * Polls up to timeoutMillis for any of the pre-auth patterns to be detected.
	 */
	public static boolean isPreAuthVisible(PageHandle page, int timeoutMillis, String... patterns) {
		long end = System.currentTimeMillis() + timeoutMillis;

		while (System.currentTimeMillis() < end) {
			for (String pattern : patterns) {
				try {
					if (elementExists(page, pattern)) {
						System.out.println("[PreAuth detection] Found pattern: " + pattern);
						return true;
					}
				} catch (Exception ignored) {
				}
			}

			try {
				Thread.sleep(500);
			} catch (InterruptedException ignored) {
			}
		}

		return false;
	}

	//end here =========================================================================================

	public static void waitForPageStable(PageHandle page, int timeoutMs) {
		try {
			long end = System.currentTimeMillis() + timeoutMs;
			String lastHtml = "";
			int stableCount = 0;

			while (System.currentTimeMillis() < end) {
				String currentHtml = tryGetPageHtml(page);
				if (currentHtml != null && currentHtml.equals(lastHtml)) {
					stableCount++;
					if (stableCount >= 2) {
						System.out.println("====== Page is stable.");
						return;
					}
				} else {
					stableCount = 0;
				}
				lastHtml = currentHtml;
				Thread.sleep(1000);
			}
			System.out.println("⚠️ Page stability wait timeout reached (" + timeoutMs + "ms)");
		} catch (Exception e) {
			System.out.println("⚠️ waitForPageStable failed: " + e.getMessage());
		}
	}

	// -----------------------------------------------------------
	// Get page URL (works for any PageHandle)
	// -----------------------------------------------------------
	public static String getPageUrl(Object page) {
		if (page == null) return "";

		String[] candidateNames = {
			"getUrl", "getCurrentUrl", "url", "currentUrl",
			"getLocation", "getPageUrl", "getBrowserUrl"
		};

		// Try direct getters
		for (String name : candidateNames) {
			try {
				Method m = page.getClass().getMethod(name);
				Object result = m.invoke(page);
				if (result != null && !result.toString().isBlank()) {
					return result.toString();
				}
			} catch (Exception ignored) {
			}
		}

		// Try evaluating JS for URL
		String[] jsNames = {"evaluate", "executeScript", "runScript"};
		String script = "return window.location.href;";
		for (String js : jsNames) {
			try {
				Method m = page.getClass().getMethod(js, String.class);
				Object result = m.invoke(page, script);
				if (result != null && !result.toString().isBlank()) {
					return result.toString();
				}
			} catch (Exception ignored) {
			}
		}

		// Fallback: extract from HTML
		try {
			String html = tryGetPageHtml(page);
			if (html != null && !html.isEmpty()) {
				String fromHtml = extractUrlFromHtml(html);
				if (!fromHtml.isEmpty()) return fromHtml;
			}
		} catch (Exception ignored) {
		}

		return "";
	}

	// -----------------------------------------------------------
	// Check if text exists on the page (within timeout)
	// -----------------------------------------------------------
	public static boolean textExists(PageHandle page, String text, int timeoutMs) {
		long end = System.currentTimeMillis() + timeoutMs;
		while (System.currentTimeMillis() < end) {
			try {
				String html = tryGetPageHtml(page);
				if (html != null && html.toLowerCase().contains(text.toLowerCase())) {
					return true;
				}
				Thread.sleep(500);
			} catch (Exception ignored) {
			}
		}
		return false;
	}

	// -----------------------------------------------------------
	// Check if element selector exists on the page
	// -----------------------------------------------------------
	public static boolean elementExists(PageHandle page, String selector, int timeoutMs) {
		long end = System.currentTimeMillis() + timeoutMs;
		while (System.currentTimeMillis() < end) {
			try {
				Method find = page.getClass().getMethod("find", String.class);
				Object element = find.invoke(page, selector);
				if (element != null) {
					try {
						Method isVisible = page.getClass().getMethod("isVisible", String.class);
						Object vis = isVisible.invoke(page, selector);
						if (vis instanceof Boolean && (Boolean) vis) {
							return true;
						}
					} catch (NoSuchMethodException e) {
						return true; // no isVisible method — assume exists
					}
				}
				Thread.sleep(500);
			} catch (NoSuchMethodException e) {
				System.out.println("⚠️ PageHandle has no find(String) method.");
				break;
			} catch (Exception ignored) {
			}
		}
		return false;
	}

	// -----------------------------------------------------------
	// Detect iframes containing a keyword (e.g. BMW auth)
	// -----------------------------------------------------------
	public static boolean pageContainsIframe(PageHandle page, String keyword) {
		try {
			Method m = page.getClass().getMethod("getFrameUrls");
			Object result = m.invoke(page);
			if (result instanceof List) {
				for (Object urlObj : (List<?>) result) {
					if (urlObj != null && urlObj.toString().toLowerCase().contains(keyword.toLowerCase())) {
						return true;
					}
				}
			}
		} catch (Exception e) {
			System.out.println("⚠️ Could not inspect iframes: " + e.getMessage());
		}
		return false;
	}

	// -----------------------------------------------------------
	// 🔧 Helper methods used internally
	// -----------------------------------------------------------
	private static String tryGetPageHtml(Object page) {
		String[] htmlMethods = {
			"getPageSource", "getHtml", "getContent", "html", "getDOM", "getDocument"
		};

		for (String name : htmlMethods) {
			try {
				Method m = page.getClass().getMethod(name);
				Object result = m.invoke(page);
				if (result != null) return result.toString();
			} catch (Exception ignored) {
			}
		}

		// Try JS fallback
		String[] jsNames = {"evaluate", "executeScript", "runScript"};
		String script = "return document.documentElement.outerHTML;";
		for (String js : jsNames) {
			try {
				Method m = page.getClass().getMethod(js, String.class);
				Object result = m.invoke(page, script);
				if (result != null) return result.toString();
			} catch (Exception ignored) {
			}
		}

		return "";
	}

	private static String extractUrlFromHtml(String html) {
		Pattern canonical = Pattern.compile(
			"<link[^>]*rel=[\"']canonical[\"'][^>]*href=[\"']([^\"']+)[\"'][^>]*>",
			Pattern.CASE_INSENSITIVE);
		Matcher m = canonical.matcher(html);
		if (m.find()) return m.group(1);

		Pattern base = Pattern.compile(
			"<base[^>]*href=[\"']([^\"']+)[\"'][^>]*>",
			Pattern.CASE_INSENSITIVE);
		m = base.matcher(html);
		if (m.find()) return m.group(1);

		Pattern og = Pattern.compile(
			"<meta[^>]*property=[\"']og:url[\"'][^>]*content=[\"']([^\"']+)[\"'][^>]*>",
			Pattern.CASE_INSENSITIVE);
		m = og.matcher(html);
		if (m.find()) return m.group(1);

		return "";
	}

	public static String getPageHtmlDebug(Object page) {
		try {
			String html = tryGetPageHtml(page); // <-- this already exists in your Utils
			if (html == null) {
				return "No HTML returned (null)";
			}
			// Limit output to avoid console spam
			int len = Math.min(1000, html.length());
			return html.substring(0, len);
		} catch (Exception e) {
			return "Failed to fetch page HTML: " + e.getMessage();
		}
	}
	//====session script=======================================
	/// saving a session for pre-auth to happen once
	///
	private static final String SESSION_FILE = "src/main/resources/seeds/session-state.json";
	private static final ObjectMapper MAPPER = new ObjectMapper();

	/**
	 * Entry point that ensures:
	 * - Old session file is deleted before test starts
	 * - Pre-auth is performed when no valid session exists
	 * - Session is saved cleanly after login
	 * - Reused session is validated and cleaned up if invalid
	 */

	public static PageHandle initSession(
		LoggingHelper log,
		de.bmw.otp.playwright.BrowserContext customContext,
		String url,
		Runnable preAuthAction) {

		Path sessionPath = Paths.get(SESSION_FILE);

		// Always delete any old session before starting
		try {
			if (Files.exists(sessionPath)) {
				Files.delete(sessionPath);
				System.out.println("====== Deleted old session before starting new context: " + sessionPath);
			}
		} catch (IOException e) {
			System.out.println("Could not delete old session: " + e.getMessage());
		}

		// Open a new page
		PageHandle pageHandle = customContext.getPage(log);
		pageHandle.navigate(url);

		// Detect pre-authentication screen
		boolean preAuthDetected = isPreAuthVisible(pageHandle, 20000,
			"auth.bmwgroup.net", "BMW Login", "My BMW ID", "Sign In", "Anmelden");

		if (!preAuthDetected) {
			System.out.println("====== No pre-authentication detected — assuming existing session is valid.");
			return pageHandle;
		}

		System.out.println("====== Pre-authentication detected — starting login flow...");

		// Execute login (HOTP / BMW credentials)
		if (preAuthAction != null) {
			preAuthAction.run();
		}

		// Wait for authenticated page
		System.out.println("Waiting for BMW authenticated page...");
		boolean success = waitForBMWAuthenticatedPage(pageHandle, 90000);
		if (!success) {
			System.out.println("Authentication may not have completed fully.");
		}

		// Save authenticated session
		try {
			System.out.println("About to save session — Current URL: " + pageHandle.getPage().url());
			saveCleanSession(pageHandle.getPage());
			if (Files.exists(sessionPath)) {
				System.out.println("Session file successfully created at: " + sessionPath.toAbsolutePath());
			} else {
				System.out.println("Session file not found after save attempt!");
			}
		} catch (Exception e) {
			System.out.println("Failed to capture BMW session: " + e.getMessage());
			e.printStackTrace();
		}

		return pageHandle;
	}

	public static boolean waitForBMWAuthenticatedPage(Page page, long timeoutMs) {
		long start = System.currentTimeMillis();

		while (System.currentTimeMillis() - start < timeoutMs) {
			try {
				String url = page.url().toLowerCase();

				if (url.contains("vehicle-overview") ||
					url.contains("my-bmw") ||
					url.contains("dashboard") ||
					url.contains("vehicles")) {

					page.waitForLoadState(LoadState.NETWORKIDLE);
					System.out.println("Authenticated URL reached: " + url);
					return true;
				}

				// Fallback: detect UI elements that only appear post-login
				if (page.locator("text=My BMW").first().isVisible() ||
					page.locator("text=Vehicle Overview").first().isVisible() ||
					page.locator("text=Welcome").first().isVisible() ||
					page.locator("text=Fahrzeugübersicht").first().isVisible()) {
					System.out.println("Authenticated BMW UI detected — session ready.");
					return true;
				}

			} catch (Exception ignored) { }

			try {
				Thread.sleep(1000);
			} catch (InterruptedException ignored) { }
		}

		System.out.println("Timed out waiting for authenticated BMW page.");
		return false;
	}

	// Accepts PageHandle (your wrapper) and unwraps the real Playwright Page
	public static boolean waitForBMWAuthenticatedPage(PageHandle pageHandle, long timeoutMs) {
		if (pageHandle == null) {
			System.out.println("PageHandle is null — cannot wait for authenticated page.");
			return false;
		}

		try {
			Page page = pageHandle.getPage(); //unwrap your Playwright Page
			return waitForBMWAuthenticatedPage(page, timeoutMs); // delegate to main method
		} catch (Exception e) {
			System.out.println("Failed to unwrap PageHandle: " + e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * Deletes any existing session file before starting new test.
	 */
	private static void deleteSessionFile() {
		try {
			Path path = Paths.get(SESSION_FILE);
			if (Files.exists(path)) {
				Files.delete(path);
				System.out.println("Deleted old session: " + path.toAbsolutePath());
			}
		} catch (IOException e) {
			System.out.println("Failed to delete old session: " + e.getMessage());
		}
	}

	/**
	 * Saves a clean session with corrected cookies to prevent Playwright validation errors.
	 */

	public static void saveCleanSession(Page page) {
		Path sessionPath = Paths.get("src/main/resources/seeds/session-state.json");
		System.out.println("Attempting to save authenticated session to: " + sessionPath);

		try {
			// Always delete old file before saving a new one
			if (Files.exists(sessionPath)) {
				Files.delete(sessionPath);
				System.out.println("Deleted previous session before saving a new one.");
			}
			Files.createDirectories(sessionPath.getParent());

			// Ensure we have cookies
			List<Cookie> cookies = null;
			for (int i = 0; i < 10; i++) {
				cookies = page.context().cookies();
				if (cookies != null && !cookies.isEmpty()) break;
				System.out.println("Waiting for cookies to appear (" + (i + 1) + "/10)...");
				Thread.sleep(1000);
			}

			if (cookies == null || cookies.isEmpty()) {
				System.out.println("No cookies found — cannot save valid session.");
				return;
			}

			ObjectMapper mapper = new ObjectMapper();
			ObjectNode sessionData = mapper.createObjectNode();

			ArrayNode cookiesArray = mapper.createArrayNode();
			for (Cookie c : cookies) {
				ObjectNode cookieNode = mapper.createObjectNode();
				cookieNode.put("name", c.name);
				cookieNode.put("value", c.value);
				cookieNode.put("domain", c.domain);
				cookieNode.put("path", c.path);
				cookieNode.put("secure", c.secure);
				cookieNode.put("httpOnly", c.httpOnly);
				cookieNode.put("expires", c.expires);

				// Normalize sameSite
				String sameSite = "Lax";
				if (c.sameSite != null) {
					String raw = c.sameSite.name().trim().toLowerCase();
					switch (raw) {
						case "strict" -> sameSite = "Strict";
						case "none" -> sameSite = "None";
						case "lax" -> sameSite = "Lax";
						default -> sameSite = "Lax";
					}
				}
				cookieNode.put("sameSite", sameSite);
				cookiesArray.add(cookieNode);
			}
			sessionData.set("cookies", cookiesArray);

			// Capture localStorage
			ArrayNode originsArray = mapper.createArrayNode();
			try {
				String origin = page.url().split("/")[0] + "//" + page.url().split("/")[2];
				ArrayNode localStorageArray = mapper.createArrayNode();

				@SuppressWarnings("unchecked")
				List<String> keys = (List<String>) page.evaluate("Object.keys(window.localStorage)");
				for (String key : keys) {
					Object value = page.evaluate("window.localStorage.getItem('" + key + "')");
					ObjectNode kv = mapper.createObjectNode();
					kv.put("name", key);
					kv.put("value", value == null ? "" : value.toString());
					localStorageArray.add(kv);
				}

				if (localStorageArray.size() > 0) {
					ObjectNode originNode = mapper.createObjectNode();
					originNode.put("origin", origin);
					originNode.set("localStorage", localStorageArray);
					originsArray.add(originNode);
				}
			} catch (Exception ignored) {}

			sessionData.set("origins", originsArray);

			mapper.writerWithDefaultPrettyPrinter().writeValue(sessionPath.toFile(), sessionData);

			System.out.println("BMW session successfully saved → " + sessionPath.toAbsolutePath());
			System.out.println("Cookies saved: " + cookies.size());

		} catch (Exception e) {
			System.out.println("Failed to save authenticated session: " + e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Attempts to reuse a previously saved Playwright session.
	 * If invalid, deletes it and forces re-login next time.
	 */
	private static void reuseCleanSession(
		LoggingHelper log,
		de.bmw.otp.playwright.BrowserContext customContext,
		String url) {

		File sessionFile = new File(SESSION_FILE);
		if (!sessionFile.exists()) {
			System.out.println("No saved session found for reuse.");
			return;
		}

		try {
			Browser browser = extractPWBrowser(customContext);
			com.microsoft.playwright.BrowserContext reuseContext = browser.newContext(
				new Browser.NewContextOptions().setStorageStatePath(Paths.get(SESSION_FILE)));

			Page page = reuseContext.newPage();
			page.navigate(url);
			page.waitForLoadState(LoadState.NETWORKIDLE);

			if (isSessionValid(page)) {
				System.out.println("Session reuse successful — authenticated BMW session active.");
			} else {
				System.out.println("Session expired or invalid. Deleting session file and forcing re-login.");
				deleteSessionFile();
			}

			reuseContext.close();
		} catch (PlaywrightException ex) {
			System.out.println("Playwright rejected storageState (invalid cookie format). Deleting and regenerating...");
			deleteSessionFile();
		} catch (Exception e) {
			System.out.println("Failed to reuse session: " + e.getMessage());
			deleteSessionFile();
		}
	}

	/**
	 * Checks if user is currently logged in or if BMW app main page is loaded.
	 */
	private static boolean isSessionValid(Page page) {
		try {
			String url = page.url();
			if (url.contains("vehicle-overview") || url.contains("dashboard") || url.contains("my-bmw"))
				return true;
			return page.locator("text=My BMW").first().isVisible()
				|| page.locator("text=Vehicle Overview").first().isVisible();
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Normalizes cookie sameSite attribute to Playwright-accepted values.
	 */
	private static String normalizeSameSite(String value) {
		if (value == null || value.isBlank()) return "Lax";
		switch (value.trim().toLowerCase()) {
			case "strict":
				return "Strict";
			case "none":
				return "None";
			case "lax":
			default:
				return "Lax";
		}
	}

	/**
	 * Extracts Playwright's internal BrowserContext from BMW custom wrapper.
	 */
	private static com.microsoft.playwright.BrowserContext extractPWContext(
		de.bmw.otp.playwright.BrowserContext customContext) {
		try {
			Field f = de.bmw.otp.playwright.BrowserContext.class.getDeclaredField("context");
			f.setAccessible(true);
			return (com.microsoft.playwright.BrowserContext) f.get(customContext);
		} catch (Exception e) {
			throw new RuntimeException("Failed to extract Playwright context: " + e.getMessage(), e);
		}
	}

	/**
	 * Extracts Playwright Browser instance from BMW custom context.
	 */
	private static Browser extractPWBrowser(de.bmw.otp.playwright.BrowserContext customContext) {
		return extractPWContext(customContext).browser();
	}

	/**
	 * Unwrap Playwright internal context.
	 */
	private static com.microsoft.playwright.BrowserContext extractPlaywrightContext(
		de.bmw.otp.playwright.BrowserContext customContext) {
		try {
			Field field = de.bmw.otp.playwright.BrowserContext.class.getDeclaredField("context");
			field.setAccessible(true);
			return (com.microsoft.playwright.BrowserContext) field.get(customContext);
		} catch (Exception e) {
			throw new RuntimeException("Failed to extract BrowserContext: " + e.getMessage(), e);
		}
	}

	private static Browser extractPlaywrightBrowser(
		de.bmw.otp.playwright.BrowserContext customContext) {
		com.microsoft.playwright.BrowserContext pwContext = extractPlaywrightContext(customContext);
		return pwContext.browser();
	}

	/**
	 * Extracts the underlying Playwright Browser instance.
	 */
	public static Browser getBrowserFromCustomContext(BrowserContext customContext) {
		try {
			java.lang.reflect.Field contextField = BrowserContext.class.getDeclaredField("context");
			contextField.setAccessible(true);
			com.microsoft.playwright.BrowserContext pwContext =
				(com.microsoft.playwright.BrowserContext) contextField.get(customContext);
			return pwContext.browser();
		} catch (Exception e) {
			throw new RuntimeException("Failed to extract Browser from custom BrowserContext: " + e.getMessage(), e);
		}
	}

	/**
	 * Extracts Playwright’s internal BrowserContext (for cookies & storage).
	 */
	private static com.microsoft.playwright.BrowserContext getPlaywrightContext(
		de.bmw.otp.playwright.BrowserContext customContext) {
		try {
			java.lang.reflect.Field field =
				de.bmw.otp.playwright.BrowserContext.class.getDeclaredField("context");
			field.setAccessible(true);
			return (com.microsoft.playwright.BrowserContext) field.get(customContext);
		} catch (Exception e) {
			throw new RuntimeException("Failed to extract Playwright context: " + e.getMessage(), e);
		}
	}
}
