package de.bmw.otp.MyToyota;

import de.bmw.otp.business.AbstractResetAccountTests;
import de.bmw.otp.business.MyToyotaHelper;

public class ResetMyToyotaAccountTest extends AbstractResetAccountTests implements MyToyotaHelper {
}
