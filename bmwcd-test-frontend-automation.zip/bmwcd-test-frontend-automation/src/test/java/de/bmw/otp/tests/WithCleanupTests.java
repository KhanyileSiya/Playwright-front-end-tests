package de.bmw.otp.tests;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class WithCleanupTests {

	private <T> WithCleanup<T> withCleanup(T val, AtomicInteger destructorCount) {
		return new WithCleanup<>(val, v -> destructorCount.incrementAndGet());
	}

	@Test
	public void testWithCleanupDestruction() {
		var counter = new AtomicInteger(0);
		try (var sut = withCleanup("", counter)) {
			assertEquals("", sut.val());
			assertEquals(0, counter.get());
		}
		assertEquals(1, counter.get());
	}

	@Test
	public void testWithCleanupDestructionThrows() {
		var counter = new AtomicInteger(0);
		Assertions.assertThrows(RuntimeException.class, () -> {
			try (var sut = withCleanup("", counter)) {
				assertEquals("", sut.val());
				assertEquals(0, counter.get());
				throw new RuntimeException();
			}
		});
		assertEquals(1, counter.get());
	}

	@Test
	public void testWithCleanupThen() {
		var counter = new AtomicInteger(0);
		var counter2 = new AtomicInteger(0);
		try (var sut = WithCleanup.then(withCleanup("", counter), counter2::incrementAndGet)) {
			assertEquals(0, counter.get());
			assertEquals(1, counter2.get());
			assertEquals("", sut.val());
		}
		assertEquals(1, counter.get());
		assertEquals(1, counter2.get());
	}

	@Test
	public void testWithCleanupThenThrows() {
		var counter = new AtomicInteger(0);
		Assertions.assertThrows(RuntimeException.class, () -> {
			try (var sut = WithCleanup.then(
				withCleanup("", counter),
				() -> {
					assertEquals(0, counter.get());
					throw new RuntimeException();
				})) {
			}
		});
		assertEquals(1, counter.get());
	}

	@Test
	public void testWithCleanupThen2() {
		var counter = new AtomicInteger(0);
		var counter2 = new AtomicInteger(0);
		try (var sut = WithCleanup.then(withCleanup("", counter), val -> counter2.incrementAndGet())) {
			assertEquals(0, counter.get());
			assertEquals(1, counter2.get());
			assertEquals("", sut.val());
		}
		assertEquals(1, counter.get());
		assertEquals(1, counter2.get());
	}

	@Test
	public void testWithCleanupThen2Throws() {
		var counter = new AtomicInteger(0);
		Assertions.assertThrows(RuntimeException.class, () -> {
			try (var sut = WithCleanup.then(
				withCleanup("", counter),
				val -> {
					assertEquals(0, counter.get());
					throw new RuntimeException();
				})) {
			}
		});
		assertEquals(1, counter.get());
	}

	@Test
	public void testWithCleanupCombine() {
		var counter = new AtomicInteger(0);
		var counter2 = new AtomicInteger(0);
		try (var sut = WithCleanup.combine(
			withCleanup("", counter),
			s -> counter2.incrementAndGet(),
			Pair::new)) {
			assertEquals(0, counter.get());
			assertEquals(1, counter2.get());
			assertEquals("", sut.val().a());
			assertEquals(1, sut.val().b());
		}
		assertEquals(1, counter.get());
		assertEquals(1, counter2.get());
	}

	@Test
	public void testWithCleanupCombineThrows() {
		var counter = new AtomicInteger(0);
		Assertions.assertThrows(RuntimeException.class, () -> {
			try (var sut = WithCleanup.combine(
				withCleanup("", counter),
				s -> {
					assertEquals(0, counter.get());
					throw new RuntimeException();
				},
				Pair::new)) {
			}
		});
		assertEquals(1, counter.get());
	}

	private record Pair<A,B>(A a, B b) {}


}
