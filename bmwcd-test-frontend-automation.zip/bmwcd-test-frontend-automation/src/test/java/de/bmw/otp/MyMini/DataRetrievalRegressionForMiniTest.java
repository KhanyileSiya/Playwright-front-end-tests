package de.bmw.otp.MyMini;

import de.bmw.otp.business.AbstractDataRetrievalIndependentRegressionTests;
import de.bmw.otp.business.MyMiniHelper;

public class DataRetrievalRegressionForMiniTest extends AbstractDataRetrievalIndependentRegressionTests implements MyMiniHelper {
}
