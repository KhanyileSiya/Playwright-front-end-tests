package de.bmw.otp.MyRollsRoyce;

import de.bmw.otp.business.AbstractDocumentsTests;
import de.bmw.otp.business.MyRollsRoyceHelper;
import org.junit.jupiter.api.Test;

public class CustomerChecksMyRollsRoyceAndDocumentsTest extends AbstractDocumentsTests implements MyRollsRoyceHelper {

	@Test
	void testLinkFAQAndHelp() {
		openPageAndLoginAndSelectVin(getSutVin());

		try (var popup = waitForPopup(() -> {
			getByText("FAQ and Help").click();
		})) {
			try (var temp = withTemporaryPage(popup)) {
				getByText("What is telematics data?").assertVisible();
				getByText("What is Rolls-Royce CarData?").assertVisible();
				getByText("What are the costs of using Rolls-Royce CarData?").assertVisible();
				getByText("What value does Rolls-Royce CarData add?").assertVisible();
				getByText("What requirements must I meet as a client to be able to use Rolls-Royce CarData?").assertVisible();
			}
		}
	}

}
