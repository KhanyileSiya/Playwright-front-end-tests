package de.bmw.otp.architecture;

import com.tngtech.archunit.base.DescribedPredicate;
import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.domain.JavaFieldAccess;
import com.tngtech.archunit.core.domain.JavaMethod;
import com.tngtech.archunit.core.domain.JavaModifier;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchCondition;
import com.tngtech.archunit.lang.ConditionEvents;
import com.tngtech.archunit.lang.SimpleConditionEvent;

import java.util.Objects;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.methods;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses;

@AnalyzeClasses(packages = "de.bmw.otp")
public class PlaywrightArchitectureTest {

	@ArchTest
	public void neverUseJavaUtilDate(JavaClasses classes) {
		noClasses()
			.that()
			.resideOutsideOfPackages("de.bmw.otp.exve.*", "de.bmw.otp.architecture")
			.should()
			.dependOnClassesThat()
			.belongToAnyOf(java.util.Date.class)
			.because("it is considered deprecated and there are better alternatives like LocalDateTime/ZonedDateTime")
			.check(classes);
	}

	@ArchTest
	public void noDirectPlaywrightImportsAllowedExceptInPackagePlaywright(JavaClasses classes) {
		noClasses()
			.that()
			.resideOutsideOfPackage("de.bmw.otp.playwright")
			.should()
			.dependOnClassesThat()
			.resideInAPackage("com.microsoft.playwright")
			.because("that is against the rules!")
			.check(classes);

	}

	@ArchTest
	public void noClassInPackagePlaywrightShouldExposePlaywrightInternals(JavaClasses allClasses) {
		JavaClasses classes = new ClassFileImporter().importPackages("de.bmw.otp.playwright");

		methods()
			.should(notReturnPlaywrightTypes())
			.check(classes);

		noClasses()
			.should()
			.accessFieldWhere(fieldIsPublicPlaywrightInternal())
			.check(allClasses);
	}

	private DescribedPredicate<JavaFieldAccess> fieldIsPublicPlaywrightInternal() {
		return new DescribedPredicate<>("fieldIsPublicPlaywrightInternal") {
			@Override
			public boolean test(JavaFieldAccess access) {
				if (isPlaywrightType(access.getTarget().getType().getName())) {
					var isGet = access.getAccessType() == JavaFieldAccess.AccessType.GET;
					if (isGet) {
						var isExternalAccess = !Objects.equals(access.getOriginOwner().getFullName(), access.getTargetOwner().getFullName());
						if (isExternalAccess) {
							var accessingClassIsInMyPlaywrightPackage = access.getOriginOwner().getPackageName().startsWith("de.bmw.otp.playwright");
							if (!accessingClassIsInMyPlaywrightPackage) {
								return true;
							}
						}
					}
				}
				return false;
			}
		};
	}

	private ArchCondition<JavaMethod> notReturnPlaywrightTypes() {
		return new ArchCondition<>("notReturnPlaywrightTypes") {
			@Override
			public void check(JavaMethod method, ConditionEvents conditionEvents) {
				Class<?> returnType = method.getRawReturnType().reflect();
				if (isPublic(method) && isPlaywrightType(returnType)) {
					conditionEvents.add(SimpleConditionEvent.violated(method, String.format("Method %s returns Playwright type: %s", method.getFullName(), returnType.getName())));
				}
			}
		};
	}

	private boolean isPublic(JavaMethod m) {
		return m.getModifiers().contains(JavaModifier.PUBLIC);
	}

	private boolean isPlaywrightType(Class<?> type) {
		return isPlaywrightType(type.getPackageName());
	}

	private boolean isPlaywrightType(String name) {
		return name.startsWith("com.microsoft.playwright");
	}
}
