package de.bmw.otp.MyBmw;

import de.bmw.otp.business.AbstractCustomerJourneyClearanceTests;
import de.bmw.otp.business.MyBmwHelper;

public class CustomerJourneyClearanceForBmwTest extends AbstractCustomerJourneyClearanceTests implements MyBmwHelper {
}
