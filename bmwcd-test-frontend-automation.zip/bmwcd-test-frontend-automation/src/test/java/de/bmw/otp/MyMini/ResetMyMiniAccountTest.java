package de.bmw.otp.MyMini;

import de.bmw.otp.business.AbstractResetAccountTests;
import de.bmw.otp.business.MyMiniHelper;

public class ResetMyMiniAccountTest extends AbstractResetAccountTests implements MyMiniHelper {
}
