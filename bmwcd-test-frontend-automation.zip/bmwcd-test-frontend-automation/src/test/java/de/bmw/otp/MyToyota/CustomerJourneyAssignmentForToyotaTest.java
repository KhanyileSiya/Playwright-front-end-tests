package de.bmw.otp.MyToyota;

import de.bmw.otp.business.AbstractCustomerJourneyAssignmentTests;
import de.bmw.otp.business.MyToyotaHelper;

public class CustomerJourneyAssignmentForToyotaTest  extends AbstractCustomerJourneyAssignmentTests implements MyToyotaHelper {
}
