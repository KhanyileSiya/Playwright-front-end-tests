package de.bmw.otp.MyToyota;

import de.bmw.otp.business.AbstractCustomerJourneyClearanceTests;
import de.bmw.otp.business.MyToyotaHelper;

public class CustomerJourneyClearanceForToyotaTest extends AbstractCustomerJourneyClearanceTests implements MyToyotaHelper {
}
