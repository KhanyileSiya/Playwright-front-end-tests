package de.bmw.otp.MyBmw;

import de.bmw.otp.business.AbstractCustomerJourneyAssignmentTests;
import de.bmw.otp.business.MyBmwHelper;

public class CustomerJourneyAssignmentForBmwTest extends AbstractCustomerJourneyAssignmentTests implements MyBmwHelper {
}
