package de.bmw.otp.MyToyota;

import de.bmw.otp.business.AbstractDocumentsTests;
import de.bmw.otp.business.MyToyotaHelper;
import org.junit.jupiter.api.Test;

public class CustomerChecksMyToyotaAndDocumentsTest extends AbstractDocumentsTests implements MyToyotaHelper {

	@Test
	void testLinkFAQAndHelp() {
		openPageAndLoginAndSelectVin(getSutVin());

		try (var popup = waitForPopup(() -> {
			getByTestId("faqLink").getByText("FAQ und Hilfe").click();
		})) {
			try (var temp = withTemporaryPage(popup)) {
				checkForErrorMessage();
				getByText("Was sind Telematikdaten?").assertVisible();
				getByText("Was ist Toyota Supra CarData?").assertVisible();
				getByText("Was kostet die Nutzung von Toyota Supra CarData?").assertVisible();
				getByText("Welchen Mehrwert bietet Toyota Supra CarData?").assertVisible();
				getByText("Welche Voraussetzungen muss ich als Kunde erfüllen, um Toyota Supra CarData nutzen zu können?").assertVisible();
			}
		}
	}

}
