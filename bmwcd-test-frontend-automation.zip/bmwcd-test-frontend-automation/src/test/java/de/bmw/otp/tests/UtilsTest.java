package de.bmw.otp.tests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class UtilsTest {

	@Test
	public void testTruncateNone() {
		String s = "1234";
		String expect = "1234";
		assertEquals(expect, Utils.truncate(s, 5));
		assertEquals(expect, Utils.truncate(s, 6));
		assertEquals(expect, Utils.truncate(s, 7));
		assertEquals(expect, Utils.truncate(s, 8));
		assertEquals(expect, Utils.truncate(s, 9));
	}

	@Test
	public void testTruncateExact() {
		String s = "1234";
		String expect = "1234";
		assertEquals(expect, Utils.truncate(s, 4));
	}

	@Test
	public void testTruncateOne() {
		String s = "1234";
		String expect = "123";
		assertEquals(expect, Utils.truncate(s, 3));
	}

	@Test
	public void testTruncateTwo() {
		String s = "1234";
		String expect = "12";
		assertEquals(expect, Utils.truncate(s, 2));
	}

	@Test
	public void testTruncateAll() {
		String s = "1234";
		String expect = "";
		assertEquals(expect, Utils.truncate(s, 0));
	}
}
