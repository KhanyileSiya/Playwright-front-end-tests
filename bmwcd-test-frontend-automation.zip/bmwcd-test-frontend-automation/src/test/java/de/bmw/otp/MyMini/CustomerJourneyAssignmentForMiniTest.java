package de.bmw.otp.MyMini;

import de.bmw.otp.business.AbstractCustomerJourneyAssignmentTests;
import de.bmw.otp.business.MyMiniHelper;

public class CustomerJourneyAssignmentForMiniTest extends AbstractCustomerJourneyAssignmentTests implements MyMiniHelper {
}
