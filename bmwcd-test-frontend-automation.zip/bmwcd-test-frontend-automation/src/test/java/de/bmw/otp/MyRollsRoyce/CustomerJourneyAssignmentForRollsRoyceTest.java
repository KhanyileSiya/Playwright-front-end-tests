package de.bmw.otp.MyRollsRoyce;

import de.bmw.otp.business.AbstractCustomerJourneyAssignmentTests;
import de.bmw.otp.business.MyRollsRoyceHelper;

public class CustomerJourneyAssignmentForRollsRoyceTest extends AbstractCustomerJourneyAssignmentTests implements MyRollsRoyceHelper {
}
