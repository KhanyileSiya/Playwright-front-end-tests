package de.bmw.otp.MyMini;

import de.bmw.otp.business.AbstractCustomerJourneyClearanceTests;
import de.bmw.otp.business.MyMiniHelper;

public class CustomerJourneyClearanceForMiniTest extends AbstractCustomerJourneyClearanceTests implements MyMiniHelper {
}
