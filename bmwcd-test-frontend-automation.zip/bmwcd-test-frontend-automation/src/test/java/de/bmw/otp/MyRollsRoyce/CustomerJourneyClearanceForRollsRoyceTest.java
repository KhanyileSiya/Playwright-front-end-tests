package de.bmw.otp.MyRollsRoyce;

import de.bmw.otp.business.AbstractCustomerJourneyClearanceTests;
import de.bmw.otp.business.MyRollsRoyceHelper;

public class CustomerJourneyClearanceForRollsRoyceTest extends AbstractCustomerJourneyClearanceTests implements MyRollsRoyceHelper {
}
