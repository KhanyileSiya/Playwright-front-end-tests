package de.bmw.otp.MyBmw;

import de.bmw.otp.business.AbstractDocumentsTests;
import de.bmw.otp.business.MyBmwHelper;
import org.junit.jupiter.api.Test;

public class CustomerChecksMyBmwAndDocumentsTest extends AbstractDocumentsTests implements MyBmwHelper {

	@Test
	void testMyBMWLinkMoreAboutCarData() {
		openPageAndLoginAndSelectVin(getSutVin());

		try (var popup = waitForPopup(() -> {
			getByText("Mehr über BMW CarData erfahren").click();
		})) {
			try (var temp = withTemporaryPage(popup)) {
				getByText("WAS IST BMW CARDATA?").assertVisible();
				getByText("IHRE FAHRZEUGDATEN IM BLICK").assertVisible();
				getByText("DATENFREIGABE VERWALTEN").assertVisible();
				getByText("BMW CARDATA – SO GEHT'S:").assertVisible();
				getByText("IHRE VORTEILE").assertVisible();
				getByText("INNOVATIONEN FÜR EINE AUTOMOBILE ZUKUNFT").assertVisible();
				getByText("DATENFREIGABE VERWALTEN").assertVisible();
			}
		}
	}

	@Test
	void testMyBMWLinkFAQAndHelp() {
		openPageAndLoginAndSelectVin(getSutVin());

		try (var popup = waitForPopup(() -> {
			getByText("FAQ und Hilfe").click();
		})) {
			try (var temp = withTemporaryPage(popup)) {
				getByText("Was sind Telematikdaten?").assertVisible();
				getByText("Was ist BMW CarData?").assertVisible();
				getByText("Was kostet die Nutzung von BMW CarData?").assertVisible();
				getByText("Welchen Mehrwert bietet mir BMW CarData?").assertVisible();
				getByText("Welche Vorraussetzungen muss ich als Kunde erfüllen, um BMW CarData nutzen zu können?").assertVisible();
			}
		}
	}

}
