package de.bmw.otp.ThirdPartyPortal;

import de.bmw.otp.business.ThirdPartyBase;
import de.bmw.otp.business.ThirdPartyPortalTests;
import de.bmw.otp.exve.invoker.ApiException;
import de.bmw.otp.playwright.LocatorHandle;
import de.bmw.otp.tests.Utils;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.TestMethodOrder;

import static org.junit.jupiter.api.Assertions.assertEquals;

@TestMethodOrder(OrderAnnotation.class)
public class ThirdPartyRegressionTest extends ThirdPartyBase implements ThirdPartyPortalTests {

	// CARDATA-8608 [UAT] 3pp EMEA - regression

	private static final String TESTING_CONTAINER_TITLE = Utils.withIdTrimmed("Playwright Cont ", 30);

	private static String containerId;

	public String getTestingContainerTitle() {
		return TESTING_CONTAINER_TITLE;
	}

	@Override
	public String getSutVin() {
		return getStage().vins().myBmw().vin();
	}

	@BeforeAll
	static void setUpAll() {
		baseSetUpAll();
	}

	@BeforeEach
	void setUpEach(TestInfo testInfo) {
		baseSetUp(getStage(), testInfo);
		openAndLogin3rdPartyPortal();
	}

	@AfterEach
	void tearDownEach() {
		baseTearDown();
	}

	@AfterAll
	static void tearDownAll() {
		baseTearDownAll();
	}

	@Test
	@Order(1)
	void testCreateContainer() {
		abortTests();
		if (false) {
			containerId = testingCreateContainer(10).containerId();
		} else {
			containerId = testingCreateContainer().containerId();
		}
		continueTests();
	}

	@Test
	@Order(2)
	void testCreatedContainerDetails() {
		openContainerOverview();

		findRegressionContainerAndViewDetails();

		locateCarDataBody().getByText("CONTAINER-ÜBERSICHT").assertVisible();
		assertContainerDetail("Name des Containers", getTestingContainerTitle());
		assertContainerDetail("Container-ID", containerId);
		String expectEmailAddress = "CarData.Playwright.Automation+360m@byom.de";
		assertContainerDetail("Ansprechpartner für den Kunden", expectEmailAddress);

		String actualPurpose = locateContainerDetailNotification().inputValue();
		assertEquals("Das ist ein Playwright Test", actualPurpose);

		assertTelematicCatalogueValue("Angaben zum Fahrzeugstatus", 1, "76");
		assertTelematicCatalogueValue("Angaben zum Fahrzeugstatus", 2, "22,04");
		assertTelematicCatalogueValue("Nutzungsbasierte Daten", 1, "9");
		assertTelematicCatalogueValue("Nutzungsbasierte Daten", 2, "2,61");
		assertTelematicCatalogueValue("Daten zu elektrischen Fahrzeugen", 1, "53");
		assertTelematicCatalogueValue("Daten zu elektrischen Fahrzeugen", 2, "15,37");
		assertTelematicCatalogueValue("Events – Informationen zu definierten Ereignissen", 1, "12");
		assertTelematicCatalogueValue("Events – Informationen zu definierten Ereignissen", 2, "1,08");
		assertTelematicCatalogueValue("Basisdaten", 1, "5");
		assertTelematicCatalogueValue("Basisdaten", 2, "1,45");
		assertTelematicCatalogueValue("Daten zu den Reifen Ihres Fahrzeugs", 1, "4");
		assertTelematicCatalogueValue("Daten zu den Reifen Ihres Fahrzeugs", 2, "1,16");
		assertTelematicCatalogueValue("Gesamtsumme", 1, "159");
		assertTelematicCatalogueValue("Gesamtsumme", 2, "43,71");

		locateButtonBackToOverview().click();
		assertEquals(containerId, findRegressionContainerAndGetContainerId());
	}

	private void assertContainerDetail(String key, String value) {
		locateContainerDetail(key)
			.filter(getByText(value))
			.assertVisible();
	}

	private LocatorHandle locateContainerDetailNotification() {
		return locateContainerDetail("Nachricht an den Kunden, um die Freigabe seiner Daten zu beantragen. Bitte formulieren Sie hier den Verwendungszweck")
			.select("textarea");
	}

	private LocatorHandle locateContainerDetail(String key) {
		return locateContainerDetailHeader()
			.select("div.ant-row")
			.filter(getByText(key));
	}

	@Test
	@Order(3)
	void testPriceList() {
		openContainerOverview();
		findRegressionContainerAndViewDetails();

		locatePriceListLink().click();

		locateCarDataBody().getByText("PREISE").andIsHeading().assertVisible();
		locateCarDataBody().getByText("Gültig ab").andIsHeading().assertVisible();
		locateCarDataBody().getByText("Preisübersicht").andIsHeading().assertVisible();
		locateCarDataBody().getByText("Maximalbetrag je Datenfreigabe").andIsHeading().assertVisible();
		locateCarDataBody().getByText("Volumenbasierter Rabatt").nth(0).andIsHeading().assertVisible();
	}

	@Test
	@Order(4)
	void testDeleteCreatedContainer() {
		var containerId = openContainerOverviewAndDeleteContainer();

		var e = Assertions.assertThrows(ApiException.class, () -> {
			getClearanceClient().requestClearance(containerId, getSutVin());
		});

		getByText(getTestingContainerTitle()).assertMissing();
	}
}
