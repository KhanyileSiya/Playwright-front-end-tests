package de.bmw.otp.MyRollsRoyce;

import de.bmw.otp.business.AbstractResetAccountTests;
import de.bmw.otp.business.MyRollsRoyceHelper;

public class ResetMyRollsRoyceAccountTest extends AbstractResetAccountTests implements MyRollsRoyceHelper {
}
