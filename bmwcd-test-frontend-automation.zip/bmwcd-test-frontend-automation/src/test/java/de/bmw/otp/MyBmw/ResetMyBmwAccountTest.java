package de.bmw.otp.MyBmw;

import de.bmw.otp.business.AbstractResetAccountTests;
import de.bmw.otp.business.MyBmwHelper;

public class ResetMyBmwAccountTest extends AbstractResetAccountTests implements MyBmwHelper {
}
