package de.bmw.otp.MyToyota;

import de.bmw.otp.business.AbstractDataRetrievalIndependentRegressionTests;
import de.bmw.otp.business.MyToyotaHelper;

public class DataRetrievalRegressionForToyotaTest extends AbstractDataRetrievalIndependentRegressionTests implements MyToyotaHelper {
}
