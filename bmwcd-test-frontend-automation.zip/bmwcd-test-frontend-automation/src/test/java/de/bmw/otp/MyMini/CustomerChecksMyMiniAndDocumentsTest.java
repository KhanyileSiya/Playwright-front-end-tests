package de.bmw.otp.MyMini;

import de.bmw.otp.business.AbstractDocumentsTests;
import de.bmw.otp.business.MyMiniHelper;
import org.junit.jupiter.api.Test;

public class CustomerChecksMyMiniAndDocumentsTest extends AbstractDocumentsTests implements MyMiniHelper {

	@Test
	void testLinkMoreAboutCarData() {
		openPageAndLoginAndSelectVin(getSutVin());

		try (var popup = waitForPopup(() -> {
			getByText("Mehr über MINI CarData erfahren").click();
		})) {
			try (var temp = withTemporaryPage(popup)) {
				getByText("WAS IST MINI CARDATA?").assertVisible();
				getByText("IHRE FAHRZEUGDATEN IM BLICK").assertVisible();
				getByText("DATENFREIGABE VERWALTEN").assertVisible();
				getByText("MINI CARDATA – SO GEHT'S:").assertVisible();
				getByText("IHRE VORTEILE").assertVisible();
				getByText("INNOVATIONEN FÜR EINE AUTOMOBILE ZUKUNFT").assertVisible();
				getByText("DATENFREIGABE VERWALTEN").assertVisible();
			}
		}
	}

	@Test
	void testLinkFAQAndHelp() {
		openPageAndLoginAndSelectVin(getSutVin());

		try (var popup = waitForPopup(() -> {
			getByText("FAQ und Hilfe").click();
		})) {
			try (var temp = withTemporaryPage(popup)) {
				getByText("Was sind Telematikdaten?").assertVisible();
				getByText("Was ist MINI CarData?").assertVisible();
				getByText("Was kostet die Nutzung von MINI CarData?").assertVisible();
				getByText("Welchen Mehrwert bietet mir MINI CarData?").assertVisible();
				getByText("Welche Daten werden in meinem Fahrzeug gesammelt? Zu welchem Zweck?").assertVisible();
			}
		}
	}
}
