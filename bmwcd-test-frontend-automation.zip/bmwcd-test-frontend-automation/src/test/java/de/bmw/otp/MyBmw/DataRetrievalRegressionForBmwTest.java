package de.bmw.otp.MyBmw;

import de.bmw.otp.business.AbstractDataRetrievalIndependentRegressionTests;
import de.bmw.otp.business.MyBmwHelper;

public class DataRetrievalRegressionForBmwTest extends AbstractDataRetrievalIndependentRegressionTests implements MyBmwHelper {
}
