package de.bmw.otp.MyRollsRoyce;

import de.bmw.otp.business.AbstractDataRetrievalIndependentRegressionTests;
import de.bmw.otp.business.MyRollsRoyceHelper;

public class DataRetrievalRegressionForRollsRoyceTest extends AbstractDataRetrievalIndependentRegressionTests implements MyRollsRoyceHelper {
}
