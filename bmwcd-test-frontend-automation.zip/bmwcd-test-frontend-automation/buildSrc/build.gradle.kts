plugins {
    id("java")
}

repositories {
    mavenCentral()
}

dependencies {
    implementation(gradleApi())
}
