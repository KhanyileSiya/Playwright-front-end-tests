package de.bmw.otp.tests;

import org.gradle.api.tasks.testing.TestDescriptor;
import org.gradle.api.tasks.testing.TestListener;
import org.gradle.api.tasks.testing.TestOutputEvent;
import org.gradle.api.tasks.testing.TestOutputListener;
import org.gradle.api.tasks.testing.TestResult;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TestResultExporterForXRay implements TestListener, TestOutputListener {

	private record TestCaseResult(TestDescriptor testCase, TestResult result, List<String> output) {
		public void toXml(PrintWriter xml) {
			var duration = durationOfTestToString(result);
			var detailedMessage = getDetailedMessage(result);
			xml.printf("""
	<testcase name="%s" classname="%s" time="%s">
		%s
		<properties>
			<property name="test_description"><![CDATA[%s""",
				escapeXml(testCase.getClassName() + "::" + testCase.getName()), escapeXml(testCase.getClassName()), escapeXml(duration), detailedMessage, joinAndTruncateOutput(output));
			for (Throwable e : result.getExceptions()) {
				e.printStackTrace(xml);
			}
			xml.println("""
		]]></property>
		</properties>
	</testcase>""");
		}

		private String getDetailedMessage(TestResult result) {
			return switch (result.getResultType()) {
				case FAILURE -> getFailureDetails(result);
				case SKIPPED -> getSkippedDetails(result);
				default -> "";
			};
		}

		private String getFailureDetails(TestResult result) {
			return result.getFailures()
				.stream()
				.map(failure -> {
					var details = failure.getDetails();
					String errorMessageEscaped = Optional.ofNullable(details.getMessage())
						.map(TestResultExporterForXRay::escapeXml)
						.map(TestResultExporterForXRay::escapeLinebreaks)
						.orElse("");
					return """
			<failure type="%s" message="%s">
				%s
			</failure>
			""".formatted(escapeXml(details.getClassName()),
						errorMessageEscaped,
						escapeXml(details.getStacktrace()));
			})
				.collect(Collectors.joining(System.lineSeparator()));
		}

		private String getSkippedDetails(TestResult result) {
			return "<skipped type=\"skipped\" message=\"\"/>";
		}
	}

	static String joinAndTruncateOutput(List<String> lines) {
		int characterThreshold = 15*1024;
		var characterCountByLine = countCharactersIncludingLf(lines);
		int countAllCharacters = characterCountByLine.stream()
			.reduce(0, Integer::sum);
		if (countAllCharacters < characterThreshold) {
			return joinOutput(lines);
		}
		int includeLinesFromTop = howManyLinesUntilThreshold(characterCountByLine, characterThreshold / 2);
		int includeLinesFromBottom = howManyLinesUntilThreshold(characterCountByLine.reversed(), characterThreshold / 2);
		int continueAt = lines.size() - includeLinesFromBottom;

		return joinOutput(
			Stream.concat(Stream.concat(
				lines.stream().limit(includeLinesFromTop),
				Stream.of("%d-%d: [...]".formatted(includeLinesFromTop+1, continueAt))),
				lines.stream().skip(continueAt)
			).toList()
		);
	}

	static List<Integer> countCharactersIncludingLf(List<String> lines) {
		return lines
			.stream()
			.map(String::length)
			.map(count -> count + 1)
			.toList();
	}

	static int howManyLinesUntilThreshold(List<Integer> characterCountByLine, int threshold) {
		int i = 0;
		for (int count : characterCountByLine) {
			threshold -= count;
			if (threshold < 0) {
				break;
			}
			i++;
		}
		return i;
	}

	private static String joinOutput(List<String> lines) {
		return String.join(System.lineSeparator(), lines);
	}

	private List<TestCaseResult> testCases = new ArrayList<>();
	private List<String> outputOfTestCase = new ArrayList<>();

	@Override
	public void beforeSuite(TestDescriptor suite) {
	}

	@Override
	public void afterSuite(TestDescriptor suite, TestResult result) {
		var startTimestamp = Instant.ofEpochMilli(result.getStartTime());
		var durationDecimal = durationOfTestToString(result);
		var baos = new ByteArrayOutputStream();
		var xml = new PrintWriter(baos);
		xml.printf("""
<?xml version="1.0" encoding="UTF-8"?>
<testsuite name="%s" tests="%s" skipped="%s" failures="%s" errors="0" timestamp="%s" time="%s">
	""", escapeXml(getTestRunName()), result.getTestCount(), result.getSkippedTestCount(), result.getFailedTestCount(), startTimestamp, durationDecimal);
		for (TestCaseResult testCase : testCases) {
			testCase.toXml(xml);
		}
		xml.println("</testsuite>");
		xml.close();

		try {
			var parent = Path.of("results");
			Files.createDirectories(parent);
			Files.write(parent.resolve("TEST-" + getTestRunName() + ".xml"), baos.toByteArray());
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public void beforeTest(TestDescriptor testDescriptor) {
		outputOfTestCase = new ArrayList<>();
	}

	@Override
	public void afterTest(TestDescriptor testDescriptor, TestResult result) {
		testCases.add(new TestCaseResult(testDescriptor, result, outputOfTestCase));
	}

	@Override
	public void onOutput(TestDescriptor testDescriptor, TestOutputEvent outputEvent) {
		if (outputEvent.getMessage() != null) {
			this.outputOfTestCase.add(outputEvent.getMessage());
		}
	}

	private String getTestRunName() {
		return Optional.ofNullable(System.getenv("TEST_RUN_NAME"))
			.orElse("frontend-automation");
	}

	private static String durationOfTestToString(TestResult result) {
		return durationToString(durationOfTest(result));
	}

	private static Duration durationOfTest(TestResult result) {
		return Duration.ofMillis(result.getEndTime()- result.getStartTime());
	}

	private static String durationToString(Duration duration) {
		return new BigDecimal(duration.toMillis()).divide(BigDecimal.valueOf(1000), 3, RoundingMode.HALF_UP).toString();
	}

	private static String escapeXml(String s) {
		if (s == null) {
			return null;
		}
		return s.replace("&","&amp;")
			.replace("\"","&quot;")
			.replace("<","&lt;")
			.replace(">","&gt;");
	}

	private static String escapeLinebreaks(String s) {
		if (s == null) {
			return null;
		}
		return s.replace("\r","&#13;")
			.replace("\n","&#10;");
	}
}
